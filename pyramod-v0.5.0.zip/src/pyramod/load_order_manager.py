import os
import json
from typing import Dict, List, Optional
from error_handler import error_handler

class LoadOrderManager:
    def __init__(self):
        self.load_order_file = "load_order.json"
        self.supported_games = {
            "The Elder Scrolls V: Skyrim": {
                "plugin_extensions": [".esp", ".esm", ".esl"],
                "load_order_file": "plugins.txt"
            },
            "Fallout 4": {
                "plugin_extensions": [".esp", ".esm", ".esl"],
                "load_order_file": "plugins.txt"
            },
            "Stardew Valley": {
                "plugin_extensions": [".dll", ".json"],
                "load_order_file": "smapi-internal/load_order.json"
            },
            "Terraria": {
                "plugin_extensions": [".tmod"],
                "load_order_file": "tModLoader/load_order.json"
            }
        }

    def get_load_order(self, game_name: str, mods_dir: str) -> List[Dict]:
        """Get the current load order for a game"""
        try:
            if game_name not in self.supported_games:
                raise ValueError(f"Game {game_name} not supported")

            game_info = self.supported_games[game_name]
            load_order = []

            # Get all plugins
            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    for file in os.listdir(mod_path):
                        if any(file.endswith(ext) for ext in game_info["plugin_extensions"]):
                            load_order.append({
                                "mod": mod,
                                "plugin": file,
                                "enabled": True
                            })

            # Sort based on game-specific rules
            if game_name in ["The Elder Scrolls V: Skyrim", "Fallout 4"]:
                load_order = self._sort_bethesda_plugins(load_order)
            elif game_name == "Stardew Valley":
                load_order = self._sort_smapi_plugins(load_order)
            elif game_name == "Terraria":
                load_order = self._sort_tmodloader_plugins(load_order)

            return load_order

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "mods_dir": mods_dir
            })
            return []

    def set_load_order(self, game_name: str, mods_dir: str, load_order: List[Dict]) -> bool:
        """Set the load order for a game"""
        try:
            if game_name not in self.supported_games:
                raise ValueError(f"Game {game_name} not supported")

            game_info = self.supported_games[game_name]
            load_order_file = os.path.join(mods_dir, game_info["load_order_file"])

            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(load_order_file), exist_ok=True)

            # Save load order
            with open(load_order_file, "w") as f:
                if game_name in ["The Elder Scrolls V: Skyrim", "Fallout 4"]:
                    # Bethesda games use a simple text file
                    for plugin in load_order:
                        if plugin["enabled"]:
                            f.write(f"*{plugin['plugin']}\n")
                        else:
                            f.write(f"{plugin['plugin']}\n")
                else:
                    # Other games use JSON
                    json.dump(load_order, f, indent=4)

            error_handler.log_info(f"Updated load order for {game_name}")
            return True

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "mods_dir": mods_dir,
                "load_order": load_order
            })
            return False

    def _sort_bethesda_plugins(self, plugins: List[Dict]) -> List[Dict]:
        """Sort plugins for Bethesda games"""
        # Sort by file extension (ESM before ESP)
        def get_priority(plugin):
            ext = os.path.splitext(plugin["plugin"])[1].lower()
            if ext == ".esm":
                return 0
            elif ext == ".esl":
                return 1
            else:
                return 2

        return sorted(plugins, key=get_priority)

    def _sort_smapi_plugins(self, plugins: List[Dict]) -> List[Dict]:
        """Sort plugins for SMAPI (Stardew Valley)"""
        # SMAPI plugins are typically loaded in alphabetical order
        return sorted(plugins, key=lambda x: x["plugin"].lower())

    def _sort_tmodloader_plugins(self, plugins: List[Dict]) -> List[Dict]:
        """Sort plugins for tModLoader (Terraria)"""
        # tModLoader plugins are typically loaded in alphabetical order
        return sorted(plugins, key=lambda x: x["plugin"].lower())

    def validate_load_order(self, game_name: str, load_order: List[Dict]) -> List[Dict]:
        """Validate a load order for potential issues"""
        issues = []

        if game_name in ["The Elder Scrolls V: Skyrim", "Fallout 4"]:
            # Check for master file dependencies
            for i, plugin in enumerate(load_order):
                if plugin["plugin"].endswith(".esp"):
                    # Check if required master files are loaded before this plugin
                    # This is a simplified check. A real implementation would need to
                    # read the ESP file headers to check actual dependencies
                    for j in range(i):
                        if load_order[j]["plugin"].endswith(".esm"):
                            issues.append({
                                "type": "master_dependency",
                                "plugin": plugin["plugin"],
                                "master": load_order[j]["plugin"],
                                "message": f"Master file {load_order[j]['plugin']} should be loaded before {plugin['plugin']}"
                            })

        return issues

# Create a global load order manager instance
load_order_manager = LoadOrderManager() 