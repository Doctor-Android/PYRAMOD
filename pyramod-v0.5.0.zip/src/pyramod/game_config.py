import json
from pathlib import Path
from typing import Dict, List, Optional
import logging
from dataclasses import dataclass
import os

@dataclass
class GameConfig:
    name: str
    executable: str
    data_path: str
    mod_path: str
    load_order_file: str
    wine_prefix: Optional[str] = None
    wine_executable: str = "wine"
    proton_executable: str = "proton"
    required_tools: List[str] = None
    supported_mod_types: List[str] = None
    load_order_rules: Dict = None

class GameManager:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.config_path = base_path / "game_configs"
        self.config_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=self.base_path / "game_manager.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Default game configurations
        self.default_configs = {
            "skyrim": GameConfig(
                name="Skyrim Special Edition",
                executable="SkyrimSE.exe",
                data_path="Data",
                mod_path="Data",
                load_order_file="plugins.txt",
                required_tools=["LOOT", "xEdit"],
                supported_mod_types=[".esp", ".esm", ".esl", ".bsa"],
                load_order_rules={
                    "masters_first": True,
                    "esm_before_esp": True,
                    "esl_at_end": True
                }
            ),
            "fallout4": GameConfig(
                name="Fallout 4",
                executable="Fallout4.exe",
                data_path="Data",
                mod_path="Data",
                load_order_file="plugins.txt",
                required_tools=["LOOT", "xEdit"],
                supported_mod_types=[".esp", ".esm", ".esl", ".ba2"],
                load_order_rules={
                    "masters_first": True,
                    "esm_before_esp": True,
                    "esl_at_end": True
                }
            ),
            "witcher3": GameConfig(
                name="The Witcher 3",
                executable="witcher3.exe",
                data_path="content",
                mod_path="mods",
                load_order_file="mods.settings",
                required_tools=["Script Merger"],
                supported_mod_types=[".w3mod", ".zip"],
                load_order_rules={
                    "alphabetical": True
                }
            ),
            "cyberpunk": GameConfig(
                name="Cyberpunk 2077",
                executable="Cyberpunk2077.exe",
                data_path="archive/pc/mod",
                mod_path="archive/pc/mod",
                load_order_file="mods.json",
                required_tools=["Cyberpunk Mod Manager"],
                supported_mod_types=[".zip", ".pak"],
                load_order_rules={
                    "alphabetical": True
                }
            )
        }
        
    def get_game_config(self, game_id: str) -> Optional[GameConfig]:
        """Get configuration for a specific game"""
        try:
            config_file = self.config_path / f"{game_id}.json"
            if config_file.exists():
                with open(config_file, 'r') as f:
                    config_data = json.load(f)
                    return GameConfig(**config_data)
            return self.default_configs.get(game_id)
        except Exception as e:
            logging.error(f"Failed to get game config: {e}")
            return None
            
    def save_game_config(self, game_id: str, config: GameConfig) -> bool:
        """Save configuration for a specific game"""
        try:
            config_file = self.config_path / f"{game_id}.json"
            with open(config_file, 'w') as f:
                json.dump(config.__dict__, f, indent=2)
            return True
        except Exception as e:
            logging.error(f"Failed to save game config: {e}")
            return False
            
    def get_supported_games(self) -> List[str]:
        """Get list of supported games"""
        return list(self.default_configs.keys())
        
    def validate_game_path(self, game_id: str, path: Path) -> bool:
        """Validate if a path contains a valid game installation"""
        try:
            config = self.get_game_config(game_id)
            if not config:
                return False
                
            # Check for executable
            if not (path / config.executable).exists():
                return False
                
            # Check for data directory
            if not (path / config.data_path).exists():
                return False
                
            return True
            
        except Exception as e:
            logging.error(f"Failed to validate game path: {e}")
            return False
            
    def get_game_specific_paths(self, game_id: str, base_path: Path) -> Dict[str, Path]:
        """Get game-specific paths for mod installation"""
        try:
            config = self.get_game_config(game_id)
            if not config:
                return {}
                
            return {
                "data": base_path / config.data_path,
                "mods": base_path / config.mod_path,
                "load_order": base_path / config.load_order_file
            }
            
        except Exception as e:
            logging.error(f"Failed to get game paths: {e}")
            return {}
            
    def get_game_specific_tools(self, game_id: str) -> List[str]:
        """Get list of required tools for a game"""
        try:
            config = self.get_game_config(game_id)
            if not config:
                return []
            return config.required_tools or []
        except Exception as e:
            logging.error(f"Failed to get game tools: {e}")
            return []
            
    def get_supported_mod_types(self, game_id: str) -> List[str]:
        """Get list of supported mod file types for a game"""
        try:
            config = self.get_game_config(game_id)
            if not config:
                return []
            return config.supported_mod_types or []
        except Exception as e:
            logging.error(f"Failed to get supported mod types: {e}")
            return []
            
    def get_load_order_rules(self, game_id: str) -> Dict:
        """Get load order rules for a game"""
        try:
            config = self.get_game_config(game_id)
            if not config:
                return {}
            return config.load_order_rules or {}
        except Exception as e:
            logging.error(f"Failed to get load order rules: {e}")
            return {} 