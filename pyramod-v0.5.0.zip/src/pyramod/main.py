"""
Main application for Pyramod.
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
from typing import Dict, List, Optional, Union

from .wine_config_manager import WineConfigManager
from .system_compatibility import SystemCompatibilityChecker
from .mod_compatibility import ModCompatibilityChecker
from .mod_installer import ModInstaller
from .mod_manager import ModManager
from .gui import run_gui

def setup_logging(config_dir: Path):
    """Set up logging configuration.
    
    Args:
        config_dir: Configuration directory
    """
    log_dir = config_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[
            logging.FileHandler(log_dir / "pyramod.log"),
            logging.StreamHandler()
        ]
    )

def parse_args():
    """Parse command line arguments.
    
    Returns:
        Parsed arguments
    """
    parser = argparse.ArgumentParser(description="Pyramod - Mod Manager")
    
    parser.add_argument(
        "--config-dir",
        type=str,
        default=os.path.expanduser("~/.config/pyramod"),
        help="Configuration directory"
    )
    
    parser.add_argument(
        "--game",
        type=str,
        choices=["skyrim", "fallout4"],
        help="Game to manage"
    )
    
    parser.add_argument(
        "--profile",
        type=str,
        help="Mod profile to use"
    )
    
    parser.add_argument(
        "--install-path",
        type=str,
        help="Game installation path"
    )
    
    parser.add_argument(
        "--list-profiles",
        action="store_true",
        help="List available mod profiles"
    )
    
    parser.add_argument(
        "--create-profile",
        type=str,
        help="Create a new mod profile"
    )
    
    parser.add_argument(
        "--delete-profile",
        type=str,
        help="Delete a mod profile"
    )
    
    parser.add_argument(
        "--activate-profile",
        type=str,
        help="Activate a mod profile"
    )
    
    parser.add_argument(
        "--check-compatibility",
        action="store_true",
        help="Check mod compatibility"
    )
    
    parser.add_argument(
        "--install-mod",
        type=str,
        help="Install a mod"
    )
    
    parser.add_argument(
        "--uninstall-mod",
        type=str,
        help="Uninstall a mod"
    )
    
    parser.add_argument(
        "--list-mods",
        action="store_true",
        help="List installed mods"
    )
    
    parser.add_argument(
        "--export-profile",
        type=str,
        help="Export a mod profile"
    )
    
    parser.add_argument(
        "--import-profile",
        type=str,
        help="Import a mod profile"
    )
    
    parser.add_argument(
        "--gui",
        action="store_true",
        help="Launch the GUI interface"
    )
    
    return parser.parse_args()

def main():
    """Main application entry point."""
    args = parse_args()
    
    # Set up configuration directory
    config_dir = Path(args.config_dir)
    config_dir.mkdir(parents=True, exist_ok=True)
    
    # Set up logging
    setup_logging(config_dir)
    logger = logging.getLogger("pyramod")
    
    # If GUI mode is requested, launch the GUI
    if args.gui:
        run_gui(str(config_dir))
        return
    
    # Initialize components
    wine_config = WineConfigManager(str(config_dir))
    system_checker = SystemCompatibilityChecker(str(config_dir))
    mod_checker = ModCompatibilityChecker(str(config_dir))
    mod_installer = ModInstaller(str(config_dir))
    mod_manager = ModManager(str(config_dir))
    
    # Process arguments
    if args.game:
        if args.install_path:
            if not mod_installer.set_game_path(args.game, args.install_path):
                logger.error(f"Failed to set game path for {args.game}")
                sys.exit(1)
        
        if args.list_profiles:
            profiles = mod_manager.list_profiles(args.game)
            for profile in profiles:
                print(f"{profile['id']}: {profile['name']} {'(active)' if profile['active'] else ''}")
        
        if args.create_profile:
            if not mod_manager.create_profile(args.game, args.create_profile, args.create_profile):
                logger.error(f"Failed to create profile {args.create_profile}")
                sys.exit(1)
        
        if args.delete_profile:
            if not mod_manager.delete_profile(args.game, args.delete_profile):
                logger.error(f"Failed to delete profile {args.delete_profile}")
                sys.exit(1)
        
        if args.activate_profile:
            if not mod_manager.activate_profile(args.game, args.activate_profile):
                logger.error(f"Failed to activate profile {args.activate_profile}")
                sys.exit(1)
        
        if args.check_compatibility:
            if not args.profile:
                logger.error("Profile not specified")
                sys.exit(1)
            
            results = mod_manager.check_profile_compatibility(args.game, args.profile)
            if not results["compatible"]:
                logger.error("Compatibility check failed")
                for warning in results["warnings"]:
                    logger.warning(warning)
                sys.exit(1)
        
        if args.install_mod:
            if not args.profile:
                logger.error("Profile not specified")
                sys.exit(1)
            
            if not mod_manager.add_mod_to_profile(args.game, args.profile, args.install_mod):
                logger.error(f"Failed to add mod {args.install_mod} to profile {args.profile}")
                sys.exit(1)
        
        if args.uninstall_mod:
            if not args.profile:
                logger.error("Profile not specified")
                sys.exit(1)
            
            if not mod_manager.remove_mod_from_profile(args.game, args.profile, args.uninstall_mod):
                logger.error(f"Failed to remove mod {args.uninstall_mod} from profile {args.profile}")
                sys.exit(1)
        
        if args.list_mods:
            if not args.profile:
                logger.error("Profile not specified")
                sys.exit(1)
            
            mods = mod_manager.get_profile_mods(args.game, args.profile)
            for mod_id in mods:
                print(mod_id)
        
        if args.export_profile:
            if not args.profile:
                logger.error("Profile not specified")
                sys.exit(1)
            
            if not mod_manager.export_profile(args.game, args.profile, args.export_profile):
                logger.error(f"Failed to export profile {args.profile}")
                sys.exit(1)
        
        if args.import_profile:
            if not mod_manager.import_profile(args.import_profile):
                logger.error(f"Failed to import profile from {args.import_profile}")
                sys.exit(1)

if __name__ == "__main__":
    main() 