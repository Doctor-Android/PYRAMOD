#!/usr/bin/env python3
import os
import json
import shutil
import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

class ProtonManager:
    """Manages Proton/Wine prefixes for modded games."""
    
    def __init__(self, config_dir: str = None):
        """Initialize the Proton manager.
        
        Args:
            config_dir: Directory to store configuration and prefix data
        """
        self.logger = logging.getLogger("ProtonManager")
        
        # Set up directories
        if config_dir is None:
            config_dir = str(Path.home() / ".config" / "pyramod" / "proton")
        self.config_dir = Path(config_dir)
        self.prefixes_dir = self.config_dir / "prefixes"
        self.config_file = self.config_dir / "config.json"
        
        # Create directories if they don't exist
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.prefixes_dir.mkdir(parents=True, exist_ok=True)
        
        # Load configuration
        self.config = self._load_config()
        
        # Initialize prefix registry
        self.prefix_registry = self._load_prefix_registry()
    
    def _load_config(self) -> dict:
        """Load configuration from file."""
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.error(f"Failed to load config: {e}")
                return self._get_default_config()
        return self._get_default_config()
    
    def _save_config(self):
        """Save configuration to file."""
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
        except Exception as e:
            self.logger.error(f"Failed to save config: {e}")
    
    def _get_default_config(self) -> dict:
        """Get default configuration."""
        return {
            "proton_paths": {
                "steam": str(Path.home() / ".steam" / "steam" / "steamapps" / "common"),
                "lutris": str(Path.home() / ".local" / "share" / "lutris" / "runners" / "wine"),
                "system": "/usr/share/wine"
            },
            "default_proton_version": "GE-Proton7-55",
            "prefix_settings": {
                "dxvk": True,
                "vkd3d": True,
                "esync": True,
                "fsync": True,
                "gamemode": True
            }
        }
    
    def _load_prefix_registry(self) -> dict:
        """Load prefix registry from file."""
        registry_file = self.config_dir / "prefix_registry.json"
        if registry_file.exists():
            try:
                with open(registry_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                self.logger.error(f"Failed to load prefix registry: {e}")
                return {}
        return {}
    
    def _save_prefix_registry(self):
        """Save prefix registry to file."""
        registry_file = self.config_dir / "prefix_registry.json"
        try:
            with open(registry_file, 'w') as f:
                json.dump(self.prefix_registry, f, indent=4)
        except Exception as e:
            self.logger.error(f"Failed to save prefix registry: {e}")
    
    def detect_proton_installations(self) -> Dict[str, List[str]]:
        """Detect installed Proton versions.
        
        Returns:
            Dictionary mapping installation types to lists of Proton versions
        """
        installations = {}
        
        # Check Steam Proton installations
        steam_path = Path(self.config["proton_paths"]["steam"])
        if steam_path.exists():
            installations["steam"] = [
                d.name for d in steam_path.iterdir()
                if d.is_dir() and d.name.startswith("Proton")
            ]
        
        # Check Lutris Wine installations
        lutris_path = Path(self.config["proton_paths"]["lutris"])
        if lutris_path.exists():
            installations["lutris"] = [
                d.name for d in lutris_path.iterdir()
                if d.is_dir() and "wine" in d.name.lower()
            ]
        
        # Check system Wine installation
        system_path = Path(self.config["proton_paths"]["system"])
        if system_path.exists():
            installations["system"] = ["system"]
        
        return installations
    
    def create_prefix(self, game_name: str, proton_version: str = None) -> bool:
        """Create a new Proton/Wine prefix for a game.
        
        Args:
            game_name: Name of the game
            proton_version: Version of Proton/Wine to use
            
        Returns:
            True if successful, False otherwise
        """
        if proton_version is None:
            proton_version = self.config["default_proton_version"]
        
        # Create prefix directory
        prefix_dir = self.prefixes_dir / game_name
        if prefix_dir.exists():
            self.logger.warning(f"Prefix for {game_name} already exists")
            return False
        
        try:
            # Create prefix directory
            prefix_dir.mkdir(parents=True)
            
            # Initialize prefix with wineboot
            env = os.environ.copy()
            env["WINEPREFIX"] = str(prefix_dir)
            env["WINEARCH"] = "win64"
            
            # Find Proton/Wine executable
            proton_path = self._find_proton_executable(proton_version)
            if not proton_path:
                self.logger.error(f"Could not find Proton/Wine executable for version {proton_version}")
                return False
            
            # Run wineboot
            subprocess.run([proton_path, "wineboot", "-i"], env=env, check=True)
            
            # Apply prefix settings
            self._apply_prefix_settings(prefix_dir, proton_path)
            
            # Register prefix
            self.prefix_registry[game_name] = {
                "path": str(prefix_dir),
                "proton_version": proton_version,
                "created_at": str(Path(prefix_dir).stat().st_ctime),
                "settings": self.config["prefix_settings"].copy()
            }
            self._save_prefix_registry()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to create prefix: {e}")
            if prefix_dir.exists():
                shutil.rmtree(prefix_dir)
            return False
    
    def delete_prefix(self, game_name: str) -> bool:
        """Delete a Proton/Wine prefix.
        
        Args:
            game_name: Name of the game
            
        Returns:
            True if successful, False otherwise
        """
        if game_name not in self.prefix_registry:
            self.logger.warning(f"No prefix found for {game_name}")
            return False
        
        prefix_dir = Path(self.prefix_registry[game_name]["path"])
        if not prefix_dir.exists():
            self.logger.warning(f"Prefix directory for {game_name} does not exist")
            return False
        
        try:
            # Delete prefix directory
            shutil.rmtree(prefix_dir)
            
            # Remove from registry
            del self.prefix_registry[game_name]
            self._save_prefix_registry()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to delete prefix: {e}")
            return False
    
    def get_prefix_info(self, game_name: str) -> Optional[dict]:
        """Get information about a prefix.
        
        Args:
            game_name: Name of the game
            
        Returns:
            Dictionary containing prefix information, or None if not found
        """
        return self.prefix_registry.get(game_name)
    
    def list_prefixes(self) -> List[Tuple[str, dict]]:
        """List all prefixes.
        
        Returns:
            List of tuples containing game name and prefix information
        """
        return list(self.prefix_registry.items())
    
    def update_prefix_settings(self, game_name: str, settings: dict) -> bool:
        """Update settings for a prefix.
        
        Args:
            game_name: Name of the game
            settings: Dictionary of settings to update
            
        Returns:
            True if successful, False otherwise
        """
        if game_name not in self.prefix_registry:
            self.logger.warning(f"No prefix found for {game_name}")
            return False
        
        try:
            # Update settings
            self.prefix_registry[game_name]["settings"].update(settings)
            
            # Apply new settings
            prefix_dir = Path(self.prefix_registry[game_name]["path"])
            proton_path = self._find_proton_executable(self.prefix_registry[game_name]["proton_version"])
            if proton_path:
                self._apply_prefix_settings(prefix_dir, proton_path)
            
            # Save registry
            self._save_prefix_registry()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to update prefix settings: {e}")
            return False
    
    def _find_proton_executable(self, version: str) -> Optional[str]:
        """Find Proton/Wine executable for a given version.
        
        Args:
            version: Version of Proton/Wine
            
        Returns:
            Path to executable, or None if not found
        """
        # Check Steam Proton
        steam_path = Path(self.config["proton_paths"]["steam"]) / version / "proton"
        if steam_path.exists():
            return str(steam_path)
        
        # Check Lutris Wine
        lutris_path = Path(self.config["proton_paths"]["lutris"]) / version / "bin" / "wine"
        if lutris_path.exists():
            return str(lutris_path)
        
        # Check system Wine
        system_path = Path(self.config["proton_paths"]["system"]) / "bin" / "wine"
        if system_path.exists():
            return str(system_path)
        
        return None
    
    def _apply_prefix_settings(self, prefix_dir: Path, proton_path: str):
        """Apply settings to a prefix.
        
        Args:
            prefix_dir: Path to prefix directory
            proton_path: Path to Proton/Wine executable
        """
        env = os.environ.copy()
        env["WINEPREFIX"] = str(prefix_dir)
        env["WINEARCH"] = "win64"
        
        settings = self.config["prefix_settings"]
        
        # Apply DXVK
        if settings.get("dxvk"):
            subprocess.run([proton_path, "winetricks", "dxvk"], env=env, check=True)
        
        # Apply VKD3D
        if settings.get("vkd3d"):
            subprocess.run([proton_path, "winetricks", "vkd3d"], env=env, check=True)
        
        # Apply ESync
        if settings.get("esync"):
            env["WINEESYNC"] = "1"
        
        # Apply FSync
        if settings.get("fsync"):
            env["WINEFSYNC"] = "1"
        
        # Apply GameMode
        if settings.get("gamemode"):
            env["GAMEMODE"] = "1" 