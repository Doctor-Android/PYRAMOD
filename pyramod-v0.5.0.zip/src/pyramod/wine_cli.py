#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from wine_config_manager import WineConfigManager

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the Wine configuration CLI."""
    parser = argparse.ArgumentParser(
        description="Wine/Proton Configuration Manager CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "wine"),
        help="Directory to store Wine configurations"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create prefix command
    create_parser = subparsers.add_parser("create", help="Create a new Wine prefix")
    create_parser.add_argument("prefix_name", help="Name of the prefix to create")
    create_parser.add_argument("wine_version", help="Wine version to use")

    # Configure prefix command
    config_parser = subparsers.add_parser("configure", help="Configure a Wine prefix")
    config_parser.add_argument("prefix_name", help="Name of the prefix to configure")
    config_parser.add_argument("--registry", help="Registry settings in JSON format")
    config_parser.add_argument("--dll-overrides", help="DLL overrides in JSON format")
    config_parser.add_argument("--environment", help="Environment variables in JSON format")

    # Delete prefix command
    delete_parser = subparsers.add_parser("delete", help="Delete a Wine prefix")
    delete_parser.add_argument("prefix_name", help="Name of the prefix to delete")

    # List prefixes command
    subparsers.add_parser("list", help="List all configured prefixes")

    # Get prefix info command
    info_parser = subparsers.add_parser("info", help="Get information about a prefix")
    info_parser.add_argument("prefix_name", help="Name of the prefix to get info for")

    # Export config command
    export_parser = subparsers.add_parser("export", help="Export prefix configuration")
    export_parser.add_argument("prefix_name", help="Name of the prefix to export")
    export_parser.add_argument("output_file", help="Output file path")

    # Import config command
    import_parser = subparsers.add_parser("import", help="Import prefix configuration")
    import_parser.add_argument("input_file", help="Input file path")
    import_parser.add_argument("prefix_name", help="Name for the imported prefix")

    # List versions command
    subparsers.add_parser("versions", help="List available Wine and Proton versions")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("wine_cli")
    manager = WineConfigManager(args.config_dir)

    try:
        if args.command == "create":
            result = manager.create_prefix(args.prefix_name, args.wine_version)
            if result:
                logger.info(f"Successfully created prefix: {args.prefix_name}")
            else:
                logger.error(f"Failed to create prefix: {args.prefix_name}")
                sys.exit(1)

        elif args.command == "configure":
            settings = {}
            if args.registry:
                settings["registry"] = eval(args.registry)
            if args.dll_overrides:
                settings["dll_overrides"] = eval(args.dll_overrides)
            if args.environment:
                settings["environment"] = eval(args.environment)

            result = manager.configure_prefix(args.prefix_name, settings)
            if result:
                logger.info(f"Successfully configured prefix: {args.prefix_name}")
            else:
                logger.error(f"Failed to configure prefix: {args.prefix_name}")
                sys.exit(1)

        elif args.command == "delete":
            result = manager.delete_prefix(args.prefix_name)
            if result:
                logger.info(f"Successfully deleted prefix: {args.prefix_name}")
            else:
                logger.error(f"Failed to delete prefix: {args.prefix_name}")
                sys.exit(1)

        elif args.command == "list":
            prefixes = manager.list_prefixes()
            if prefixes:
                print("\nConfigured prefixes:")
                for prefix in prefixes:
                    print(f"- {prefix}")
            else:
                print("No prefixes configured")

        elif args.command == "info":
            info = manager.get_prefix_info(args.prefix_name)
            if info:
                print(f"\nPrefix information for {args.prefix_name}:")
                for key, value in info.items():
                    print(f"{key}: {value}")
            else:
                logger.error(f"Prefix not found: {args.prefix_name}")
                sys.exit(1)

        elif args.command == "export":
            result = manager.export_config(args.prefix_name, args.output_file)
            if result:
                logger.info(f"Successfully exported configuration to: {args.output_file}")
            else:
                logger.error(f"Failed to export configuration")
                sys.exit(1)

        elif args.command == "import":
            result = manager.import_config(args.input_file, args.prefix_name)
            if result:
                logger.info(f"Successfully imported configuration to: {args.prefix_name}")
            else:
                logger.error(f"Failed to import configuration")
                sys.exit(1)

        elif args.command == "versions":
            versions = manager.get_available_versions()
            print("\nAvailable Wine versions:")
            for version in versions["wine"]:
                print(f"- {version}")
            print("\nAvailable Proton versions:")
            for version in versions["proton"]:
                print(f"- {version}")

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 