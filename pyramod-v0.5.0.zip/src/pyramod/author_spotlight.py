#!/usr/bin/env python3
import os
import json
import logging
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import hashlib
import markdown
from PIL import Image
import shutil

class AuthorSpotlight:
    def __init__(self, config_dir: str):
        self.config_dir = Path(config_dir)
        self.spotlight_dir = self.config_dir / "spotlight"
        self.spotlight_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("AuthorSpotlight")
        self.authors = self._load_authors()
        self.spotlights = self._load_spotlights()

    def _load_authors(self) -> Dict:
        """Load author data from config file."""
        authors_file = self.spotlight_dir / "authors.json"
        if authors_file.exists():
            try:
                with open(authors_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                self.logger.error("Failed to load author data")
                return {}
        return {}

    def _load_spotlights(self) -> Dict:
        """Load spotlight data from config file."""
        spotlights_file = self.spotlight_dir / "spotlights.json"
        if spotlights_file.exists():
            try:
                with open(spotlights_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                self.logger.error("Failed to load spotlight data")
                return {}
        return {}

    def _save_authors(self):
        """Save author data to config file."""
        authors_file = self.spotlight_dir / "authors.json"
        try:
            with open(authors_file, 'w') as f:
                json.dump(self.authors, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save author data: {e}")

    def _save_spotlights(self):
        """Save spotlight data to config file."""
        spotlights_file = self.spotlight_dir / "spotlights.json"
        try:
            with open(spotlights_file, 'w') as f:
                json.dump(self.spotlights, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save spotlight data: {e}")

    def register_author(self, username: str, display_name: str, bio: str,
                       social_links: Dict[str, str] = None,
                       avatar_path: str = None) -> Optional[str]:
        """Register a new mod author."""
        try:
            # Generate author ID
            author_id = hashlib.md5(username.encode()).hexdigest()

            # Create author directory
            author_dir = self.spotlight_dir / "authors" / author_id
            author_dir.mkdir(parents=True, exist_ok=True)

            # Process avatar if provided
            avatar_url = None
            if avatar_path and os.path.exists(avatar_path):
                avatar_file = author_dir / "avatar.jpg"
                with Image.open(avatar_path) as img:
                    # Resize and optimize avatar
                    img.thumbnail((200, 200))
                    img.save(avatar_file, "JPEG", quality=85)
                avatar_url = str(avatar_file)

            # Create author record
            author = {
                "id": author_id,
                "username": username,
                "display_name": display_name,
                "bio": bio,
                "social_links": social_links or {},
                "avatar_url": avatar_url,
                "created_at": datetime.now().isoformat(),
                "mods": [],
                "awards": [],
                "stats": {
                    "total_downloads": 0,
                    "total_endorsements": 0,
                    "total_mods": 0
                }
            }

            self.authors[author_id] = author
            self._save_authors()

            return author_id

        except Exception as e:
            self.logger.error(f"Failed to register author: {e}")
            return None

    def get_author(self, author_id: str) -> Optional[Dict]:
        """Get author by ID."""
        return self.authors.get(author_id)

    def update_author(self, author_id: str, updates: Dict) -> bool:
        """Update author information."""
        try:
            if author_id not in self.authors:
                return False

            author = self.authors[author_id]
            
            # Handle avatar update
            if "avatar_path" in updates:
                avatar_path = updates.pop("avatar_path")
                if os.path.exists(avatar_path):
                    author_dir = self.spotlight_dir / "authors" / author_id
                    avatar_file = author_dir / "avatar.jpg"
                    with Image.open(avatar_path) as img:
                        img.thumbnail((200, 200))
                        img.save(avatar_file, "JPEG", quality=85)
                    author["avatar_url"] = str(avatar_file)

            # Update author data
            author.update(updates)
            self._save_authors()

            return True

        except Exception as e:
            self.logger.error(f"Failed to update author: {e}")
            return False

    def add_mod(self, author_id: str, mod_data: Dict) -> bool:
        """Add a mod to an author's profile."""
        try:
            if author_id not in self.authors:
                return False

            author = self.authors[author_id]
            mod_id = mod_data.get("id")
            
            if not mod_id:
                return False

            # Add mod if not already present
            if not any(m["id"] == mod_id for m in author["mods"]):
                author["mods"].append(mod_data)
                author["stats"]["total_mods"] = len(author["mods"])
                self._save_authors()

            return True

        except Exception as e:
            self.logger.error(f"Failed to add mod: {e}")
            return False

    def add_award(self, author_id: str, award_data: Dict) -> bool:
        """Add an award to an author's profile."""
        try:
            if author_id not in self.authors:
                return False

            author = self.authors[author_id]
            award_id = award_data.get("id")
            
            if not award_id:
                return False

            # Add award if not already present
            if not any(a["id"] == award_id for a in author["awards"]):
                author["awards"].append(award_data)
                self._save_authors()

            return True

        except Exception as e:
            self.logger.error(f"Failed to add award: {e}")
            return False

    def create_spotlight(self, author_id: str, title: str, content: str,
                        featured_mods: List[str] = None) -> Optional[str]:
        """Create a spotlight feature for an author."""
        try:
            if author_id not in self.authors:
                return False

            # Generate spotlight ID
            spotlight_id = hashlib.md5(
                f"{author_id}{datetime.now().isoformat()}".encode()
            ).hexdigest()

            # Create spotlight directory
            spotlight_dir = self.spotlight_dir / "features" / spotlight_id
            spotlight_dir.mkdir(parents=True, exist_ok=True)

            # Convert markdown content to HTML
            html_content = markdown.markdown(content)

            # Create spotlight record
            spotlight = {
                "id": spotlight_id,
                "author_id": author_id,
                "title": title,
                "content": content,
                "html_content": html_content,
                "featured_mods": featured_mods or [],
                "created_at": datetime.now().isoformat(),
                "status": "published"
            }

            self.spotlights[spotlight_id] = spotlight
            self._save_spotlights()

            return spotlight_id

        except Exception as e:
            self.logger.error(f"Failed to create spotlight: {e}")
            return None

    def get_spotlight(self, spotlight_id: str) -> Optional[Dict]:
        """Get spotlight by ID."""
        return self.spotlights.get(spotlight_id)

    def list_spotlights(self, author_id: Optional[str] = None,
                       status: Optional[str] = None) -> List[Dict]:
        """List spotlights with optional filtering."""
        spotlights = []
        for spotlight in self.spotlights.values():
            if author_id and spotlight["author_id"] != author_id:
                continue
            if status and spotlight["status"] != status:
                continue
            spotlights.append(spotlight)
        return sorted(spotlights, key=lambda x: x["created_at"], reverse=True)

    def update_spotlight(self, spotlight_id: str, updates: Dict) -> bool:
        """Update a spotlight feature."""
        try:
            if spotlight_id not in self.spotlights:
                return False

            spotlight = self.spotlights[spotlight_id]
            
            # Handle content update
            if "content" in updates:
                updates["html_content"] = markdown.markdown(updates["content"])

            spotlight.update(updates)
            self._save_spotlights()

            return True

        except Exception as e:
            self.logger.error(f"Failed to update spotlight: {e}")
            return False

    def delete_spotlight(self, spotlight_id: str) -> bool:
        """Delete a spotlight feature."""
        try:
            if spotlight_id not in self.spotlights:
                return False

            # Delete spotlight directory
            spotlight_dir = self.spotlight_dir / "features" / spotlight_id
            if spotlight_dir.exists():
                shutil.rmtree(spotlight_dir)

            del self.spotlights[spotlight_id]
            self._save_spotlights()

            return True

        except Exception as e:
            self.logger.error(f"Failed to delete spotlight: {e}")
            return False

    def get_author_stats(self, author_id: str) -> Optional[Dict]:
        """Get author statistics."""
        try:
            if author_id not in self.authors:
                return None

            author = self.authors[author_id]
            return author["stats"]

        except Exception as e:
            self.logger.error(f"Failed to get author stats: {e}")
            return None

    def update_author_stats(self, author_id: str, stats: Dict) -> bool:
        """Update author statistics."""
        try:
            if author_id not in self.authors:
                return False

            author = self.authors[author_id]
            author["stats"].update(stats)
            self._save_authors()

            return True

        except Exception as e:
            self.logger.error(f"Failed to update author stats: {e}")
            return False

if __name__ == '__main__':
    # Example usage
    logging.basicConfig(level=logging.INFO)
    spotlight = AuthorSpotlight("config")
    
    # Register an author
    author_id = spotlight.register_author(
        username="modmaster",
        display_name="Mod Master",
        bio="Passionate modder creating amazing content",
        social_links={
            "github": "https://github.com/modmaster",
            "twitter": "https://twitter.com/modmaster"
        },
        avatar_path="avatar.jpg"
    )
    
    if author_id:
        # Add a mod
        spotlight.add_mod(author_id, {
            "id": "mod123",
            "name": "Amazing Mod",
            "description": "An amazing mod",
            "downloads": 1000,
            "endorsements": 100
        })
        
        # Create a spotlight
        spotlight.create_spotlight(
            author_id,
            "Featured Modder: Mod Master",
            "Interview with the talented modder behind amazing creations",
            featured_mods=["mod123"]
        ) 