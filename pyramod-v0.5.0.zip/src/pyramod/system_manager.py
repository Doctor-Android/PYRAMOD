import apt
import subprocess
from typing import List, Dict, Optional
import json
from pathlib import Path

class SystemManager:
    def __init__(self):
        self.cache = apt.Cache()
        self.required_packages = {
            "wine": "Wine compatibility layer",
            "winetricks": "Wine helper utility",
            "lutris": "Game management platform",
            "steam": "Steam gaming platform",
            "proton": "Steam Proton compatibility tool"
        }
        
    def check_system_requirements(self) -> Dict[str, bool]:
        """Check if all required system packages are installed"""
        status = {}
        for package in self.required_packages:
            status[package] = self.is_package_installed(package)
        return status
        
    def is_package_installed(self, package_name: str) -> bool:
        """Check if a package is installed"""
        try:
            return self.cache[package_name].is_installed
        except KeyError:
            return False
            
    def install_package(self, package_name: str) -> bool:
        """Install a system package"""
        try:
            if not self.is_package_installed(package_name):
                subprocess.run(["sudo", "apt-get", "install", "-y", package_name], check=True)
            return True
        except subprocess.CalledProcessError:
            return False
            
    def install_required_packages(self) -> bool:
        """Install all required system packages"""
        try:
            packages_to_install = [
                pkg for pkg in self.required_packages
                if not self.is_package_installed(pkg)
            ]
            
            if packages_to_install:
                subprocess.run(
                    ["sudo", "apt-get", "install", "-y"] + packages_to_install,
                    check=True
                )
            return True
        except subprocess.CalledProcessError:
            return False
            
    def check_wine_version(self) -> Optional[str]:
        """Check installed Wine version"""
        try:
            result = subprocess.run(
                ["wine", "--version"],
                capture_output=True,
                text=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return None
            
    def check_proton_version(self) -> Optional[str]:
        """Check installed Proton version"""
        try:
            result = subprocess.run(
                ["proton", "--version"],
                capture_output=True,
                text=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return None
            
    def get_system_info(self) -> Dict:
        """Get detailed system information"""
        return {
            "wine_version": self.check_wine_version(),
            "proton_version": self.check_proton_version(),
            "installed_packages": {
                pkg: self.is_package_installed(pkg)
                for pkg in self.required_packages
            }
        }
        
    def configure_wine_prefix(self, game_path: Path) -> bool:
        """Configure Wine prefix for a game"""
        try:
            wine_prefix = game_path.parent / "wineprefix"
            wine_prefix.mkdir(exist_ok=True)
            
            # Set up Wine prefix
            subprocess.run(
                ["WINEPREFIX=" + str(wine_prefix), "wine", "wineboot"],
                check=True
            )
            
            # Install required components
            subprocess.run(
                ["WINEPREFIX=" + str(wine_prefix), "winetricks", "corefonts"],
                check=True
            )
            
            return True
        except subprocess.CalledProcessError:
            return False 