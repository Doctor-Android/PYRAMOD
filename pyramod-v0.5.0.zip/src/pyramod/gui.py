"""
GUI interface for Pyramod using tkinter with vaporwave theme.
"""

import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from typing import Optional, Dict, List
import json
import subprocess
from datetime import datetime

from .wine_config_manager import WineConfigManager
from .system_compatibility import SystemCompatibilityChecker
from .mod_compatibility import ModCompatibilityChecker
from .mod_installer import ModInstaller
from .mod_manager import ModManager

# Vaporwave color scheme
VAPORWAVE_COLORS = {
    'dark': {
        'bg': '#1a1a2e',
        'fg': '#e94560',
        'accent': '#16213e',
        'text': '#ffffff',
        'button': '#0f3460',
        'button_hover': '#e94560',
        'list_bg': '#16213e',
        'list_fg': '#ffffff',
        'entry_bg': '#16213e',
        'entry_fg': '#ffffff'
    },
    'light': {
        'bg': '#f0f0f0',
        'fg': '#e94560',
        'accent': '#ffffff',
        'text': '#1a1a2e',
        'button': '#0f3460',
        'button_hover': '#e94560',
        'list_bg': '#ffffff',
        'list_fg': '#1a1a2e',
        'entry_bg': '#ffffff',
        'entry_fg': '#1a1a2e'
    }
}

# Supported games
SUPPORTED_GAMES = {
    "The Elder Scrolls V: Skyrim": "skyrim",
    "The Elder Scrolls V: Skyrim Special Edition": "skyrimse",
    "The Elder Scrolls V: Skyrim VR": "skyrimvr",
    "Fallout 4": "fallout4",
    "Fallout 4 VR": "fallout4vr",
    "Fallout: New Vegas": "falloutnv",
    "Fallout 3": "fallout3",
    "The Elder Scrolls IV: Oblivion": "oblivion",
    "The Elder Scrolls III: Morrowind": "morrowind",
    "The Witcher 3: Wild Hunt": "witcher3",
    "Cyberpunk 2077": "cyberpunk2077",
    "Red Dead Redemption 2": "rdr2",
    "Grand Theft Auto V": "gtav",
    "Dark Souls III": "darksouls3",
    "Dark Souls II": "darksouls2",
    "Dark Souls": "darksouls",
    "Sekiro: Shadows Die Twice": "sekiro",
    "Elden Ring": "eldenring"
}

class VaporwaveButton(ttk.Button):
    """Custom button with vaporwave styling."""
    def __init__(self, master, **kwargs):
        super().__init__(master, **kwargs)
        self.bind('<Enter>', self.on_enter)
        self.bind('<Leave>', self.on_leave)
        
    def on_enter(self, e):
        self['style'] = 'Hover.TButton'
        
    def on_leave(self, e):
        self['style'] = 'TButton'

class PyramodGUI:
    """Main window for the Pyramod GUI application."""
    
    def __init__(self, config_dir: str):
        """Initialize the GUI.
        
        Args:
            config_dir: Configuration directory path
        """
        self.config_dir = Path(config_dir)
        self.theme_mode = 'dark'  # Default to dark mode
        
        # Initialize components
        self.wine_config = WineConfigManager(str(self.config_dir))
        self.system_checker = SystemCompatibilityChecker(str(self.config_dir))
        self.mod_checker = ModCompatibilityChecker(str(self.config_dir))
        self.mod_installer = ModInstaller(str(self.config_dir))
        self.mod_manager = ModManager(str(self.config_dir))
        
        # Create main window
        self.root = tk.Tk()
        self.root.title("Pyramod")
        self.root.geometry("1200x800")
        
        # Set up styles
        self.setup_styles()
        
        # Create main container
        self.main_container = ttk.Frame(self.root)
        self.main_container.pack(expand=True, fill='both', padx=10, pady=10)
        
        # Create header
        self.create_header()
        
        # Create notebook (tabbed interface)
        self.notebook = ttk.Notebook(self.main_container)
        self.notebook.pack(expand=True, fill='both', padx=5, pady=5)
        
        # Add tabs
        self.profiles_tab = ttk.Frame(self.notebook)
        self.mods_tab = ttk.Frame(self.notebook)
        self.settings_tab = ttk.Frame(self.notebook)
        
        self.notebook.add(self.profiles_tab, text="Profiles")
        self.notebook.add(self.mods_tab, text="Mods")
        self.notebook.add(self.settings_tab, text="Settings")
        
        # Set up each tab
        self.setup_profiles_tab()
        self.setup_mods_tab()
        self.setup_settings_tab()
        
        # Apply initial theme
        self.apply_theme()
        
    def setup_styles(self):
        """Set up custom styles for the application."""
        style = ttk.Style()
        
        # Configure theme
        style.theme_use('clam')
        
        # Configure colors
        colors = VAPORWAVE_COLORS[self.theme_mode]
        
        # Configure styles
        style.configure('TFrame', background=colors['bg'])
        style.configure('TLabel', background=colors['bg'], foreground=colors['text'])
        style.configure('TButton', 
                       background=colors['button'],
                       foreground=colors['text'],
                       padding=10)
        style.configure('Hover.TButton',
                       background=colors['button_hover'],
                       foreground=colors['text'])
        style.configure('TNotebook', background=colors['bg'])
        style.configure('TNotebook.Tab', 
                       background=colors['accent'],
                       foreground=colors['text'],
                       padding=[10, 5])
        style.configure('TLabelframe', 
                       background=colors['bg'],
                       foreground=colors['text'])
        style.configure('TLabelframe.Label', 
                       background=colors['bg'],
                       foreground=colors['text'])
        style.configure('TCombobox',
                       fieldbackground=colors['entry_bg'],
                       background=colors['button'],
                       foreground=colors['text'])
        style.configure('TEntry',
                       fieldbackground=colors['entry_bg'],
                       foreground=colors['entry_fg'])
        
    def create_header(self):
        """Create the application header."""
        header = ttk.Frame(self.main_container)
        header.pack(fill='x', pady=(0, 10))
        
        # Title
        title = ttk.Label(header, 
                         text="Pyramod",
                         font=('Helvetica', 24, 'bold'))
        title.pack(side='left')
        
        # Theme toggle
        theme_btn = VaporwaveButton(header,
                                  text="Toggle Theme",
                                  command=self.toggle_theme)
        theme_btn.pack(side='right')
        
    def setup_profiles_tab(self):
        """Set up the profiles tab."""
        # Game selection
        game_frame = ttk.LabelFrame(self.profiles_tab, text="Game")
        game_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Label(game_frame, text="Select Game:").pack(side='left', padx=5)
        self.game_combo = ttk.Combobox(game_frame, 
                                     values=list(SUPPORTED_GAMES.keys()),
                                     state='readonly',
                                     width=40)
        self.game_combo.pack(side='left', padx=5)
        self.game_combo.bind('<<ComboboxSelected>>', lambda e: self.refresh_profiles())
        
        # Profile management
        profile_frame = ttk.LabelFrame(self.profiles_tab, text="Profiles")
        profile_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Profile list with scrollbar
        list_frame = ttk.Frame(profile_frame)
        list_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.profile_list = tk.Listbox(list_frame,
                                     yscrollcommand=scrollbar.set,
                                     selectmode='single',
                                     font=('Helvetica', 10))
        self.profile_list.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.profile_list.yview)
        
        # Profile buttons
        button_frame = ttk.Frame(profile_frame)
        button_frame.pack(fill='x', padx=5, pady=5)
        
        VaporwaveButton(button_frame, 
                       text="Create Profile",
                       command=self.create_profile).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Delete Profile",
                       command=self.delete_profile).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Activate Profile",
                       command=self.activate_profile).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Export Profile",
                       command=self.export_profile).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Import Profile",
                       command=self.import_profile).pack(side='left', padx=5)
        
    def setup_mods_tab(self):
        """Set up the mods tab."""
        # Mod list
        mod_frame = ttk.LabelFrame(self.mods_tab, text="Installed Mods")
        mod_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Mod list with scrollbar
        list_frame = ttk.Frame(mod_frame)
        list_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.mod_list = tk.Listbox(list_frame,
                                 yscrollcommand=scrollbar.set,
                                 selectmode='single',
                                 font=('Helvetica', 10))
        self.mod_list.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.mod_list.yview)
        
        # Mod buttons
        button_frame = ttk.Frame(mod_frame)
        button_frame.pack(fill='x', padx=5, pady=5)
        
        VaporwaveButton(button_frame,
                       text="Install Mod",
                       command=self.install_mod).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Uninstall Mod",
                       command=self.uninstall_mod).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Check Compatibility",
                       command=self.check_compatibility).pack(side='left', padx=5)
        VaporwaveButton(button_frame,
                       text="Sort Load Order",
                       command=self.sort_load_order).pack(side='left', padx=5)
        
    def setup_settings_tab(self):
        """Set up the settings tab."""
        # Game path settings
        path_frame = ttk.LabelFrame(self.settings_tab, text="Game Installation Path")
        path_frame.pack(fill='x', padx=5, pady=5)
        
        self.path_var = tk.StringVar()
        path_entry = ttk.Entry(path_frame, textvariable=self.path_var)
        path_entry.pack(side='left', fill='x', expand=True, padx=5, pady=5)
        
        VaporwaveButton(path_frame,
                       text="Browse",
                       command=self.browse_game_path).pack(side='left', padx=5)
        
        # Wine settings
        wine_frame = ttk.LabelFrame(self.settings_tab, text="Wine Configuration")
        wine_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Label(wine_frame, text="Wine Version:").pack(side='left', padx=5)
        self.wine_combo = ttk.Combobox(wine_frame,
                                     values=self.get_wine_versions(),
                                     state='readonly')
        self.wine_combo.pack(side='left', padx=5)
        
        # Advanced settings
        advanced_frame = ttk.LabelFrame(self.settings_tab, text="Advanced Settings")
        advanced_frame.pack(fill='x', padx=5, pady=5)
        
        # Add checkboxes for various options
        self.auto_sort_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(advanced_frame,
                       text="Auto-sort load order",
                       variable=self.auto_sort_var).pack(anchor='w', padx=5, pady=2)
        
        self.auto_backup_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(advanced_frame,
                       text="Auto-backup profiles",
                       variable=self.auto_backup_var).pack(anchor='w', padx=5, pady=2)
        
        self.check_updates_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(advanced_frame,
                       text="Check for updates",
                       variable=self.check_updates_var).pack(anchor='w', padx=5, pady=2)
        
    def get_wine_versions(self) -> List[str]:
        """Get list of available Wine versions.
        
        Returns:
            List of Wine version strings
        """
        versions = ["System Wine"]
        
        # Check for Proton versions
        steam_path = Path.home() / ".steam" / "steam" / "steamapps" / "common"
        if steam_path.exists():
            for proton in steam_path.glob("Proton*"):
                versions.append(f"Proton: {proton.name}")
        
        # Check for custom Wine versions
        wine_path = Path.home() / ".wine"
        if wine_path.exists():
            versions.append("Custom Wine")
        
        return versions
        
    def toggle_theme(self):
        """Toggle between light and dark themes."""
        self.theme_mode = 'light' if self.theme_mode == 'dark' else 'dark'
        self.apply_theme()
        
    def apply_theme(self):
        """Apply the current theme to all widgets."""
        self.setup_styles()
        
        # Update widget colors
        colors = VAPORWAVE_COLORS[self.theme_mode]
        
        # Update listboxes
        self.profile_list.configure(
            bg=colors['list_bg'],
            fg=colors['list_fg'],
            selectbackground=colors['button_hover'],
            selectforeground=colors['text']
        )
        
        self.mod_list.configure(
            bg=colors['list_bg'],
            fg=colors['list_fg'],
            selectbackground=colors['button_hover'],
            selectforeground=colors['text']
        )
        
        # Update root window
        self.root.configure(bg=colors['bg'])
        
    def refresh_profiles(self):
        """Refresh the profile list."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        if not game:
            return
            
        profiles = self.mod_manager.list_profiles(game)
        self.profile_list.delete(0, tk.END)
        for profile in profiles:
            self.profile_list.insert(tk.END, f"{profile['name']} {'(active)' if profile['active'] else ''}")
            
    def create_profile(self):
        """Create a new profile."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        if not game:
            messagebox.showwarning("Warning", "Please select a game first")
            return
            
        name = tk.simpledialog.askstring("Create Profile", "Enter profile name:")
        if name:
            if self.mod_manager.create_profile(game, name, name):
                self.refresh_profiles()
            else:
                messagebox.showerror("Error", "Failed to create profile")
                
    def delete_profile(self):
        """Delete the selected profile."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        name = self.profile_list.get(selection[0]).split(" (active)")[0]
        if self.mod_manager.delete_profile(game, name):
            self.refresh_profiles()
        else:
            messagebox.showerror("Error", "Failed to delete profile")
            
    def activate_profile(self):
        """Activate the selected profile."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        name = self.profile_list.get(selection[0]).split(" (active)")[0]
        if self.mod_manager.activate_profile(game, name):
            self.refresh_profiles()
        else:
            messagebox.showerror("Error", "Failed to activate profile")
            
    def export_profile(self):
        """Export the selected profile."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        name = self.profile_list.get(selection[0]).split(" (active)")[0]
        filename = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json")],
            initialfile=f"{name}_profile.json"
        )
        if filename:
            if self.mod_manager.export_profile(game, name, filename):
                messagebox.showinfo("Success", "Profile exported successfully")
            else:
                messagebox.showerror("Error", "Failed to export profile")
                
    def import_profile(self):
        """Import a profile."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        if not game:
            messagebox.showwarning("Warning", "Please select a game first")
            return
            
        filename = filedialog.askopenfilename(
            filetypes=[("JSON files", "*.json")]
        )
        if filename:
            if self.mod_manager.import_profile(filename):
                self.refresh_profiles()
                messagebox.showinfo("Success", "Profile imported successfully")
            else:
                messagebox.showerror("Error", "Failed to import profile")
                
    def install_mod(self):
        """Install a new mod."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        profile = self.profile_list.get(selection[0]).split(" (active)")[0]
        mod_id = tk.simpledialog.askstring("Install Mod", "Enter mod ID:")
        if mod_id:
            if self.mod_manager.add_mod_to_profile(game, profile, mod_id):
                self.refresh_mods()
            else:
                messagebox.showerror("Error", "Failed to install mod")
                
    def uninstall_mod(self):
        """Uninstall the selected mod."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        profile_selection = self.profile_list.curselection()
        mod_selection = self.mod_list.curselection()
        
        if not profile_selection or not mod_selection:
            messagebox.showwarning("Warning", "Please select both a profile and a mod")
            return
            
        profile = self.profile_list.get(profile_selection[0]).split(" (active)")[0]
        mod_id = self.mod_list.get(mod_selection[0])
        
        if self.mod_manager.remove_mod_from_profile(game, profile, mod_id):
            self.refresh_mods()
        else:
            messagebox.showerror("Error", "Failed to uninstall mod")
            
    def check_compatibility(self):
        """Check mod compatibility."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        profile = self.profile_list.get(selection[0]).split(" (active)")[0]
        results = self.mod_manager.check_profile_compatibility(game, profile)
        
        if results["compatible"]:
            messagebox.showinfo("Compatibility", "All mods are compatible!")
        else:
            msg = "Compatibility issues found:\n\n" + "\n".join(results["warnings"])
            messagebox.showwarning("Compatibility", msg)
            
    def sort_load_order(self):
        """Sort the load order of mods."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            messagebox.showwarning("Warning", "Please select a profile first")
            return
            
        profile = self.profile_list.get(selection[0]).split(" (active)")[0]
        if self.mod_manager.sort_load_order(game, profile):
            self.refresh_mods()
            messagebox.showinfo("Success", "Load order sorted successfully")
        else:
            messagebox.showerror("Error", "Failed to sort load order")
            
    def browse_game_path(self):
        """Open file dialog to select game path."""
        path = filedialog.askdirectory(title="Select Game Directory")
        if path:
            self.path_var.set(path)
            game = SUPPORTED_GAMES.get(self.game_combo.get())
            if game:
                self.mod_installer.set_game_path(game, path)
            
    def refresh_mods(self):
        """Refresh the mod list."""
        game = SUPPORTED_GAMES.get(self.game_combo.get())
        selection = self.profile_list.curselection()
        if not selection:
            return
            
        profile = self.profile_list.get(selection[0]).split(" (active)")[0]
        mods = self.mod_manager.get_profile_mods(game, profile)
        self.mod_list.delete(0, tk.END)
        for mod_id in mods:
            self.mod_list.insert(tk.END, mod_id)
            
    def run(self):
        """Run the GUI application."""
        self.root.mainloop()

def run_gui(config_dir: str):
    """Run the GUI application.
    
    Args:
        config_dir: Configuration directory path
    """
    app = PyramodGUI(config_dir)
    app.run() 