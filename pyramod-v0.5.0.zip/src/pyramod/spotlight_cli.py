#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from author_spotlight import AuthorSpotlight

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the author spotlight CLI."""
    parser = argparse.ArgumentParser(
        description="Mod Author Spotlight CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "spotlight"),
        help="Directory to store spotlight data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Register author command
    register_parser = subparsers.add_parser("register", help="Register a new author")
    register_parser.add_argument("username", help="Author username")
    register_parser.add_argument("display_name", help="Author display name")
    register_parser.add_argument("bio", help="Author biography")
    register_parser.add_argument("--social-links", help="JSON string of social media links")
    register_parser.add_argument("--avatar", help="Path to author avatar image")

    # Update author command
    update_parser = subparsers.add_parser("update-author", help="Update author information")
    update_parser.add_argument("author_id", help="Author ID")
    update_parser.add_argument("--display-name", help="New display name")
    update_parser.add_argument("--bio", help="New biography")
    update_parser.add_argument("--social-links", help="New JSON string of social media links")
    update_parser.add_argument("--avatar", help="New avatar image path")

    # Add mod command
    add_mod_parser = subparsers.add_parser("add-mod", help="Add a mod to author's profile")
    add_mod_parser.add_argument("author_id", help="Author ID")
    add_mod_parser.add_argument("mod_data", help="JSON string of mod data")

    # Add award command
    add_award_parser = subparsers.add_parser("add-award", help="Add an award to author's profile")
    add_award_parser.add_argument("author_id", help="Author ID")
    add_award_parser.add_argument("award_data", help="JSON string of award data")

    # Create spotlight command
    create_parser = subparsers.add_parser("create", help="Create a spotlight feature")
    create_parser.add_argument("author_id", help="Author ID")
    create_parser.add_argument("title", help="Spotlight title")
    create_parser.add_argument("content", help="Spotlight content (markdown)")
    create_parser.add_argument("--featured-mods", help="Comma-separated list of featured mod IDs")

    # Update spotlight command
    update_spotlight_parser = subparsers.add_parser("update-spotlight", help="Update a spotlight")
    update_spotlight_parser.add_argument("spotlight_id", help="Spotlight ID")
    update_spotlight_parser.add_argument("--title", help="New title")
    update_spotlight_parser.add_argument("--content", help="New content (markdown)")
    update_spotlight_parser.add_argument("--featured-mods", help="New comma-separated list of mod IDs")
    update_spotlight_parser.add_argument("--status", help="New status")

    # Delete spotlight command
    delete_parser = subparsers.add_parser("delete", help="Delete a spotlight")
    delete_parser.add_argument("spotlight_id", help="Spotlight ID")

    # List spotlights command
    list_parser = subparsers.add_parser("list", help="List spotlights")
    list_parser.add_argument("--author", help="Filter by author ID")
    list_parser.add_argument("--status", help="Filter by status")

    # Get author info command
    info_parser = subparsers.add_parser("info", help="Get author information")
    info_parser.add_argument("author_id", help="Author ID")

    # Get spotlight info command
    spotlight_info_parser = subparsers.add_parser("spotlight-info", help="Get spotlight information")
    spotlight_info_parser.add_argument("spotlight_id", help="Spotlight ID")

    # Update stats command
    stats_parser = subparsers.add_parser("update-stats", help="Update author statistics")
    stats_parser.add_argument("author_id", help="Author ID")
    stats_parser.add_argument("stats", help="JSON string of statistics")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("spotlight_cli")
    spotlight = AuthorSpotlight(args.config_dir)

    try:
        if args.command == "register":
            social_links = eval(args.social_links) if args.social_links else None
            author_id = spotlight.register_author(
                username=args.username,
                display_name=args.display_name,
                bio=args.bio,
                social_links=social_links,
                avatar_path=args.avatar
            )
            if author_id:
                logger.info(f"Successfully registered author: {author_id}")
            else:
                logger.error("Failed to register author")
                sys.exit(1)

        elif args.command == "update-author":
            updates = {}
            if args.display_name:
                updates["display_name"] = args.display_name
            if args.bio:
                updates["bio"] = args.bio
            if args.social_links:
                updates["social_links"] = eval(args.social_links)
            if args.avatar:
                updates["avatar_path"] = args.avatar

            result = spotlight.update_author(args.author_id, updates)
            if result:
                logger.info("Successfully updated author")
            else:
                logger.error("Failed to update author")
                sys.exit(1)

        elif args.command == "add-mod":
            mod_data = eval(args.mod_data)
            result = spotlight.add_mod(args.author_id, mod_data)
            if result:
                logger.info("Successfully added mod")
            else:
                logger.error("Failed to add mod")
                sys.exit(1)

        elif args.command == "add-award":
            award_data = eval(args.award_data)
            result = spotlight.add_award(args.author_id, award_data)
            if result:
                logger.info("Successfully added award")
            else:
                logger.error("Failed to add award")
                sys.exit(1)

        elif args.command == "create":
            featured_mods = args.featured_mods.split(",") if args.featured_mods else None
            spotlight_id = spotlight.create_spotlight(
                args.author_id,
                args.title,
                args.content,
                featured_mods
            )
            if spotlight_id:
                logger.info(f"Successfully created spotlight: {spotlight_id}")
            else:
                logger.error("Failed to create spotlight")
                sys.exit(1)

        elif args.command == "update-spotlight":
            updates = {}
            if args.title:
                updates["title"] = args.title
            if args.content:
                updates["content"] = args.content
            if args.featured_mods:
                updates["featured_mods"] = args.featured_mods.split(",")
            if args.status:
                updates["status"] = args.status

            result = spotlight.update_spotlight(args.spotlight_id, updates)
            if result:
                logger.info("Successfully updated spotlight")
            else:
                logger.error("Failed to update spotlight")
                sys.exit(1)

        elif args.command == "delete":
            result = spotlight.delete_spotlight(args.spotlight_id)
            if result:
                logger.info("Successfully deleted spotlight")
            else:
                logger.error("Failed to delete spotlight")
                sys.exit(1)

        elif args.command == "list":
            spotlights = spotlight.list_spotlights(
                author_id=args.author,
                status=args.status
            )
            if spotlights:
                print("\nSpotlights:")
                for s in spotlights:
                    print(f"\nID: {s['id']}")
                    print(f"Title: {s['title']}")
                    print(f"Author: {s['author_id']}")
                    print(f"Created: {s['created_at']}")
                    print(f"Status: {s['status']}")
            else:
                print("No spotlights found")

        elif args.command == "info":
            author = spotlight.get_author(args.author_id)
            if author:
                print(f"\nAuthor information for {args.author_id}:")
                print(f"Username: {author['username']}")
                print(f"Display Name: {author['display_name']}")
                print(f"Bio: {author['bio']}")
                print("\nSocial Links:")
                for platform, url in author['social_links'].items():
                    print(f"- {platform}: {url}")
                print(f"\nMods: {len(author['mods'])}")
                print(f"Awards: {len(author['awards'])}")
                print("\nStats:")
                for stat, value in author['stats'].items():
                    print(f"- {stat}: {value}")
            else:
                logger.error(f"Author not found: {args.author_id}")
                sys.exit(1)

        elif args.command == "spotlight-info":
            spotlight_info = spotlight.get_spotlight(args.spotlight_id)
            if spotlight_info:
                print(f"\nSpotlight information for {args.spotlight_id}:")
                print(f"Title: {spotlight_info['title']}")
                print(f"Author: {spotlight_info['author_id']}")
                print(f"Content: {spotlight_info['content']}")
                print(f"Featured Mods: {', '.join(spotlight_info['featured_mods'])}")
                print(f"Created: {spotlight_info['created_at']}")
                print(f"Status: {spotlight_info['status']}")
            else:
                logger.error(f"Spotlight not found: {args.spotlight_id}")
                sys.exit(1)

        elif args.command == "update-stats":
            stats = eval(args.stats)
            result = spotlight.update_author_stats(args.author_id, stats)
            if result:
                logger.info("Successfully updated stats")
            else:
                logger.error("Failed to update stats")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 