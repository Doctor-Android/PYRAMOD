"""
Wine configuration manager for Pyramod.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger("pyramod.wine_config")

class WineConfigManager:
    """Manages Wine/Proton configuration for games."""
    
    def __init__(self, config_dir: str):
        """Initialize the Wine configuration manager.
        
        Args:
            config_dir: Configuration directory
        """
        self.config_dir = Path(config_dir)
        self.wine_config_dir = self.config_dir / "wine"
        self.wine_config_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.wine_config_dir / "config.json"
        if not self.config_file.exists():
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default Wine configuration."""
        default_config = {
            "wine_prefix": str(self.wine_config_dir / "prefix"),
            "dxvk_version": "latest",
            "esync": True,
            "fsync": True,
            "dxvk_nvapi": True,
            "dxvk_d3d11": True,
            "dxvk_d3d9": True,
            "dxvk_d3d12": True,
            "vulkan_layer": True,
            "vulkan_icd": "radv",
            "wine_version": "proton",
            "proton_version": "latest",
            "wine_arch": "win64",
            "wine_debug": "err",
            "wine_loader": "wine64",
            "wine_server": "wineserver",
            "wine_bin": "wine",
            "wine_path": "/usr/bin/wine",
            "wine_server_path": "/usr/bin/wineserver",
            "wine_loader_path": "/usr/bin/wine64",
            "wine_config_path": "/usr/bin/winecfg",
            "wine_regedit_path": "/usr/bin/regedit",
            "wine_taskmgr_path": "/usr/bin/wine taskmgr",
            "wine_uninstaller_path": "/usr/bin/wine uninstaller",
            "wine_winetricks_path": "/usr/bin/winetricks",
            "wine_dxvk_path": str(self.wine_config_dir / "dxvk"),
            "wine_dxvk_nvapi_path": str(self.wine_config_dir / "dxvk-nvapi"),
            "wine_dxvk_d3d11_path": str(self.wine_config_dir / "dxvk-d3d11"),
            "wine_dxvk_d3d9_path": str(self.wine_config_dir / "dxvk-d3d9"),
            "wine_dxvk_d3d12_path": str(self.wine_config_dir / "dxvk-d3d12"),
            "wine_vulkan_layer_path": str(self.wine_config_dir / "vulkan-layer"),
            "wine_vulkan_icd_path": str(self.wine_config_dir / "vulkan-icd"),
            "wine_proton_path": str(self.wine_config_dir / "proton"),
            "wine_proton_version_path": str(self.wine_config_dir / "proton-version"),
            "wine_proton_latest_path": str(self.wine_config_dir / "proton-latest"),
            "wine_proton_ge_path": str(self.wine_config_dir / "proton-ge"),
            "wine_proton_ge_version_path": str(self.wine_config_dir / "proton-ge-version"),
            "wine_proton_ge_latest_path": str(self.wine_config_dir / "proton-ge-latest"),
            "wine_proton_ge_custom_path": str(self.wine_config_dir / "proton-ge-custom"),
            "wine_proton_ge_custom_version_path": str(self.wine_config_dir / "proton-ge-custom-version"),
            "wine_proton_ge_custom_latest_path": str(self.wine_config_dir / "proton-ge-custom-latest"),
            "wine_proton_ge_custom_install_path": str(self.wine_config_dir / "proton-ge-custom-install"),
            "wine_proton_ge_custom_install_version_path": str(self.wine_config_dir / "proton-ge-custom-install-version"),
            "wine_proton_ge_custom_install_latest_path": str(self.wine_config_dir / "proton-ge-custom-install-latest"),
            "wine_proton_ge_custom_install_ge_path": str(self.wine_config_dir / "proton-ge-custom-install-ge"),
            "wine_proton_ge_custom_install_ge_version_path": str(self.wine_config_dir / "proton-ge-custom-install-ge-version"),
            "wine_proton_ge_custom_install_ge_latest_path": str(self.wine_config_dir / "proton-ge-custom-install-ge-latest"),
            "wine_proton_ge_custom_install_ge_custom_path": str(self.wine_config_dir / "proton-ge-custom-install-ge-custom"),
            "wine_proton_ge_custom_install_ge_custom_version_path": str(self.wine_config_dir / "proton-ge-custom-install-ge-custom-version"),
            "wine_proton_ge_custom_install_ge_custom_latest_path": str(self.wine_config_dir / "proton-ge-custom-install-ge-custom-latest"),
        }
        
        with open(self.config_file, "w") as f:
            json.dump(default_config, f, indent=4)
    
    def get_config(self) -> Dict[str, Union[str, bool]]:
        """Get the current Wine configuration.
        
        Returns:
            Current Wine configuration
        """
        with open(self.config_file, "r") as f:
            return json.load(f)
    
    def update_config(self, config: Dict[str, Union[str, bool]]):
        """Update the Wine configuration.
        
        Args:
            config: New Wine configuration
        """
        current_config = self.get_config()
        current_config.update(config)
        
        with open(self.config_file, "w") as f:
            json.dump(current_config, f, indent=4)
    
    def get_wine_prefix(self) -> str:
        """Get the Wine prefix path.
        
        Returns:
            Wine prefix path
        """
        config = self.get_config()
        return config["wine_prefix"]
    
    def set_wine_prefix(self, prefix: str):
        """Set the Wine prefix path.
        
        Args:
            prefix: Wine prefix path
        """
        self.update_config({"wine_prefix": prefix})
    
    def get_dxvk_version(self) -> str:
        """Get the DXVK version.
        
        Returns:
            DXVK version
        """
        config = self.get_config()
        return config["dxvk_version"]
    
    def set_dxvk_version(self, version: str):
        """Set the DXVK version.
        
        Args:
            version: DXVK version
        """
        self.update_config({"dxvk_version": version})
    
    def is_esync_enabled(self) -> bool:
        """Check if ESync is enabled.
        
        Returns:
            True if ESync is enabled, False otherwise
        """
        config = self.get_config()
        return config["esync"]
    
    def set_esync(self, enabled: bool):
        """Enable or disable ESync.
        
        Args:
            enabled: Whether to enable ESync
        """
        self.update_config({"esync": enabled})
    
    def is_fsync_enabled(self) -> bool:
        """Check if FSync is enabled.
        
        Returns:
            True if FSync is enabled, False otherwise
        """
        config = self.get_config()
        return config["fsync"]
    
    def set_fsync(self, enabled: bool):
        """Enable or disable FSync.
        
        Args:
            enabled: Whether to enable FSync
        """
        self.update_config({"fsync": enabled})
    
    def is_dxvk_nvapi_enabled(self) -> bool:
        """Check if DXVK NVAPI is enabled.
        
        Returns:
            True if DXVK NVAPI is enabled, False otherwise
        """
        config = self.get_config()
        return config["dxvk_nvapi"]
    
    def set_dxvk_nvapi(self, enabled: bool):
        """Enable or disable DXVK NVAPI.
        
        Args:
            enabled: Whether to enable DXVK NVAPI
        """
        self.update_config({"dxvk_nvapi": enabled})
    
    def is_dxvk_d3d11_enabled(self) -> bool:
        """Check if DXVK D3D11 is enabled.
        
        Returns:
            True if DXVK D3D11 is enabled, False otherwise
        """
        config = self.get_config()
        return config["dxvk_d3d11"]
    
    def set_dxvk_d3d11(self, enabled: bool):
        """Enable or disable DXVK D3D11.
        
        Args:
            enabled: Whether to enable DXVK D3D11
        """
        self.update_config({"dxvk_d3d11": enabled})
    
    def is_dxvk_d3d9_enabled(self) -> bool:
        """Check if DXVK D3D9 is enabled.
        
        Returns:
            True if DXVK D3D9 is enabled, False otherwise
        """
        config = self.get_config()
        return config["dxvk_d3d9"]
    
    def set_dxvk_d3d9(self, enabled: bool):
        """Enable or disable DXVK D3D9.
        
        Args:
            enabled: Whether to enable DXVK D3D9
        """
        self.update_config({"dxvk_d3d9": enabled})
    
    def is_dxvk_d3d12_enabled(self) -> bool:
        """Check if DXVK D3D12 is enabled.
        
        Returns:
            True if DXVK D3D12 is enabled, False otherwise
        """
        config = self.get_config()
        return config["dxvk_d3d12"]
    
    def set_dxvk_d3d12(self, enabled: bool):
        """Enable or disable DXVK D3D12.
        
        Args:
            enabled: Whether to enable DXVK D3D12
        """
        self.update_config({"dxvk_d3d12": enabled})
    
    def is_vulkan_layer_enabled(self) -> bool:
        """Check if Vulkan layer is enabled.
        
        Returns:
            True if Vulkan layer is enabled, False otherwise
        """
        config = self.get_config()
        return config["vulkan_layer"]
    
    def set_vulkan_layer(self, enabled: bool):
        """Enable or disable Vulkan layer.
        
        Args:
            enabled: Whether to enable Vulkan layer
        """
        self.update_config({"vulkan_layer": enabled})
    
    def get_vulkan_icd(self) -> str:
        """Get the Vulkan ICD.
        
        Returns:
            Vulkan ICD
        """
        config = self.get_config()
        return config["vulkan_icd"]
    
    def set_vulkan_icd(self, icd: str):
        """Set the Vulkan ICD.
        
        Args:
            icd: Vulkan ICD
        """
        self.update_config({"vulkan_icd": icd})
    
    def get_wine_version(self) -> str:
        """Get the Wine version.
        
        Returns:
            Wine version
        """
        config = self.get_config()
        return config["wine_version"]
    
    def set_wine_version(self, version: str):
        """Set the Wine version.
        
        Args:
            version: Wine version
        """
        self.update_config({"wine_version": version})
    
    def get_proton_version(self) -> str:
        """Get the Proton version.
        
        Returns:
            Proton version
        """
        config = self.get_config()
        return config["proton_version"]
    
    def set_proton_version(self, version: str):
        """Set the Proton version.
        
        Args:
            version: Proton version
        """
        self.update_config({"proton_version": version})
    
    def get_wine_arch(self) -> str:
        """Get the Wine architecture.
        
        Returns:
            Wine architecture
        """
        config = self.get_config()
        return config["wine_arch"]
    
    def set_wine_arch(self, arch: str):
        """Set the Wine architecture.
        
        Args:
            arch: Wine architecture
        """
        self.update_config({"wine_arch": arch})
    
    def get_wine_debug(self) -> str:
        """Get the Wine debug level.
        
        Returns:
            Wine debug level
        """
        config = self.get_config()
        return config["wine_debug"]
    
    def set_wine_debug(self, debug: str):
        """Set the Wine debug level.
        
        Args:
            debug: Wine debug level
        """
        self.update_config({"wine_debug": debug})
    
    def get_wine_loader(self) -> str:
        """Get the Wine loader.
        
        Returns:
            Wine loader
        """
        config = self.get_config()
        return config["wine_loader"]
    
    def set_wine_loader(self, loader: str):
        """Set the Wine loader.
        
        Args:
            loader: Wine loader
        """
        self.update_config({"wine_loader": loader})
    
    def get_wine_server(self) -> str:
        """Get the Wine server.
        
        Returns:
            Wine server
        """
        config = self.get_config()
        return config["wine_server"]
    
    def set_wine_server(self, server: str):
        """Set the Wine server.
        
        Args:
            server: Wine server
        """
        self.update_config({"wine_server": server})
    
    def get_wine_bin(self) -> str:
        """Get the Wine binary.
        
        Returns:
            Wine binary
        """
        config = self.get_config()
        return config["wine_bin"]
    
    def set_wine_bin(self, bin: str):
        """Set the Wine binary.
        
        Args:
            bin: Wine binary
        """
        self.update_config({"wine_bin": bin})
    
    def get_wine_path(self) -> str:
        """Get the Wine path.
        
        Returns:
            Wine path
        """
        config = self.get_config()
        return config["wine_path"]
    
    def set_wine_path(self, path: str):
        """Set the Wine path.
        
        Args:
            path: Wine path
        """
        self.update_config({"wine_path": path})
    
    def get_wine_server_path(self) -> str:
        """Get the Wine server path.
        
        Returns:
            Wine server path
        """
        config = self.get_config()
        return config["wine_server_path"]
    
    def set_wine_server_path(self, path: str):
        """Set the Wine server path.
        
        Args:
            path: Wine server path
        """
        self.update_config({"wine_server_path": path})
    
    def get_wine_loader_path(self) -> str:
        """Get the Wine loader path.
        
        Returns:
            Wine loader path
        """
        config = self.get_config()
        return config["wine_loader_path"]
    
    def set_wine_loader_path(self, path: str):
        """Set the Wine loader path.
        
        Args:
            path: Wine loader path
        """
        self.update_config({"wine_loader_path": path})
    
    def get_wine_config_path(self) -> str:
        """Get the Wine config path.
        
        Returns:
            Wine config path
        """
        config = self.get_config()
        return config["wine_config_path"]
    
    def set_wine_config_path(self, path: str):
        """Set the Wine config path.
        
        Args:
            path: Wine config path
        """
        self.update_config({"wine_config_path": path})
    
    def get_wine_regedit_path(self) -> str:
        """Get the Wine regedit path.
        
        Returns:
            Wine regedit path
        """
        config = self.get_config()
        return config["wine_regedit_path"]
    
    def set_wine_regedit_path(self, path: str):
        """Set the Wine regedit path.
        
        Args:
            path: Wine regedit path
        """
        self.update_config({"wine_regedit_path": path})
    
    def get_wine_taskmgr_path(self) -> str:
        """Get the Wine taskmgr path.
        
        Returns:
            Wine taskmgr path
        """
        config = self.get_config()
        return config["wine_taskmgr_path"]
    
    def set_wine_taskmgr_path(self, path: str):
        """Set the Wine taskmgr path.
        
        Args:
            path: Wine taskmgr path
        """
        self.update_config({"wine_taskmgr_path": path})
    
    def get_wine_uninstaller_path(self) -> str:
        """Get the Wine uninstaller path.
        
        Returns:
            Wine uninstaller path
        """
        config = self.get_config()
        return config["wine_uninstaller_path"]
    
    def set_wine_uninstaller_path(self, path: str):
        """Set the Wine uninstaller path.
        
        Args:
            path: Wine uninstaller path
        """
        self.update_config({"wine_uninstaller_path": path})
    
    def get_wine_winetricks_path(self) -> str:
        """Get the Wine winetricks path.
        
        Returns:
            Wine winetricks path
        """
        config = self.get_config()
        return config["wine_winetricks_path"]
    
    def set_wine_winetricks_path(self, path: str):
        """Set the Wine winetricks path.
        
        Args:
            path: Wine winetricks path
        """
        self.update_config({"wine_winetricks_path": path})
    
    def get_wine_dxvk_path(self) -> str:
        """Get the Wine DXVK path.
        
        Returns:
            Wine DXVK path
        """
        config = self.get_config()
        return config["wine_dxvk_path"]
    
    def set_wine_dxvk_path(self, path: str):
        """Set the Wine DXVK path.
        
        Args:
            path: Wine DXVK path
        """
        self.update_config({"wine_dxvk_path": path})
    
    def get_wine_dxvk_nvapi_path(self) -> str:
        """Get the Wine DXVK NVAPI path.
        
        Returns:
            Wine DXVK NVAPI path
        """
        config = self.get_config()
        return config["wine_dxvk_nvapi_path"]
    
    def set_wine_dxvk_nvapi_path(self, path: str):
        """Set the Wine DXVK NVAPI path.
        
        Args:
            path: Wine DXVK NVAPI path
        """
        self.update_config({"wine_dxvk_nvapi_path": path})
    
    def get_wine_dxvk_d3d11_path(self) -> str:
        """Get the Wine DXVK D3D11 path.
        
        Returns:
            Wine DXVK D3D11 path
        """
        config = self.get_config()
        return config["wine_dxvk_d3d11_path"]
    
    def set_wine_dxvk_d3d11_path(self, path: str):
        """Set the Wine DXVK D3D11 path.
        
        Args:
            path: Wine DXVK D3D11 path
        """
        self.update_config({"wine_dxvk_d3d11_path": path})
    
    def get_wine_dxvk_d3d9_path(self) -> str:
        """Get the Wine DXVK D3D9 path.
        
        Returns:
            Wine DXVK D3D9 path
        """
        config = self.get_config()
        return config["wine_dxvk_d3d9_path"]
    
    def set_wine_dxvk_d3d9_path(self, path: str):
        """Set the Wine DXVK D3D9 path.
        
        Args:
            path: Wine DXVK D3D9 path
        """
        self.update_config({"wine_dxvk_d3d9_path": path})
    
    def get_wine_dxvk_d3d12_path(self) -> str:
        """Get the Wine DXVK D3D12 path.
        
        Returns:
            Wine DXVK D3D12 path
        """
        config = self.get_config()
        return config["wine_dxvk_d3d12_path"]
    
    def set_wine_dxvk_d3d12_path(self, path: str):
        """Set the Wine DXVK D3D12 path.
        
        Args:
            path: Wine DXVK D3D12 path
        """
        self.update_config({"wine_dxvk_d3d12_path": path})
    
    def get_wine_vulkan_layer_path(self) -> str:
        """Get the Wine Vulkan layer path.
        
        Returns:
            Wine Vulkan layer path
        """
        config = self.get_config()
        return config["wine_vulkan_layer_path"]
    
    def set_wine_vulkan_layer_path(self, path: str):
        """Set the Wine Vulkan layer path.
        
        Args:
            path: Wine Vulkan layer path
        """
        self.update_config({"wine_vulkan_layer_path": path})
    
    def get_wine_vulkan_icd_path(self) -> str:
        """Get the Wine Vulkan ICD path.
        
        Returns:
            Wine Vulkan ICD path
        """
        config = self.get_config()
        return config["wine_vulkan_icd_path"]
    
    def set_wine_vulkan_icd_path(self, path: str):
        """Set the Wine Vulkan ICD path.
        
        Args:
            path: Wine Vulkan ICD path
        """
        self.update_config({"wine_vulkan_icd_path": path})
    
    def get_wine_proton_path(self) -> str:
        """Get the Wine Proton path.
        
        Returns:
            Wine Proton path
        """
        config = self.get_config()
        return config["wine_proton_path"]
    
    def set_wine_proton_path(self, path: str):
        """Set the Wine Proton path.
        
        Args:
            path: Wine Proton path
        """
        self.update_config({"wine_proton_path": path})
    
    def get_wine_proton_version_path(self) -> str:
        """Get the Wine Proton version path.
        
        Returns:
            Wine Proton version path
        """
        config = self.get_config()
        return config["wine_proton_version_path"]
    
    def set_wine_proton_version_path(self, path: str):
        """Set the Wine Proton version path.
        
        Args:
            path: Wine Proton version path
        """
        self.update_config({"wine_proton_version_path": path})
    
    def get_wine_proton_latest_path(self) -> str:
        """Get the Wine Proton latest path.
        
        Returns:
            Wine Proton latest path
        """
        config = self.get_config()
        return config["wine_proton_latest_path"]
    
    def set_wine_proton_latest_path(self, path: str):
        """Set the Wine Proton latest path.
        
        Args:
            path: Wine Proton latest path
        """
        self.update_config({"wine_proton_latest_path": path})
    
    def get_wine_proton_ge_path(self) -> str:
        """Get the Wine Proton GE path.
        
        Returns:
            Wine Proton GE path
        """
        config = self.get_config()
        return config["wine_proton_ge_path"]
    
    def set_wine_proton_ge_path(self, path: str):
        """Set the Wine Proton GE path.
        
        Args:
            path: Wine Proton GE path
        """
        self.update_config({"wine_proton_ge_path": path})
    
    def get_wine_proton_ge_version_path(self) -> str:
        """Get the Wine Proton GE version path.
        
        Returns:
            Wine Proton GE version path
        """
        config = self.get_config()
        return config["wine_proton_ge_version_path"]
    
    def set_wine_proton_ge_version_path(self, path: str):
        """Set the Wine Proton GE version path.
        
        Args:
            path: Wine Proton GE version path
        """
        self.update_config({"wine_proton_ge_version_path": path})
    
    def get_wine_proton_ge_latest_path(self) -> str:
        """Get the Wine Proton GE latest path.
        
        Returns:
            Wine Proton GE latest path
        """
        config = self.get_config()
        return config["wine_proton_ge_latest_path"]
    
    def set_wine_proton_ge_latest_path(self, path: str):
        """Set the Wine Proton GE latest path.
        
        Args:
            path: Wine Proton GE latest path
        """
        self.update_config({"wine_proton_ge_latest_path": path})
    
    def get_wine_proton_ge_custom_path(self) -> str:
        """Get the Wine Proton GE custom path.
        
        Returns:
            Wine Proton GE custom path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_path"]
    
    def set_wine_proton_ge_custom_path(self, path: str):
        """Set the Wine Proton GE custom path.
        
        Args:
            path: Wine Proton GE custom path
        """
        self.update_config({"wine_proton_ge_custom_path": path})
    
    def get_wine_proton_ge_custom_version_path(self) -> str:
        """Get the Wine Proton GE custom version path.
        
        Returns:
            Wine Proton GE custom version path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_version_path"]
    
    def set_wine_proton_ge_custom_version_path(self, path: str):
        """Set the Wine Proton GE custom version path.
        
        Args:
            path: Wine Proton GE custom version path
        """
        self.update_config({"wine_proton_ge_custom_version_path": path})
    
    def get_wine_proton_ge_custom_latest_path(self) -> str:
        """Get the Wine Proton GE custom latest path.
        
        Returns:
            Wine Proton GE custom latest path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_latest_path"]
    
    def set_wine_proton_ge_custom_latest_path(self, path: str):
        """Set the Wine Proton GE custom latest path.
        
        Args:
            path: Wine Proton GE custom latest path
        """
        self.update_config({"wine_proton_ge_custom_latest_path": path})
    
    def get_wine_proton_ge_custom_install_path(self) -> str:
        """Get the Wine Proton GE custom install path.
        
        Returns:
            Wine Proton GE custom install path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_path"]
    
    def set_wine_proton_ge_custom_install_path(self, path: str):
        """Set the Wine Proton GE custom install path.
        
        Args:
            path: Wine Proton GE custom install path
        """
        self.update_config({"wine_proton_ge_custom_install_path": path})
    
    def get_wine_proton_ge_custom_install_version_path(self) -> str:
        """Get the Wine Proton GE custom install version path.
        
        Returns:
            Wine Proton GE custom install version path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_version_path"]
    
    def set_wine_proton_ge_custom_install_version_path(self, path: str):
        """Set the Wine Proton GE custom install version path.
        
        Args:
            path: Wine Proton GE custom install version path
        """
        self.update_config({"wine_proton_ge_custom_install_version_path": path})
    
    def get_wine_proton_ge_custom_install_latest_path(self) -> str:
        """Get the Wine Proton GE custom install latest path.
        
        Returns:
            Wine Proton GE custom install latest path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_latest_path"]
    
    def set_wine_proton_ge_custom_install_latest_path(self, path: str):
        """Set the Wine Proton GE custom install latest path.
        
        Args:
            path: Wine Proton GE custom install latest path
        """
        self.update_config({"wine_proton_ge_custom_install_latest_path": path})
    
    def get_wine_proton_ge_custom_install_ge_path(self) -> str:
        """Get the Wine Proton GE custom install GE path.
        
        Returns:
            Wine Proton GE custom install GE path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_path"]
    
    def set_wine_proton_ge_custom_install_ge_path(self, path: str):
        """Set the Wine Proton GE custom install GE path.
        
        Args:
            path: Wine Proton GE custom install GE path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_path": path})
    
    def get_wine_proton_ge_custom_install_ge_version_path(self) -> str:
        """Get the Wine Proton GE custom install GE version path.
        
        Returns:
            Wine Proton GE custom install GE version path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_version_path"]
    
    def set_wine_proton_ge_custom_install_ge_version_path(self, path: str):
        """Set the Wine Proton GE custom install GE version path.
        
        Args:
            path: Wine Proton GE custom install GE version path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_version_path": path})
    
    def get_wine_proton_ge_custom_install_ge_latest_path(self) -> str:
        """Get the Wine Proton GE custom install GE latest path.
        
        Returns:
            Wine Proton GE custom install GE latest path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_latest_path"]
    
    def set_wine_proton_ge_custom_install_ge_latest_path(self, path: str):
        """Set the Wine Proton GE custom install GE latest path.
        
        Args:
            path: Wine Proton GE custom install GE latest path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_latest_path": path})
    
    def get_wine_proton_ge_custom_install_ge_custom_path(self) -> str:
        """Get the Wine Proton GE custom install GE custom path.
        
        Returns:
            Wine Proton GE custom install GE custom path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_custom_path"]
    
    def set_wine_proton_ge_custom_install_ge_custom_path(self, path: str):
        """Set the Wine Proton GE custom install GE custom path.
        
        Args:
            path: Wine Proton GE custom install GE custom path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_custom_path": path})
    
    def get_wine_proton_ge_custom_install_ge_custom_version_path(self) -> str:
        """Get the Wine Proton GE custom install GE custom version path.
        
        Returns:
            Wine Proton GE custom install GE custom version path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_custom_version_path"]
    
    def set_wine_proton_ge_custom_install_ge_custom_version_path(self, path: str):
        """Set the Wine Proton GE custom install GE custom version path.
        
        Args:
            path: Wine Proton GE custom install GE custom version path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_custom_version_path": path})
    
    def get_wine_proton_ge_custom_install_ge_custom_latest_path(self) -> str:
        """Get the Wine Proton GE custom install GE custom latest path.
        
        Returns:
            Wine Proton GE custom install GE custom latest path
        """
        config = self.get_config()
        return config["wine_proton_ge_custom_install_ge_custom_latest_path"]
    
    def set_wine_proton_ge_custom_install_ge_custom_latest_path(self, path: str):
        """Set the Wine Proton GE custom install GE custom latest path.
        
        Args:
            path: Wine Proton GE custom install GE custom latest path
        """
        self.update_config({"wine_proton_ge_custom_install_ge_custom_latest_path": path}) 