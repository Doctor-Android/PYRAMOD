"""
Pyramod - A powerful mod manager for Linux
"""

__version__ = "0.1.0"
__author__ = "Pyramod Team"
__license__ = "MIT" 