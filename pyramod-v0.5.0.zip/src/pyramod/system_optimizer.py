#!/usr/bin/env python3
import os
import logging
import json
import time
import psutil
import threading
from pathlib import Path
from typing import Dict, List, Optional, Union
import GPUtil
from system_monitor import SystemMonitor

class SystemOptimizer:
    """Automatic system optimization for modded games."""
    
    def __init__(self, config_dir: str):
        """Initialize the system optimizer.
        
        Args:
            config_dir: Directory to store optimization data
        """
        self.config_dir = Path(config_dir)
        self.optimization_dir = self.config_dir / "optimization"
        
        # Create necessary directories
        self.optimization_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        self.logger = logging.getLogger("system_optimizer")
        
        # Load optimization configuration
        self._load_config()
        
        # Initialize optimization state
        self.optimizing = False
        self.current_game = None
        self.optimization_history = []
        self.monitor = SystemMonitor(str(self.config_dir / "logs"))

    def _load_config(self):
        """Load optimization configuration from JSON file."""
        self.config_file = self.optimization_dir / "config.json"
        if self.config_file.exists():
            with open(self.config_file, "r") as f:
                self.config = json.load(f)
        else:
            self.config = {
                "optimization_interval": 300,  # 5 minutes
                "resource_thresholds": {
                    "cpu_percent": 80,
                    "memory_percent": 80,
                    "disk_percent": 90
                },
                "optimization_strategies": {
                    "cpu": {
                        "enabled": True,
                        "priority": "high",
                        "actions": [
                            "reduce_background_processes",
                            "optimize_process_priorities",
                            "adjust_cpu_governor"
                        ]
                    },
                    "memory": {
                        "enabled": True,
                        "priority": "high",
                        "actions": [
                            "clear_memory_cache",
                            "optimize_swap_usage",
                            "reduce_memory_footprint"
                        ]
                    },
                    "disk": {
                        "enabled": True,
                        "priority": "medium",
                        "actions": [
                            "clear_temp_files",
                            "optimize_disk_cache",
                            "defragment_game_files"
                        ]
                    }
                },
                "game_specific_settings": {}
            }
            self._save_config()

    def _save_config(self):
        """Save optimization configuration to JSON file."""
        with open(self.config_file, "w") as f:
            json.dump(self.config, f, indent=4)

    def start_optimization(self, game_name: str):
        """Start automatic system optimization for a game.
        
        Args:
            game_name: Name of the game to optimize for
        """
        if self.optimizing:
            self.logger.warning("Optimization already in progress")
            return False
        
        self.optimizing = True
        self.current_game = game_name
        
        # Start optimization thread
        self.optimize_thread = threading.Thread(
            target=self._optimization_loop,
            daemon=True
        )
        self.optimize_thread.start()
        
        return True

    def stop_optimization(self):
        """Stop automatic system optimization."""
        if not self.optimizing:
            self.logger.warning("No optimization in progress")
            return False
        
        self.optimizing = False
        self.optimize_thread.join()
        
        # Save optimization history
        if self.optimization_history:
            history_file = self.optimization_dir / f"{self.current_game}_optimization_history.json"
            with open(history_file, "w") as f:
                json.dump({
                    "game": self.current_game,
                    "history": self.optimization_history
                }, f, indent=4)
        
        self.current_game = None
        self.optimization_history = []
        
        return True

    def _optimization_loop(self):
        """Main optimization loop."""
        while self.optimizing:
            try:
                # Check system resources
                metrics = self._collect_metrics()
                
                # Determine if optimization is needed
                if self._needs_optimization(metrics):
                    # Perform optimization
                    optimizations = self._optimize_system(metrics)
                    
                    # Record optimization actions
                    self.optimization_history.append({
                        "timestamp": time.time(),
                        "metrics": metrics,
                        "actions": optimizations
                    })
                
                # Sleep before next check
                time.sleep(self.config["optimization_interval"])
                
            except Exception as e:
                self.logger.error(f"Error in optimization loop: {e}")
                time.sleep(60)  # Sleep longer on error

    def _collect_metrics(self) -> Dict:
        """Collect current system metrics.
        
        Returns:
            Dictionary of system metrics
        """
        return {
            "cpu": {
                "percent": psutil.cpu_percent(interval=None),
                "count": psutil.cpu_count(),
                "frequency": psutil.cpu_freq().current if psutil.cpu_freq() else None
            },
            "memory": {
                "total": psutil.virtual_memory().total,
                "available": psutil.virtual_memory().available,
                "percent": psutil.virtual_memory().percent,
                "used": psutil.virtual_memory().used
            },
            "disk": {
                "total": psutil.disk_usage("/").total,
                "used": psutil.disk_usage("/").used,
                "free": psutil.disk_usage("/").free,
                "percent": psutil.disk_usage("/").percent
            }
        }

    def _needs_optimization(self, metrics: Dict) -> bool:
        """Check if system needs optimization based on metrics.
        
        Args:
            metrics: Current system metrics
            
        Returns:
            True if optimization is needed, False otherwise
        """
        thresholds = self.config["resource_thresholds"]
        
        return (
            metrics["cpu"]["percent"] > thresholds["cpu_percent"] or
            metrics["memory"]["percent"] > thresholds["memory_percent"] or
            metrics["disk"]["percent"] > thresholds["disk_percent"]
        )

    def _optimize_system(self, metrics: Dict) -> List[Dict]:
        """Perform system optimization based on metrics.
        
        Args:
            metrics: Current system metrics
            
        Returns:
            List of optimization actions performed
        """
        optimizations = []
        strategies = self.config["optimization_strategies"]
        
        # CPU Optimization
        if strategies["cpu"]["enabled"] and metrics["cpu"]["percent"] > self.config["resource_thresholds"]["cpu_percent"]:
            for action in strategies["cpu"]["actions"]:
                try:
                    if action == "reduce_background_processes":
                        self._reduce_background_processes()
                    elif action == "optimize_process_priorities":
                        self._optimize_process_priorities()
                    elif action == "adjust_cpu_governor":
                        self._adjust_cpu_governor()
                    
                    optimizations.append({
                        "type": "cpu",
                        "action": action,
                        "success": True
                    })
                except Exception as e:
                    self.logger.error(f"CPU optimization action {action} failed: {e}")
                    optimizations.append({
                        "type": "cpu",
                        "action": action,
                        "success": False,
                        "error": str(e)
                    })
        
        # Memory Optimization
        if strategies["memory"]["enabled"] and metrics["memory"]["percent"] > self.config["resource_thresholds"]["memory_percent"]:
            for action in strategies["memory"]["actions"]:
                try:
                    if action == "clear_memory_cache":
                        self._clear_memory_cache()
                    elif action == "optimize_swap_usage":
                        self._optimize_swap_usage()
                    elif action == "reduce_memory_footprint":
                        self._reduce_memory_footprint()
                    
                    optimizations.append({
                        "type": "memory",
                        "action": action,
                        "success": True
                    })
                except Exception as e:
                    self.logger.error(f"Memory optimization action {action} failed: {e}")
                    optimizations.append({
                        "type": "memory",
                        "action": action,
                        "success": False,
                        "error": str(e)
                    })
        
        # Disk Optimization
        if strategies["disk"]["enabled"] and metrics["disk"]["percent"] > self.config["resource_thresholds"]["disk_percent"]:
            for action in strategies["disk"]["actions"]:
                try:
                    if action == "clear_temp_files":
                        self._clear_temp_files()
                    elif action == "optimize_disk_cache":
                        self._optimize_disk_cache()
                    elif action == "defragment_game_files":
                        self._defragment_game_files()
                    
                    optimizations.append({
                        "type": "disk",
                        "action": action,
                        "success": True
                    })
                except Exception as e:
                    self.logger.error(f"Disk optimization action {action} failed: {e}")
                    optimizations.append({
                        "type": "disk",
                        "action": action,
                        "success": False,
                        "error": str(e)
                    })
        
        return optimizations

    def _reduce_background_processes(self):
        """Reduce CPU usage by managing background processes."""
        # Get list of non-essential processes
        for proc in psutil.process_iter(['pid', 'name', 'cpu_percent']):
            try:
                # Skip system processes and the current game
                if proc.info['name'] in ['systemd', 'init', self.current_game]:
                    continue
                
                # If process is using significant CPU, reduce its priority
                if proc.info['cpu_percent'] > 5:
                    proc.nice(10)  # Lower priority
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

    def _optimize_process_priorities(self):
        """Optimize process priorities for better performance."""
        # Set high priority for the game process
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                if proc.info['name'] == self.current_game:
                    proc.nice(-10)  # Higher priority
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

    def _adjust_cpu_governor(self):
        """Adjust CPU governor for better performance."""
        # This is a placeholder - actual implementation would depend on the system
        pass

    def _clear_memory_cache(self):
        """Clear system memory cache."""
        # This is a placeholder - actual implementation would depend on the system
        pass

    def _optimize_swap_usage(self):
        """Optimize swap usage."""
        # This is a placeholder - actual implementation would depend on the system
        pass

    def _reduce_memory_footprint(self):
        """Reduce memory footprint of non-essential processes."""
        for proc in psutil.process_iter(['pid', 'name', 'memory_percent']):
            try:
                # Skip system processes and the current game
                if proc.info['name'] in ['systemd', 'init', self.current_game]:
                    continue
                
                # If process is using significant memory, try to reduce it
                if proc.info['memory_percent'] > 5:
                    proc.nice(10)  # Lower priority
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

    def _clear_temp_files(self):
        """Clear temporary files."""
        temp_dirs = [
            "/tmp",
            os.path.expanduser("~/.cache"),
            os.path.expanduser("~/.local/share/temp")
        ]
        
        for temp_dir in temp_dirs:
            try:
                for item in os.listdir(temp_dir):
                    item_path = os.path.join(temp_dir, item)
                    try:
                        if os.path.isfile(item_path):
                            os.remove(item_path)
                        elif os.path.isdir(item_path):
                            import shutil
                            shutil.rmtree(item_path)
                    except Exception as e:
                        self.logger.warning(f"Could not remove {item_path}: {e}")
            except Exception as e:
                self.logger.warning(f"Could not access {temp_dir}: {e}")

    def _optimize_disk_cache(self):
        """Optimize disk cache usage."""
        # This is a placeholder - actual implementation would depend on the system
        pass

    def _defragment_game_files(self):
        """Defragment game files."""
        # This is a placeholder - actual implementation would depend on the system
        pass

    def create_optimization_profile(self, game_name: str, settings: Dict):
        """Create a new optimization profile for a game."""
        self.config["game_specific_settings"][game_name] = {
            'settings': settings,
            'last_updated': str(datetime.now())
        }
        self._save_config()

    def get_optimization_profile(self, game_name: str) -> Optional[Dict]:
        """Get optimization profile for a game."""
        return self.config["game_specific_settings"].get(game_name)

    def optimize_system_for_game(self, game_name: str) -> List[str]:
        """
        Optimize system settings for a specific game.
        Returns list of optimizations applied.
        """
        applied_optimizations = []
        profile = self.get_optimization_profile(game_name)
        
        if not profile:
            self.logger.warning(f"No optimization profile found for {game_name}")
            return applied_optimizations

        # Get current system state
        metrics = self._collect_metrics()
        
        # Apply CPU optimizations
        if 'cpu' in profile['settings']:
            cpu_optimizations = self._optimize_cpu(profile['settings']['cpu'])
            applied_optimizations.extend(cpu_optimizations)

        # Apply memory optimizations
        if 'memory' in profile['settings']:
            memory_optimizations = self._optimize_memory(profile['settings']['memory'])
            applied_optimizations.extend(memory_optimizations)

        # Apply GPU optimizations
        if 'gpu' in profile['settings'] and metrics.get('gpu'):
            gpu_optimizations = self._optimize_gpu(profile['settings']['gpu'])
            applied_optimizations.extend(gpu_optimizations)

        # Apply disk optimizations
        if 'disk' in profile['settings']:
            disk_optimizations = self._optimize_disk(profile['settings']['disk'])
            applied_optimizations.extend(disk_optimizations)

        return applied_optimizations

    def _optimize_cpu(self, settings: Dict) -> List[str]:
        """Apply CPU optimizations."""
        optimizations = []
        
        # Set CPU governor if specified
        if 'governor' in settings:
            try:
                with open('/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor', 'w') as f:
                    f.write(settings['governor'])
                optimizations.append(f"Set CPU governor to {settings['governor']}")
            except Exception as e:
                self.logger.error(f"Failed to set CPU governor: {e}")

        # Set CPU frequency if specified
        if 'frequency' in settings:
            try:
                with open('/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq', 'w') as f:
                    f.write(str(settings['frequency']))
                optimizations.append(f"Set CPU frequency to {settings['frequency']}Hz")
            except Exception as e:
                self.logger.error(f"Failed to set CPU frequency: {e}")

        return optimizations

    def _optimize_memory(self, settings: Dict) -> List[str]:
        """Apply memory optimizations."""
        optimizations = []
        
        # Set swappiness if specified
        if 'swappiness' in settings:
            try:
                with open('/proc/sys/vm/swappiness', 'w') as f:
                    f.write(str(settings['swappiness']))
                optimizations.append(f"Set swappiness to {settings['swappiness']}")
            except Exception as e:
                self.logger.error(f"Failed to set swappiness: {e}")

        # Set vfs_cache_pressure if specified
        if 'vfs_cache_pressure' in settings:
            try:
                with open('/proc/sys/vm/vfs_cache_pressure', 'w') as f:
                    f.write(str(settings['vfs_cache_pressure']))
                optimizations.append(f"Set vfs_cache_pressure to {settings['vfs_cache_pressure']}")
            except Exception as e:
                self.logger.error(f"Failed to set vfs_cache_pressure: {e}")

        return optimizations

    def _optimize_gpu(self, settings: Dict) -> List[str]:
        """Apply GPU optimizations."""
        optimizations = []
        
        # Set GPU power limit if specified
        if 'power_limit' in settings:
            try:
                gpus = GPUtil.getGPUs()
                for gpu in gpus:
                    gpu.setPowerLimit(settings['power_limit'])
                optimizations.append(f"Set GPU power limit to {settings['power_limit']}W")
            except Exception as e:
                self.logger.error(f"Failed to set GPU power limit: {e}")

        # Set GPU memory clock if specified
        if 'memory_clock' in settings:
            try:
                gpus = GPUtil.getGPUs()
                for gpu in gpus:
                    gpu.setMemoryClock(settings['memory_clock'])
                optimizations.append(f"Set GPU memory clock to {settings['memory_clock']}MHz")
            except Exception as e:
                self.logger.error(f"Failed to set GPU memory clock: {e}")

        return optimizations

    def _optimize_disk(self, settings: Dict) -> List[str]:
        """Apply disk optimizations."""
        optimizations = []
        
        # Set readahead if specified
        if 'readahead' in settings:
            try:
                with open('/sys/block/sda/queue/read_ahead_kb', 'w') as f:
                    f.write(str(settings['readahead']))
                optimizations.append(f"Set disk readahead to {settings['readahead']}KB")
            except Exception as e:
                self.logger.error(f"Failed to set disk readahead: {e}")

        # Set scheduler if specified
        if 'scheduler' in settings:
            try:
                with open('/sys/block/sda/queue/scheduler', 'w') as f:
                    f.write(settings['scheduler'])
                optimizations.append(f"Set disk scheduler to {settings['scheduler']}")
            except Exception as e:
                self.logger.error(f"Failed to set disk scheduler: {e}")

        return optimizations

    def get_optimization_recommendations(self, game_name: str) -> List[str]:
        """Get optimization recommendations for a game."""
        recommendations = []
        profile = self.get_optimization_profile(game_name)
        
        if not profile:
            return ["No optimization profile found for this game"]

        # Get current system state
        metrics = self._collect_metrics()
        
        # Check CPU recommendations
        if metrics['cpu']['percent'] > 80:
            recommendations.append("Consider reducing CPU-intensive background processes")
        
        # Check memory recommendations
        if metrics['memory']['percent'] > 80:
            recommendations.append("Consider increasing swap space or closing memory-intensive applications")
        
        # Check GPU recommendations
        if metrics.get('gpu') and metrics['gpu'].get('memory_percent', 0) > 80:
            recommendations.append("Consider reducing graphics settings or closing GPU-intensive applications")
        
        # Check disk recommendations
        if metrics['disk']['percent'] > 80:
            recommendations.append("Consider cleaning up disk space or moving large files to external storage")

        return recommendations

if __name__ == '__main__':
    # Example usage
    logging.basicConfig(level=logging.INFO)
    optimizer = SystemOptimizer("config")
    
    # Create a sample optimization profile
    sample_profile = {
        'settings': {
            'cpu': {
                'governor': 'performance',
                'frequency': 3000000
            },
            'memory': {
                'swappiness': 10,
                'vfs_cache_pressure': 50
            },
            'gpu': {
                'power_limit': 150,
                'memory_clock': 7000
            },
            'disk': {
                'readahead': 2048,
                'scheduler': 'deadline'
            }
        }
    }
    
    optimizer.create_optimization_profile("Skyrim", sample_profile)
    optimizations = optimizer.optimize_system_for_game("Skyrim")
    print("Applied optimizations:", optimizations) 