from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTimeEdit, QCheckBox, QMessageBox, QGroupBox
)
from PyQt6.QtCore import Qt, QTime
from datetime import datetime
from mod_update_scheduler import ModUpdateScheduler

class ModUpdateSchedulerDialog(QDialog):
    def __init__(self, scheduler: ModUpdateScheduler, parent=None):
        super().__init__(parent)
        self.scheduler = scheduler
        self.setWindowTitle("Update Scheduler Settings")
        
        # Initialize UI
        self.init_ui()
        
        # Load current settings
        self.load_settings()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Enable/Disable
        self.enable_checkbox = QCheckBox("Enable Automatic Update Checks")
        layout.addWidget(self.enable_checkbox)
        
        # Time settings
        time_group = QGroupBox("Check Time")
        time_layout = QVBoxLayout()
        
        time_row = QHBoxLayout()
        time_row.addWidget(QLabel("Check at:"))
        self.time_edit = QTimeEdit()
        self.time_edit.setDisplayFormat("HH:mm")
        time_row.addWidget(self.time_edit)
        time_layout.addLayout(time_row)
        
        time_group.setLayout(time_layout)
        layout.addWidget(time_group)
        
        # Days settings
        days_group = QGroupBox("Check Days")
        days_layout = QVBoxLayout()
        
        self.day_checkboxes = []
        days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
        for day in days:
            checkbox = QCheckBox(day)
            self.day_checkboxes.append(checkbox)
            days_layout.addWidget(checkbox)
            
        days_group.setLayout(days_layout)
        layout.addWidget(days_group)
        
        # Next check info
        next_check_layout = QHBoxLayout()
        next_check_layout.addWidget(QLabel("Next scheduled check:"))
        self.next_check_label = QLabel()
        next_check_layout.addWidget(self.next_check_label)
        layout.addLayout(next_check_layout)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        save_button = QPushButton("Save")
        save_button.clicked.connect(self.save_settings)
        buttons_layout.addWidget(save_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        buttons_layout.addWidget(cancel_button)
        
        layout.addLayout(buttons_layout)
        
        self.setLayout(layout)
        
    def load_settings(self):
        """Load current scheduler settings"""
        schedule = self.scheduler.get_schedule()
        
        # Set enabled state
        self.enable_checkbox.setChecked(schedule["enabled"])
        
        # Set time
        check_time = datetime.strptime(schedule["check_time"], "%H:%M").time()
        self.time_edit.setTime(QTime(check_time.hour, check_time.minute))
        
        # Set days
        for i, checkbox in enumerate(self.day_checkboxes):
            checkbox.setChecked(i in schedule["check_days"])
            
        # Update next check info
        self.update_next_check_info()
        
    def save_settings(self):
        """Save new scheduler settings"""
        try:
            # Get selected days
            check_days = [i for i, checkbox in enumerate(self.day_checkboxes) if checkbox.isChecked()]
            if not check_days:
                QMessageBox.warning(self, "Error", "Please select at least one day")
                return
                
            # Get time
            check_time = self.time_edit.time().toString("HH:mm")
            
            # Save settings
            if self.scheduler.set_schedule(
                self.enable_checkbox.isChecked(),
                check_time,
                check_days
            ):
                QMessageBox.information(self, "Success", "Settings saved successfully")
                self.update_next_check_info()
                self.accept()
            else:
                QMessageBox.warning(self, "Error", "Failed to save settings")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            
    def update_next_check_info(self):
        """Update the next check information label"""
        next_check = self.scheduler.get_next_check()
        if next_check:
            self.next_check_label.setText(next_check.strftime("%Y-%m-%d %H:%M"))
        else:
            self.next_check_label.setText("Not scheduled") 