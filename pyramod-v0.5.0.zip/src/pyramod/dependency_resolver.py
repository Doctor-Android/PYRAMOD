import os
import json
from typing import Dict, List, Set, Optional
from error_handler import error_handler

class DependencyResolver:
    def __init__(self):
        self.dependency_types = {
            "required": "Required dependency",
            "optional": "Optional dependency",
            "incompatible": "Incompatible with"
        }

    def resolve_dependencies(self, mods_dir: str) -> Dict[str, List[Dict]]:
        """Resolve dependencies for all installed mods"""
        try:
            resolution = {
                "missing": [],
                "conflicts": [],
                "optional": []
            }

            # Get all mod manifests
            mod_manifests = self._get_mod_manifests(mods_dir)
            if not mod_manifests:
                return resolution

            # Check dependencies
            for mod_name, manifest in mod_manifests.items():
                if "dependencies" in manifest:
                    for dep in manifest["dependencies"]:
                        dep_type = dep.get("type", "required")
                        dep_name = dep["name"]
                        dep_version = dep.get("version", "any")

                        if dep_type == "required":
                            if not self._check_dependency(mod_manifests, dep_name, dep_version):
                                resolution["missing"].append({
                                    "mod": mod_name,
                                    "dependency": dep_name,
                                    "version": dep_version,
                                    "type": "required"
                                })
                        elif dep_type == "optional":
                            if not self._check_dependency(mod_manifests, dep_name, dep_version):
                                resolution["optional"].append({
                                    "mod": mod_name,
                                    "dependency": dep_name,
                                    "version": dep_version,
                                    "type": "optional"
                                })
                        elif dep_type == "incompatible":
                            if self._check_dependency(mod_manifests, dep_name, dep_version):
                                resolution["conflicts"].append({
                                    "mod": mod_name,
                                    "dependency": dep_name,
                                    "version": dep_version,
                                    "type": "incompatible"
                                })

            return resolution

        except Exception as e:
            error_handler.handle_error(e, {"mods_dir": mods_dir})
            raise

    def get_install_order(self, mods_dir: str) -> List[str]:
        """Get the correct installation order for mods"""
        try:
            # Get all mod manifests
            mod_manifests = self._get_mod_manifests(mods_dir)
            if not mod_manifests:
                return []

            # Create dependency graph
            graph = {}
            for mod_name, manifest in mod_manifests.items():
                graph[mod_name] = set()
                if "dependencies" in manifest:
                    for dep in manifest["dependencies"]:
                        if dep.get("type") == "required":
                            graph[mod_name].add(dep["name"])

            # Topological sort
            visited = set()
            temp = set()
            order = []

            def visit(node):
                if node in temp:
                    raise ValueError(f"Circular dependency detected: {node}")
                if node in visited:
                    return
                temp.add(node)
                for dep in graph.get(node, set()):
                    visit(dep)
                temp.remove(node)
                visited.add(node)
                order.append(node)

            for node in graph:
                if node not in visited:
                    visit(node)

            return list(reversed(order))

        except Exception as e:
            error_handler.handle_error(e, {"mods_dir": mods_dir})
            return []

    def _get_mod_manifests(self, mods_dir: str) -> Dict[str, Dict]:
        """Get manifests for all installed mods"""
        manifests = {}
        for mod in os.listdir(mods_dir):
            mod_path = os.path.join(mods_dir, mod)
            if os.path.isdir(mod_path):
                manifest_path = os.path.join(mod_path, "manifest.json")
                if os.path.exists(manifest_path):
                    try:
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                            manifests[mod] = manifest
                    except Exception as e:
                        error_handler.log_warning(f"Error reading manifest for {mod}: {str(e)}")
        return manifests

    def _check_dependency(self, mod_manifests: Dict[str, Dict], dep_name: str, dep_version: str) -> bool:
        """Check if a dependency is satisfied"""
        if dep_name not in mod_manifests:
            return False

        if dep_version == "any":
            return True

        mod_version = mod_manifests[dep_name].get("version", "0.0.0")
        return self._compare_versions(mod_version, dep_version)

    def _compare_versions(self, version1: str, version2: str) -> bool:
        """Compare two version strings"""
        v1_parts = [int(x) for x in version1.split(".")]
        v2_parts = [int(x) for x in version2.split(".")]

        for i in range(max(len(v1_parts), len(v2_parts))):
            v1_part = v1_parts[i] if i < len(v1_parts) else 0
            v2_part = v2_parts[i] if i < len(v2_parts) else 0

            if v1_part > v2_part:
                return True
            elif v1_part < v2_part:
                return False

        return True

# Create a global dependency resolver instance
dependency_resolver = DependencyResolver() 