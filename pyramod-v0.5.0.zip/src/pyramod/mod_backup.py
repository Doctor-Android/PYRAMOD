import os
import shutil
import json
import zipfile
from datetime import datetime
from typing import Dict, List, Optional
from error_handler import error_handler

class ModBackup:
    def __init__(self, backup_dir: str = "backups"):
        self.backup_dir = backup_dir
        if not os.path.exists(backup_dir):
            os.makedirs(backup_dir)

    def create_backup(self, game_name: str, profile_name: str, mods_dir: str) -> str:
        """Create a backup of the current mod configuration"""
        try:
            # Create backup directory for this game and profile
            backup_path = os.path.join(
                self.backup_dir,
                game_name,
                profile_name,
                datetime.now().strftime("%Y%m%d_%H%M%S")
            )
            os.makedirs(backup_path, exist_ok=True)

            # Create mod list file
            mod_list = []
            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    mod_list.append({
                        "name": mod,
                        "path": mod_path,
                        "timestamp": datetime.now().isoformat()
                    })

            # Save mod list
            with open(os.path.join(backup_path, "mod_list.json"), "w") as f:
                json.dump(mod_list, f, indent=4)

            # Create zip archive of mods
            zip_path = os.path.join(backup_path, "mods.zip")
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
                for mod in mod_list:
                    mod_path = mod["path"]
                    for root, _, files in os.walk(mod_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arcname = os.path.relpath(file_path, mods_dir)
                            zipf.write(file_path, arcname)

            error_handler.log_info(f"Created backup at {backup_path}")
            return backup_path

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "profile": profile_name,
                "mods_dir": mods_dir
            })
            raise

    def restore_backup(self, backup_path: str, mods_dir: str) -> bool:
        """Restore a mod configuration from backup"""
        try:
            # Read mod list
            with open(os.path.join(backup_path, "mod_list.json"), "r") as f:
                mod_list = json.load(f)

            # Clear current mods directory
            if os.path.exists(mods_dir):
                shutil.rmtree(mods_dir)
            os.makedirs(mods_dir)

            # Extract mods from zip
            zip_path = os.path.join(backup_path, "mods.zip")
            with zipfile.ZipFile(zip_path, "r") as zipf:
                zipf.extractall(mods_dir)

            error_handler.log_info(f"Restored backup from {backup_path}")
            return True

        except Exception as e:
            error_handler.handle_error(e, {
                "backup_path": backup_path,
                "mods_dir": mods_dir
            })
            return False

    def list_backups(self, game_name: str, profile_name: str) -> List[Dict[str, str]]:
        """List available backups for a game and profile"""
        backups = []
        profile_backup_dir = os.path.join(self.backup_dir, game_name, profile_name)

        if not os.path.exists(profile_backup_dir):
            return backups

        for backup in os.listdir(profile_backup_dir):
            backup_path = os.path.join(profile_backup_dir, backup)
            if os.path.isdir(backup_path):
                try:
                    with open(os.path.join(backup_path, "mod_list.json"), "r") as f:
                        mod_list = json.load(f)
                        backups.append({
                            "path": backup_path,
                            "timestamp": backup,
                            "mod_count": len(mod_list)
                        })
                except Exception as e:
                    error_handler.log_warning(f"Error reading backup {backup}: {str(e)}")
                    continue

        return sorted(backups, key=lambda x: x["timestamp"], reverse=True)

    def delete_backup(self, backup_path: str) -> bool:
        """Delete a backup"""
        try:
            if os.path.exists(backup_path):
                shutil.rmtree(backup_path)
                error_handler.log_info(f"Deleted backup at {backup_path}")
                return True
            return False
        except Exception as e:
            error_handler.handle_error(e, {"backup_path": backup_path})
            return False

# Create a global mod backup instance
mod_backup = ModBackup() 