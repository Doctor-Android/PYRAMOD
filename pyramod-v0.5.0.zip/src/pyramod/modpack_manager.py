import json
import os
import shutil
from typing import List, Dict, Optional
from pathlib import Path
import logging
from datetime import datetime

class ModpackManager:
    def __init__(self, base_path: Path, mod_manager):
        self.base_path = base_path
        self.modpacks_path = base_path / "modpacks"
        self.mod_manager = mod_manager
        
        # Create necessary directories
        self.modpacks_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=self.base_path / "modpack_manager.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
    def get_modpacks(self) -> List[str]:
        """Get list of available modpacks"""
        return [f.stem for f in self.modpacks_path.glob("*.json")]
        
    def create_modpack(self, name: str, description: str, mods: List[str]) -> bool:
        """Create a new modpack"""
        try:
            # Validate mods
            for mod in mods:
                if mod not in self.mod_manager.installed_mods:
                    logging.error(f"Mod not found: {mod}")
                    return False
                    
            # Create modpack info
            modpack_info = {
                "name": name,
                "description": description,
                "created": datetime.now().isoformat(),
                "mods": mods,
                "mod_info": {
                    mod: self.mod_manager.installed_mods[mod]
                    for mod in mods
                }
            }
            
            # Save modpack
            modpack_path = self.modpacks_path / f"{name}.json"
            with open(modpack_path, 'w') as f:
                json.dump(modpack_info, f, indent=2)
                
            logging.info(f"Created modpack: {name}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to create modpack: {e}")
            return False
            
    def get_modpack_info(self, name: str) -> Optional[Dict]:
        """Get information about a modpack"""
        try:
            modpack_path = self.modpacks_path / f"{name}.json"
            if not modpack_path.exists():
                return None
                
            with open(modpack_path, 'r') as f:
                return json.load(f)
                
        except Exception as e:
            logging.error(f"Failed to get modpack info: {e}")
            return None
            
    def edit_modpack(self, name: str, new_name: Optional[str] = None,
                    new_description: Optional[str] = None,
                    add_mods: Optional[List[str]] = None,
                    remove_mods: Optional[List[str]] = None) -> bool:
        """Edit an existing modpack"""
        try:
            modpack_info = self.get_modpack_info(name)
            if not modpack_info:
                return False
                
            # Update name if provided
            if new_name and new_name != name:
                old_path = self.modpacks_path / f"{name}.json"
                new_path = self.modpacks_path / f"{new_name}.json"
                old_path.rename(new_path)
                modpack_info["name"] = new_name
                
            # Update description if provided
            if new_description:
                modpack_info["description"] = new_description
                
            # Add mods if provided
            if add_mods:
                for mod in add_mods:
                    if mod not in modpack_info["mods"]:
                        modpack_info["mods"].append(mod)
                        modpack_info["mod_info"][mod] = self.mod_manager.installed_mods[mod]
                        
            # Remove mods if provided
            if remove_mods:
                for mod in remove_mods:
                    if mod in modpack_info["mods"]:
                        modpack_info["mods"].remove(mod)
                        del modpack_info["mod_info"][mod]
                        
            # Save updated modpack
            modpack_path = self.modpacks_path / f"{modpack_info['name']}.json"
            with open(modpack_path, 'w') as f:
                json.dump(modpack_info, f, indent=2)
                
            logging.info(f"Updated modpack: {modpack_info['name']}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to edit modpack: {e}")
            return False
            
    def delete_modpack(self, name: str) -> bool:
        """Delete a modpack"""
        try:
            modpack_path = self.modpacks_path / f"{name}.json"
            if modpack_path.exists():
                modpack_path.unlink()
                logging.info(f"Deleted modpack: {name}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Failed to delete modpack: {e}")
            return False
            
    def apply_modpack(self, name: str, game_path: Path) -> bool:
        """Apply a modpack to a game"""
        try:
            modpack_info = self.get_modpack_info(name)
            if not modpack_info:
                return False
                
            # Create backup
            backup_path = self.mod_manager.create_backup(game_path)
            if not backup_path:
                logging.error("Failed to create backup")
                return False
                
            # Install each mod in the modpack
            for mod in modpack_info["mods"]:
                mod_info = modpack_info["mod_info"][mod]
                mod_file = self.mod_manager.mods_path / mod / f"{mod}.zip"
                
                if not mod_file.exists():
                    logging.error(f"Mod file not found: {mod_file}")
                    return False
                    
                if not self.mod_manager.install_mod(mod_file, game_path):
                    logging.error(f"Failed to install mod: {mod}")
                    return False
                    
            # Sort load order
            if not self.mod_manager.sort_load_order(game_path):
                logging.error("Failed to sort load order")
                return False
                
            logging.info(f"Successfully applied modpack: {name}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to apply modpack: {e}")
            return False
            
    def export_modpack(self, name: str, export_path: Path) -> bool:
        """Export a modpack to a file"""
        try:
            modpack_info = self.get_modpack_info(name)
            if not modpack_info:
                return False
                
            # Create export directory
            export_dir = export_path / name
            export_dir.mkdir(parents=True, exist_ok=True)
            
            # Copy mod files
            for mod in modpack_info["mods"]:
                mod_file = self.mod_manager.mods_path / mod / f"{mod}.zip"
                if mod_file.exists():
                    shutil.copy2(mod_file, export_dir / f"{mod}.zip")
                    
            # Save modpack info
            with open(export_dir / "modpack.json", 'w') as f:
                json.dump(modpack_info, f, indent=2)
                
            # Create archive
            shutil.make_archive(str(export_path / name), 'zip', export_dir)
            
            # Clean up
            shutil.rmtree(export_dir)
            
            logging.info(f"Exported modpack: {name}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to export modpack: {e}")
            return False
            
    def import_modpack(self, import_path: Path) -> bool:
        """Import a modpack from a file"""
        try:
            # Extract modpack
            extract_path = self.modpacks_path / "temp"
            if extract_path.exists():
                shutil.rmtree(extract_path)
            extract_path.mkdir()
            
            # Extract archive
            shutil.unpack_archive(str(import_path), extract_path)
            
            # Load modpack info
            with open(extract_path / "modpack.json", 'r') as f:
                modpack_info = json.load(f)
                
            # Copy mod files
            for mod in modpack_info["mods"]:
                mod_file = extract_path / f"{mod}.zip"
                if mod_file.exists():
                    mod_dir = self.mod_manager.mods_path / mod
                    mod_dir.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(mod_file, mod_dir / f"{mod}.zip")
                    
            # Save modpack info
            with open(self.modpacks_path / f"{modpack_info['name']}.json", 'w') as f:
                json.dump(modpack_info, f, indent=2)
                
            # Clean up
            shutil.rmtree(extract_path)
            
            logging.info(f"Imported modpack: {modpack_info['name']}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to import modpack: {e}")
            return False 