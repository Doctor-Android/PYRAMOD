from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QTextEdit, QMessageBox
)
from PyQt6.QtCore import Qt
from datetime import datetime
from mod_update_manager import ModUpdateManager, ModVersion
from pathlib import Path

class ModVersionHistoryDialog(QDialog):
    def __init__(self, update_manager: ModUpdateManager, mod_id: str, current_version: str, parent=None):
        super().__init__(parent)
        self.update_manager = update_manager
        self.mod_id = mod_id
        self.current_version = current_version
        
        self.setWindowTitle(f"Version History - {mod_id}")
        self.setMinimumWidth(800)
        self.setMinimumHeight(600)
        
        # Initialize UI
        self.init_ui()
        
        # Load version history
        self.load_version_history()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Current version info
        current_version_layout = QHBoxLayout()
        current_version_layout.addWidget(QLabel("Current Version:"))
        self.current_version_label = QLabel(self.current_version)
        current_version_layout.addWidget(self.current_version_label)
        layout.addLayout(current_version_layout)
        
        # Version history table
        self.version_table = QTableWidget()
        self.version_table.setColumnCount(4)
        self.version_table.setHorizontalHeaderLabels([
            "Version", "Release Date", "Changelog", "Actions"
        ])
        self.version_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.version_table.itemSelectionChanged.connect(self.show_changelog)
        layout.addWidget(self.version_table)
        
        # Changelog
        changelog_layout = QVBoxLayout()
        changelog_layout.addWidget(QLabel("Changelog:"))
        self.changelog_text = QTextEdit()
        self.changelog_text.setReadOnly(True)
        changelog_layout.addWidget(self.changelog_text)
        layout.addLayout(changelog_layout)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        buttons_layout.addWidget(close_button)
        
        layout.addLayout(buttons_layout)
        
        self.setLayout(layout)
        
    def load_version_history(self):
        """Load and display version history"""
        try:
            versions = self.update_manager.get_mod_versions(self.mod_id)
            if not versions:
                QMessageBox.information(self, "No History", "No version history available")
                return
                
            self.version_table.setRowCount(len(versions))
            for row, version in enumerate(versions):
                # Version
                self.version_table.setItem(row, 0, QTableWidgetItem(version.version))
                
                # Release date
                self.version_table.setItem(row, 1, QTableWidgetItem(
                    version.release_date.strftime("%Y-%m-%d %H:%M")
                ))
                
                # Changelog preview
                changelog_preview = version.changelog[:100] + "..." if len(version.changelog) > 100 else version.changelog
                self.version_table.setItem(row, 2, QTableWidgetItem(changelog_preview))
                
                # Actions
                if version.version != self.current_version:
                    rollback_button = QPushButton("Rollback")
                    rollback_button.clicked.connect(lambda checked, v=version: self.rollback_to_version(v))
                    self.version_table.setCellWidget(row, 3, rollback_button)
                    
            # Resize columns
            self.version_table.resizeColumnsToContents()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load version history: {str(e)}")
            
    def show_changelog(self):
        """Show full changelog for selected version"""
        selected_items = self.version_table.selectedItems()
        if not selected_items:
            return
            
        row = selected_items[0].row()
        version = self.update_manager.get_mod_versions(self.mod_id)[row]
        self.changelog_text.setText(version.changelog)
        
    def rollback_to_version(self, version: ModVersion):
        """Rollback to a specific version"""
        try:
            reply = QMessageBox.question(
                self,
                "Confirm Rollback",
                f"Are you sure you want to rollback {self.mod_id} to version {version.version}?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            
            if reply == QMessageBox.StandardButton.Yes:
                # Create backup of current version
                if not self.update_manager.backup_mod(self.mod_id, Path(self.current_version)):
                    QMessageBox.warning(self, "Backup Failed", "Failed to create backup")
                    return
                    
                # Download and apply old version
                if self.update_manager.download_update(self.mod_id, version, Path(self.current_version)):
                    QMessageBox.information(self, "Success", 
                                          f"Successfully rolled back to version {version.version}")
                    self.current_version = version.version
                    self.current_version_label.setText(self.current_version)
                    self.load_version_history()
                else:
                    QMessageBox.warning(self, "Failed", "Failed to rollback version")
                    
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}") 