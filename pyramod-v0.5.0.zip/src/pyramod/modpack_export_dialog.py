from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QPushButton, QFileDialog, QMessageBox)
from PyQt6.QtCore import Qt
import json
from pathlib import Path

class ModpackExportDialog(QDialog):
    def __init__(self, modpack_name: str, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Export/Import Modpack - {modpack_name}")
        self.setGeometry(200, 200, 400, 300)
        
        self.modpack_name = modpack_name
        self.modpack_manager = modpack_manager
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Export section
        export_layout = QVBoxLayout()
        export_layout.addWidget(QLabel("Export Modpack:"))
        
        export_btn = QPushButton("Export")
        export_btn.clicked.connect(self.export_modpack)
        export_layout.addWidget(export_btn)
        layout.addLayout(export_layout)
        
        # Import section
        import_layout = QVBoxLayout()
        import_layout.addWidget(QLabel("Import Modpack:"))
        
        import_btn = QPushButton("Import")
        import_btn.clicked.connect(self.import_modpack)
        import_layout.addWidget(import_btn)
        layout.addLayout(import_layout)
        
        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)
        
        self.setLayout(layout)
        
    def export_modpack(self):
        try:
            modpack_info = self.modpack_manager.get_modpack_info(self.modpack_name)
            
            # Get save location
            file_path, _ = QFileDialog.getSaveFileName(
                self,
                "Export Modpack",
                f"{self.modpack_name}.json",
                "JSON Files (*.json)"
            )
            
            if not file_path:
                return
                
            # Save modpack info to file
            with open(file_path, 'w') as f:
                json.dump(modpack_info, f, indent=4)
                
            QMessageBox.information(self, "Success", "Modpack exported successfully!")
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to export modpack: {str(e)}")
            
    def import_modpack(self):
        try:
            # Get file to import
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "Import Modpack",
                "",
                "JSON Files (*.json)"
            )
            
            if not file_path:
                return
                
            # Load modpack info
            with open(file_path, 'r') as f:
                modpack_info = json.load(f)
                
            # Check required fields
            if not all(key in modpack_info for key in ["name", "description", "mods"]):
                raise ValueError("Invalid modpack file format")
                
            # Create new modpack
            self.modpack_manager.create_modpack(
                modpack_info["name"],
                modpack_info["description"],
                modpack_info["mods"]
            )
            
            QMessageBox.information(self, "Success", "Modpack imported successfully!")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to import modpack: {str(e)}") 