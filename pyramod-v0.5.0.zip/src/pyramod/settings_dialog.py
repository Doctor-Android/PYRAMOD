import tkinter as tk
from tkinter import ttk
import json
import os
from typing import Dict, Any

class SettingsDialog:
    def __init__(self, parent):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("Settings")
        self.window.geometry("600x400")
        
        # Load settings
        self.settings = self.load_settings()
        
        # Create main frame
        self.main_frame = ttk.Frame(self.window)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create notebook for tabs
        self.notebook = ttk.Notebook(self.main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # Create tabs
        self.create_general_tab()
        self.create_mods_tab()
        self.create_advanced_tab()
        
        # Add buttons
        self.create_buttons()
        
    def create_general_tab(self):
        """Create general settings tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="General")
        
        # Theme
        theme_frame = ttk.LabelFrame(tab, text="Theme")
        theme_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(theme_frame, text="Theme:").pack(side=tk.LEFT, padx=5)
        self.theme_var = tk.StringVar(value=self.settings.get("theme", "Dark"))
        theme_combo = ttk.Combobox(theme_frame, textvariable=self.theme_var, values=["Dark", "Light"])
        theme_combo.pack(side=tk.LEFT, padx=5)
        
        # Language
        lang_frame = ttk.LabelFrame(tab, text="Language")
        lang_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(lang_frame, text="Language:").pack(side=tk.LEFT, padx=5)
        self.lang_var = tk.StringVar(value=self.settings.get("language", "English"))
        lang_combo = ttk.Combobox(lang_frame, textvariable=self.lang_var, values=["English", "Spanish", "French", "German"])
        lang_combo.pack(side=tk.LEFT, padx=5)
        
    def create_mods_tab(self):
        """Create mods settings tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Mods")
        
        # Auto Update
        update_frame = ttk.LabelFrame(tab, text="Updates")
        update_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.auto_update_var = tk.BooleanVar(value=self.settings.get("auto_update", True))
        ttk.Checkbutton(update_frame, text="Auto Update Mods", variable=self.auto_update_var).pack(anchor=tk.W, padx=5)
        
        # Deploy Settings
        deploy_frame = ttk.LabelFrame(tab, text="Deployment")
        deploy_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.deploy_on_install_var = tk.BooleanVar(value=self.settings.get("deploy_on_install", True))
        ttk.Checkbutton(deploy_frame, text="Deploy on Install", variable=self.deploy_on_install_var).pack(anchor=tk.W, padx=5)
        
        self.auto_deploy_var = tk.BooleanVar(value=self.settings.get("auto_deploy", False))
        ttk.Checkbutton(deploy_frame, text="Auto Deploy Changes", variable=self.auto_deploy_var).pack(anchor=tk.W, padx=5)
        
    def create_advanced_tab(self):
        """Create advanced settings tab"""
        tab = ttk.Frame(self.notebook)
        self.notebook.add(tab, text="Advanced")
        
        # System Settings
        system_frame = ttk.LabelFrame(tab, text="System")
        system_frame.pack(fill=tk.X, padx=5, pady=5)
        
        ttk.Label(system_frame, text="Max Threads:").pack(side=tk.LEFT, padx=5)
        self.threads_var = tk.StringVar(value=str(self.settings.get("max_threads", 4)))
        threads_entry = ttk.Entry(system_frame, textvariable=self.threads_var, width=10)
        threads_entry.pack(side=tk.LEFT, padx=5)
        
        # Logging
        log_frame = ttk.LabelFrame(tab, text="Logging")
        log_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.log_level_var = tk.StringVar(value=self.settings.get("log_level", "INFO"))
        ttk.Label(log_frame, text="Log Level:").pack(side=tk.LEFT, padx=5)
        log_combo = ttk.Combobox(log_frame, textvariable=self.log_level_var, values=["DEBUG", "INFO", "WARNING", "ERROR"])
        log_combo.pack(side=tk.LEFT, padx=5)
        
    def create_buttons(self):
        """Create dialog buttons"""
        button_frame = ttk.Frame(self.window)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(button_frame, text="Save", command=self.save_settings).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=self.window.destroy).pack(side=tk.RIGHT, padx=5)
        
    def load_settings(self) -> Dict[str, Any]:
        """Load settings from file"""
        try:
            with open("settings.json", "r") as f:
                return json.load(f)
        except:
            return {}
            
    def save_settings(self):
        """Save settings to file"""
        settings = {
            "theme": self.theme_var.get(),
            "language": self.lang_var.get(),
            "auto_update": self.auto_update_var.get(),
            "deploy_on_install": self.deploy_on_install_var.get(),
            "auto_deploy": self.auto_deploy_var.get(),
            "max_threads": int(self.threads_var.get()),
            "log_level": self.log_level_var.get()
        }
        
        with open("settings.json", "w") as f:
            json.dump(settings, f, indent=4)
            
        self.window.destroy() 