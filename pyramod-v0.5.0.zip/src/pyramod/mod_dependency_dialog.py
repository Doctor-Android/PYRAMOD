from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
    QPushButton, QListWidget, QMessageBox, QComboBox, QCheckBox,
    QTreeWidget, QTreeWidgetItem, QFileDialog
)
from PyQt6.QtCore import Qt
from pathlib import Path
from typing import List, Optional
from mod_dependency_manager import ModDependencyManager, ModDependency

class ModDependencyDialog(QDialog):
    def __init__(self, dependency_manager: ModDependencyManager, parent=None):
        super().__init__(parent)
        self.dependency_manager = dependency_manager
        self.setWindowTitle("Mod Dependency Manager")
        self.setMinimumWidth(800)
        self.setMinimumHeight(600)
        
        # Initialize UI
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Mod selection
        mod_layout = QHBoxLayout()
        mod_layout.addWidget(QLabel("Mod ID:"))
        self.mod_id_input = QLineEdit()
        mod_layout.addWidget(self.mod_id_input)
        self.load_deps_button = QPushButton("Load Dependencies")
        self.load_deps_button.clicked.connect(self.load_dependencies)
        mod_layout.addWidget(self.load_deps_button)
        layout.addLayout(mod_layout)
        
        # Dependency tree
        self.dependency_tree = QTreeWidget()
        self.dependency_tree.setHeaderLabels(["Mod ID", "Version", "Required", "Optional", "Conflicts"])
        layout.addWidget(self.dependency_tree)
        
        # Dependency management
        dep_management_layout = QHBoxLayout()
        
        # Add dependency
        add_dep_layout = QVBoxLayout()
        add_dep_layout.addWidget(QLabel("Add Dependency"))
        
        dep_id_layout = QHBoxLayout()
        dep_id_layout.addWidget(QLabel("Mod ID:"))
        self.new_dep_id = QLineEdit()
        dep_id_layout.addWidget(self.new_dep_id)
        add_dep_layout.addLayout(dep_id_layout)
        
        dep_version_layout = QHBoxLayout()
        dep_version_layout.addWidget(QLabel("Version:"))
        self.new_dep_version = QLineEdit()
        dep_version_layout.addWidget(self.new_dep_version)
        add_dep_layout.addLayout(dep_version_layout)
        
        self.new_dep_required = QCheckBox("Required")
        add_dep_layout.addWidget(self.new_dep_required)
        
        self.new_dep_optional = QCheckBox("Optional")
        add_dep_layout.addWidget(self.new_dep_optional)
        
        self.add_dep_button = QPushButton("Add Dependency")
        self.add_dep_button.clicked.connect(self.add_dependency)
        add_dep_layout.addWidget(self.add_dep_button)
        
        dep_management_layout.addLayout(add_dep_layout)
        
        # Remove dependency
        remove_dep_layout = QVBoxLayout()
        remove_dep_layout.addWidget(QLabel("Remove Dependency"))
        self.remove_dep_button = QPushButton("Remove Selected")
        self.remove_dep_button.clicked.connect(self.remove_dependency)
        remove_dep_layout.addWidget(self.remove_dep_button)
        dep_management_layout.addLayout(remove_dep_layout)
        
        layout.addLayout(dep_management_layout)
        
        # Import/Export
        io_layout = QHBoxLayout()
        self.import_button = QPushButton("Import Dependencies")
        self.import_button.clicked.connect(self.import_dependencies)
        io_layout.addWidget(self.import_button)
        
        self.export_button = QPushButton("Export Dependencies")
        self.export_button.clicked.connect(self.export_dependencies)
        io_layout.addWidget(self.export_button)
        
        layout.addLayout(io_layout)
        
        # Close button
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button)
        
        self.setLayout(layout)
        
    def load_dependencies(self):
        mod_id = self.mod_id_input.text().strip()
        if not mod_id:
            QMessageBox.warning(self, "Error", "Please enter a mod ID")
            return
            
        self.dependency_tree.clear()
        dependencies = self.dependency_manager.get_mod_dependencies(mod_id)
        
        for dep in dependencies:
            item = QTreeWidgetItem([
                dep.mod_id,
                dep.version,
                "Yes" if dep.required else "No",
                "Yes" if dep.optional else "No",
                ", ".join(dep.conflicts) if dep.conflicts else "None"
            ])
            self.dependency_tree.addTopLevelItem(item)
            
        # Show dependency tree
        tree = self.dependency_manager.get_dependency_tree(mod_id)
        if tree:
            self.show_dependency_tree(tree)
            
    def show_dependency_tree(self, tree: dict):
        root = QTreeWidgetItem(["Dependency Tree", "", "", "", ""])
        self.dependency_tree.addTopLevelItem(root)
        
        def add_children(parent: QTreeWidgetItem, deps: dict):
            for mod_id, children in deps.items():
                child = QTreeWidgetItem([mod_id, "", "", "", ""])
                parent.addChild(child)
                if children:
                    add_children(child, {child: [] for child in children})
                    
        add_children(root, tree)
        root.setExpanded(True)
        
    def add_dependency(self):
        mod_id = self.mod_id_input.text().strip()
        if not mod_id:
            QMessageBox.warning(self, "Error", "Please enter a mod ID")
            return
            
        dep_id = self.new_dep_id.text().strip()
        if not dep_id:
            QMessageBox.warning(self, "Error", "Please enter a dependency mod ID")
            return
            
        version = self.new_dep_version.text().strip()
        if not version:
            QMessageBox.warning(self, "Error", "Please enter a version")
            return
            
        required = self.new_dep_required.isChecked()
        optional = self.new_dep_optional.isChecked()
        
        dependency = ModDependency(
            mod_id=dep_id,
            version=version,
            required=required,
            optional=optional
        )
        
        if self.dependency_manager.add_mod_dependencies(mod_id, [dependency]):
            QMessageBox.information(self, "Success", "Dependency added successfully")
            self.load_dependencies()
        else:
            QMessageBox.warning(self, "Error", "Failed to add dependency")
            
    def remove_dependency(self):
        mod_id = self.mod_id_input.text().strip()
        if not mod_id:
            QMessageBox.warning(self, "Error", "Please enter a mod ID")
            return
            
        selected_items = self.dependency_tree.selectedItems()
        if not selected_items:
            QMessageBox.warning(self, "Error", "Please select a dependency to remove")
            return
            
        dep_id = selected_items[0].text(0)
        dependencies = self.dependency_manager.get_mod_dependencies(mod_id)
        dependencies = [d for d in dependencies if d.mod_id != dep_id]
        
        if self.dependency_manager.add_mod_dependencies(mod_id, dependencies):
            QMessageBox.information(self, "Success", "Dependency removed successfully")
            self.load_dependencies()
        else:
            QMessageBox.warning(self, "Error", "Failed to remove dependency")
            
    def import_dependencies(self):
        mod_id = self.mod_id_input.text().strip()
        if not mod_id:
            QMessageBox.warning(self, "Error", "Please enter a mod ID")
            return
            
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Import Dependencies",
            str(Path.home()),
            "JSON Files (*.json)"
        )
        
        if file_path:
            if self.dependency_manager.import_dependencies(Path(file_path)):
                QMessageBox.information(self, "Success", "Dependencies imported successfully")
                self.load_dependencies()
            else:
                QMessageBox.warning(self, "Error", "Failed to import dependencies")
                
    def export_dependencies(self):
        mod_id = self.mod_id_input.text().strip()
        if not mod_id:
            QMessageBox.warning(self, "Error", "Please enter a mod ID")
            return
            
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export Dependencies",
            str(Path.home() / f"{mod_id}_dependencies.json"),
            "JSON Files (*.json)"
        )
        
        if file_path:
            if self.dependency_manager.export_dependencies(mod_id, Path(file_path).parent):
                QMessageBox.information(self, "Success", "Dependencies exported successfully")
            else:
                QMessageBox.warning(self, "Error", "Failed to export dependencies") 