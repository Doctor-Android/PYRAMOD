#!/usr/bin/env python3

import argparse
import logging
import sys
from pathlib import Path
from proton_compat_db import ProtonCompatDB

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(description="Proton/Wine Compatibility Database CLI")
    subparsers = parser.add_subparsers(dest="command", help="Command to execute")
    
    # Game management commands
    game_parser = subparsers.add_parser("game", help="Game management commands")
    game_subparsers = game_parser.add_subparsers(dest="game_command", help="Game command to execute")
    
    # Add game
    add_game_parser = game_subparsers.add_parser("add", help="Add a new game")
    add_game_parser.add_argument("game_id", help="Unique identifier for the game")
    add_game_parser.add_argument("name", help="Display name of the game")
    add_game_parser.add_argument("--executable", help="Path to the game's executable")
    add_game_parser.add_argument("--steam-appid", help="Steam App ID")
    add_game_parser.add_argument("--gog-id", help="GOG.com game ID")
    add_game_parser.add_argument("--epic-id", help="Epic Games Store ID")
    
    # Get game info
    get_game_parser = game_subparsers.add_parser("info", help="Get game information")
    get_game_parser.add_argument("game_id", help="Game identifier")
    
    # Find game by executable
    find_game_parser = game_subparsers.add_parser("find", help="Find a game")
    find_game_parser.add_argument("--executable", help="Path to the game's executable")
    find_game_parser.add_argument("--store", choices=["steam", "gog", "epic"], help="Store name")
    find_game_parser.add_argument("--store-id", help="Store-specific game ID")
    
    # Set game configuration
    set_config_parser = game_subparsers.add_parser("set-config", help="Set game configuration")
    set_config_parser.add_argument("game_id", help="Game identifier")
    set_config_parser.add_argument("proton_version_id", type=int, help="Proton/Wine version ID")
    set_config_parser.add_argument("key", help="Configuration key")
    set_config_parser.add_argument("value", help="Configuration value")
    
    # Get game configuration
    get_config_parser = game_subparsers.add_parser("get-config", help="Get game configuration")
    get_config_parser.add_argument("game_id", help="Game identifier")
    get_config_parser.add_argument("proton_version_id", type=int, help="Proton/Wine version ID")
    
    # List Proton/Wine versions
    list_parser = subparsers.add_parser("list-versions", help="List Proton/Wine versions")
    list_parser.add_argument("--type", choices=["proton", "wine"], help="Filter by type")
    
    # Add Proton/Wine version
    add_version_parser = subparsers.add_parser("add-version", help="Add a Proton/Wine version")
    add_version_parser.add_argument("name", help="Version name (e.g., 'Proton Experimental')")
    add_version_parser.add_argument("version", help="Version string (e.g., '7.0-5')")
    add_version_parser.add_argument("type", choices=["proton", "wine"], help="Version type")
    add_version_parser.add_argument("--path", help="Path to installation")
    
    # Update installation status
    update_parser = subparsers.add_parser("update-installation", help="Update installation status")
    update_parser.add_argument("version_id", type=int, help="Version ID")
    update_parser.add_argument("--installed", action="store_true", help="Mark as installed")
    update_parser.add_argument("--path", help="Path to installation")
    
    # Add game compatibility
    game_compat_parser = subparsers.add_parser("add-game-compat", help="Add game compatibility")
    game_compat_parser.add_argument("game_id", help="Game identifier")
    game_compat_parser.add_argument("version_id", type=int, help="Proton/Wine version ID")
    game_compat_parser.add_argument("level", choices=["perfect", "good", "playable", "broken"],
                                  help="Compatibility level")
    game_compat_parser.add_argument("--notes", help="Compatibility notes")
    game_compat_parser.add_argument("--reporter", default="system", help="Who reported the compatibility")
    
    # Add mod compatibility
    mod_compat_parser = subparsers.add_parser("add-mod-compat", help="Add mod compatibility")
    mod_compat_parser.add_argument("mod_id", help="Mod identifier")
    mod_compat_parser.add_argument("game_id", help="Game identifier")
    mod_compat_parser.add_argument("version_id", type=int, help="Proton/Wine version ID")
    mod_compat_parser.add_argument("level", choices=["perfect", "good", "playable", "broken"],
                                 help="Compatibility level")
    mod_compat_parser.add_argument("--notes", help="Compatibility notes")
    mod_compat_parser.add_argument("--reporter", default="system", help="Who reported the compatibility")
    
    # Get game compatibility
    get_game_parser = subparsers.add_parser("get-game-compat", help="Get game compatibility")
    get_game_parser.add_argument("game_id", help="Game identifier")
    
    # Get mod compatibility
    get_mod_parser = subparsers.add_parser("get-mod-compat", help="Get mod compatibility")
    get_mod_parser.add_argument("mod_id", help="Mod identifier")
    get_mod_parser.add_argument("game_id", help="Game identifier")
    
    # Add compatibility report
    report_parser = subparsers.add_parser("add-report", help="Add compatibility report")
    report_parser.add_argument("type", choices=["game", "mod"], help="Report type")
    report_parser.add_argument("target_id", help="Game or mod identifier")
    report_parser.add_argument("version_id", type=int, help="Proton/Wine version ID")
    report_parser.add_argument("level", choices=["perfect", "good", "playable", "broken"],
                             help="Compatibility level")
    report_parser.add_argument("--notes", help="Report notes")
    report_parser.add_argument("--reporter", default="user", help="Who reported the compatibility")
    
    # Verify compatibility report
    verify_parser = subparsers.add_parser("verify-report", help="Verify compatibility report")
    verify_parser.add_argument("report_id", type=int, help="Report ID")
    verify_parser.add_argument("verifier", help="Who verified the report")
    
    # Get best version
    best_parser = subparsers.add_parser("get-best-version", help="Get best Proton/Wine version")
    best_parser.add_argument("game_id", help="Game identifier")
    best_parser.add_argument("--mod-id", help="Optional mod identifier")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    # Initialize database
    db = ProtonCompatDB()
    
    try:
        if args.command == "game":
            if args.game_command == "add":
                game_id = db.add_game(
                    args.game_id,
                    args.name,
                    args.executable,
                    args.steam_appid,
                    args.gog_id,
                    args.epic_id
                )
                print(f"Added game with ID: {game_id}")
            
            elif args.game_command == "info":
                game = db.get_game(args.game_id)
                if game:
                    print(f"Game ID: {game['game_id']}")
                    print(f"Name: {game['name']}")
                    if game['executable']:
                        print(f"Executable: {game['executable']}")
                    if game['steam_appid']:
                        print(f"Steam App ID: {game['steam_appid']}")
                    if game['gog_id']:
                        print(f"GOG ID: {game['gog_id']}")
                    if game['epic_id']:
                        print(f"Epic ID: {game['epic_id']}")
                else:
                    print("Game not found")
            
            elif args.game_command == "find":
                if args.executable:
                    game = db.find_game_by_executable(args.executable)
                elif args.store and args.store_id:
                    game = db.find_game_by_store_id(args.store, args.store_id)
                else:
                    print("Please specify either --executable or both --store and --store-id")
                    sys.exit(1)
                
                if game:
                    print(f"Game ID: {game['game_id']}")
                    print(f"Name: {game['name']}")
                    if game['executable']:
                        print(f"Executable: {game['executable']}")
                    if game['steam_appid']:
                        print(f"Steam App ID: {game['steam_appid']}")
                    if game['gog_id']:
                        print(f"GOG ID: {game['gog_id']}")
                    if game['epic_id']:
                        print(f"Epic ID: {game['epic_id']}")
                else:
                    print("Game not found")
            
            elif args.game_command == "set-config":
                db.set_game_configuration(
                    args.game_id,
                    args.proton_version_id,
                    args.key,
                    args.value
                )
                print("Configuration set")
            
            elif args.game_command == "get-config":
                config = db.get_game_configuration(args.game_id, args.proton_version_id)
                for key, value in config.items():
                    print(f"{key}: {value}")
        
        elif args.command == "list-versions":
            versions = db.get_proton_versions(type=args.type)
            for version in versions:
                print(f"ID: {version['id']}")
                print(f"Name: {version['name']}")
                print(f"Version: {version['version']}")
                print(f"Type: {version['type']}")
                print(f"Installed: {version['is_installed']}")
                if version['path']:
                    print(f"Path: {version['path']}")
                print()
        
        elif args.command == "add-version":
            version_id = db.add_proton_version(
                args.name,
                args.version,
                args.type,
                args.path
            )
            print(f"Added version with ID: {version_id}")
        
        elif args.command == "update-installation":
            db.update_proton_installation(
                args.version_id,
                args.installed,
                args.path
            )
            print("Updated installation status")
        
        elif args.command == "add-game-compat":
            compat_id = db.add_game_compatibility(
                args.game_id,
                args.version_id,
                args.level,
                args.notes,
                args.reporter
            )
            print(f"Added game compatibility with ID: {compat_id}")
        
        elif args.command == "add-mod-compat":
            compat_id = db.add_mod_compatibility(
                args.mod_id,
                args.game_id,
                args.version_id,
                args.level,
                args.notes,
                args.reporter
            )
            print(f"Added mod compatibility with ID: {compat_id}")
        
        elif args.command == "get-game-compat":
            compat = db.get_game_compatibility(args.game_id)
            for entry in compat:
                print(f"Proton Version: {entry['proton_name']} {entry['proton_version']}")
                print(f"Compatibility: {entry['compatibility_level']}")
                if entry['notes']:
                    print(f"Notes: {entry['notes']}")
                print(f"Reported by: {entry['reported_by']}")
                print(f"Date: {entry['report_date']}")
                print()
        
        elif args.command == "get-mod-compat":
            compat = db.get_mod_compatibility(args.mod_id, args.game_id)
            for entry in compat:
                print(f"Proton Version: {entry['proton_name']} {entry['proton_version']}")
                print(f"Compatibility: {entry['compatibility_level']}")
                if entry['notes']:
                    print(f"Notes: {entry['notes']}")
                print(f"Reported by: {entry['reported_by']}")
                print(f"Date: {entry['report_date']}")
                print()
        
        elif args.command == "add-report":
            report_id = db.add_compatibility_report(
                args.type,
                args.target_id,
                args.version_id,
                args.level,
                args.notes,
                args.reporter
            )
            print(f"Added report with ID: {report_id}")
        
        elif args.command == "verify-report":
            db.verify_compatibility_report(args.report_id, args.verifier)
            print("Report verified")
        
        elif args.command == "get-best-version":
            best_version = db.get_best_proton_version(args.game_id, args.mod_id)
            if best_version:
                print(f"Best version: {best_version['name']} {best_version['version']}")
                if 'game_compatibility' in best_version:
                    print(f"Game compatibility: {best_version['game_compatibility']}")
                if 'mod_compatibility' in best_version:
                    print(f"Mod compatibility: {best_version['mod_compatibility']}")
            else:
                print("No compatible version found")
    
    except Exception as e:
        logging.error(f"Error: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    setup_logging()
    main() 