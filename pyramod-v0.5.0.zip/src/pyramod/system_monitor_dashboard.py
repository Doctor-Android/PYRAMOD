#!/usr/bin/env python3
import os
import json
import time
import psutil
import logging
import tkinter as tk
from tkinter import ttk
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union
import GPUtil
import threading

class SystemMonitorDashboard:
    """Modern system resource monitoring dashboard with real-time updates."""
    
    def __init__(self, root: tk.Tk):
        """Initialize the dashboard.
        
        Args:
            root: Tkinter root window
        """
        self.root = root
        self.root.title("System Resource Monitor")
        
        # Initialize logging
        self.logger = logging.getLogger("system_monitor_dashboard")
        
        # Initialize monitoring state
        self.monitoring = False
        self.metrics_history = []
        
        # Create GUI elements
        self._create_layout()
        
        # Start monitoring
        self.start_monitoring()
    
    def _create_layout(self):
        """Create the dashboard layout."""
        # Main container
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # System Resources Section
        system_frame = ttk.LabelFrame(main_frame, text="System Resources", padding="5")
        system_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # CPU Usage
        cpu_frame = ttk.Frame(system_frame)
        cpu_frame.pack(fill=tk.X, padx=5, pady=2)
        ttk.Label(cpu_frame, text="CPU Usage:").pack(side=tk.LEFT)
        self.cpu_label = ttk.Label(cpu_frame, text="0%")
        self.cpu_label.pack(side=tk.LEFT, padx=5)
        self.cpu_bar = ttk.Progressbar(cpu_frame, length=300, mode='determinate')
        self.cpu_bar.pack(side=tk.LEFT, padx=5)
        
        # Memory Usage
        mem_frame = ttk.Frame(system_frame)
        mem_frame.pack(fill=tk.X, padx=5, pady=2)
        ttk.Label(mem_frame, text="Memory Usage:").pack(side=tk.LEFT)
        self.mem_label = ttk.Label(mem_frame, text="0/0 GB")
        self.mem_label.pack(side=tk.LEFT, padx=5)
        self.mem_bar = ttk.Progressbar(mem_frame, length=300, mode='determinate')
        self.mem_bar.pack(side=tk.LEFT, padx=5)
        
        # Disk Usage
        disk_frame = ttk.Frame(system_frame)
        disk_frame.pack(fill=tk.X, padx=5, pady=2)
        ttk.Label(disk_frame, text="Disk Usage:").pack(side=tk.LEFT)
        self.disk_label = ttk.Label(disk_frame, text="0/0 GB")
        self.disk_label.pack(side=tk.LEFT, padx=5)
        self.disk_bar = ttk.Progressbar(disk_frame, length=300, mode='determinate')
        self.disk_bar.pack(side=tk.LEFT, padx=5)
        
        # GPU Section (if available)
        try:
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu_frame = ttk.LabelFrame(main_frame, text="GPU Resources", padding="5")
                gpu_frame.pack(fill=tk.X, padx=5, pady=5)
                
                self.gpu_frames = []
                self.gpu_labels = []
                self.gpu_bars = []
                
                for i, gpu in enumerate(gpus):
                    gpu_subframe = ttk.Frame(gpu_frame)
                    gpu_subframe.pack(fill=tk.X, padx=5, pady=2)
                    
                    ttk.Label(gpu_subframe, text=f"GPU {i} ({gpu.name}):").pack(side=tk.LEFT)
                    gpu_label = ttk.Label(gpu_subframe, text="0%")
                    gpu_label.pack(side=tk.LEFT, padx=5)
                    gpu_bar = ttk.Progressbar(gpu_subframe, length=300, mode='determinate')
                    gpu_bar.pack(side=tk.LEFT, padx=5)
                    
                    self.gpu_frames.append(gpu_subframe)
                    self.gpu_labels.append(gpu_label)
                    self.gpu_bars.append(gpu_bar)
        except Exception as e:
            self.logger.warning(f"GPU monitoring not available: {e}")
        
        # Process List Section
        process_frame = ttk.LabelFrame(main_frame, text="Top Processes", padding="5")
        process_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # Create Treeview for processes
        columns = ('PID', 'Name', 'CPU %', 'Memory %', 'Status')
        self.process_tree = ttk.Treeview(process_frame, columns=columns, show='headings')
        
        # Configure columns
        for col in columns:
            self.process_tree.heading(col, text=col)
            self.process_tree.column(col, width=100)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(process_frame, orient=tk.VERTICAL, command=self.process_tree.yview)
        self.process_tree.configure(yscrollcommand=scrollbar.set)
        
        # Pack the tree and scrollbar
        self.process_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # Status Bar
        self.status_bar = ttk.Label(self.root, text="Ready", relief=tk.SUNKEN, anchor=tk.W)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
    
    def start_monitoring(self):
        """Start the monitoring thread."""
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop the monitoring thread."""
        self.monitoring = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join()
    
    def _monitoring_loop(self):
        """Main monitoring loop."""
        while self.monitoring:
            try:
                # Update CPU usage
                cpu_percent = psutil.cpu_percent(interval=None)
                self.cpu_label.config(text=f"{cpu_percent:.1f}%")
                self.cpu_bar['value'] = cpu_percent
                
                # Update memory usage
                mem = psutil.virtual_memory()
                mem_percent = mem.percent
                mem_used_gb = mem.used / (1024 ** 3)
                mem_total_gb = mem.total / (1024 ** 3)
                self.mem_label.config(text=f"{mem_used_gb:.1f}/{mem_total_gb:.1f} GB")
                self.mem_bar['value'] = mem_percent
                
                # Update disk usage
                disk = psutil.disk_usage('/')
                disk_percent = disk.percent
                disk_used_gb = disk.used / (1024 ** 3)
                disk_total_gb = disk.total / (1024 ** 3)
                self.disk_label.config(text=f"{disk_used_gb:.1f}/{disk_total_gb:.1f} GB")
                self.disk_bar['value'] = disk_percent
                
                # Update GPU usage if available
                if hasattr(self, 'gpu_labels'):
                    try:
                        gpus = GPUtil.getGPUs()
                        for i, gpu in enumerate(gpus):
                            if i < len(self.gpu_labels):
                                gpu_load = gpu.load * 100
                                self.gpu_labels[i].config(text=f"{gpu_load:.1f}%")
                                self.gpu_bars[i]['value'] = gpu_load
                    except Exception as e:
                        self.logger.error(f"Error updating GPU metrics: {e}")
                
                # Update process list
                self.process_tree.delete(*self.process_tree.get_children())
                for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 'status']):
                    try:
                        self.process_tree.insert('', 'end', values=(
                            proc.info['pid'],
                            proc.info['name'],
                            f"{proc.info['cpu_percent']:.1f}%",
                            f"{proc.info['memory_percent']:.1f}%",
                            proc.info['status']
                        ))
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                
                # Update status bar
                self.status_bar.config(text=f"Last update: {datetime.now().strftime('%H:%M:%S')}")
                
                # Sleep before next update
                time.sleep(1)
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)  # Sleep longer on error

def main():
    """Main entry point."""
    root = tk.Tk()
    app = SystemMonitorDashboard(root)
    root.mainloop()

if __name__ == "__main__":
    main() 