from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QListWidget, QPushButton, QFileDialog, QMessageBox)
from PyQt6.QtCore import Qt
import json
import shutil
from pathlib import Path
import datetime

class ModpackBackupDialog(QDialog):
    def __init__(self, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Backup/Restore Modpacks")
        self.setGeometry(200, 200, 600, 500)
        
        self.modpack_manager = modpack_manager
        self.backup_dir = Path.home() / ".pyramod" / "backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Backup section
        backup_layout = QVBoxLayout()
        backup_layout.addWidget(QLabel("Backup All Modpacks:"))
        
        backup_btn = QPushButton("Create Backup")
        backup_btn.clicked.connect(self.create_backup)
        backup_layout.addWidget(backup_btn)
        layout.addLayout(backup_layout)
        
        # Restore section
        restore_layout = QVBoxLayout()
        restore_layout.addWidget(QLabel("Available Backups:"))
        
        self.backup_list = QListWidget()
        self.update_backup_list()
        restore_layout.addWidget(self.backup_list)
        
        restore_btn = QPushButton("Restore Selected Backup")
        restore_btn.clicked.connect(self.restore_backup)
        restore_layout.addWidget(restore_btn)
        layout.addLayout(restore_layout)
        
        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn)
        
        self.setLayout(layout)
        
    def update_backup_list(self):
        self.backup_list.clear()
        for backup in sorted(self.backup_dir.glob("*.json"), reverse=True):
            self.backup_list.addItem(backup.stem)
            
    def create_backup(self):
        try:
            # Create backup file name with timestamp
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_file = self.backup_dir / f"modpacks_{timestamp}.json"
            
            # Get all modpacks
            modpacks = {}
            for modpack_name in self.modpack_manager.get_modpacks():
                modpacks[modpack_name] = self.modpack_manager.get_modpack_info(modpack_name)
                
            # Save to backup file
            with open(backup_file, 'w') as f:
                json.dump(modpacks, f, indent=4)
                
            QMessageBox.information(self, "Success", "Backup created successfully!")
            self.update_backup_list()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to create backup: {str(e)}")
            
    def restore_backup(self):
        selected = self.backup_list.selectedItems()
        if not selected:
            QMessageBox.warning(self, "Error", "Please select a backup to restore")
            return
            
        backup_name = selected[0].text()
        backup_file = self.backup_dir / f"{backup_name}.json"
        
        reply = QMessageBox.question(
            self,
            "Confirm Restore",
            "This will overwrite all current modpacks. Are you sure?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                # Load backup
                with open(backup_file, 'r') as f:
                    modpacks = json.load(f)
                    
                # Delete current modpacks
                for modpack_name in self.modpack_manager.get_modpacks():
                    self.modpack_manager.delete_modpack(modpack_name)
                    
                # Restore from backup
                for modpack_name, modpack_info in modpacks.items():
                    self.modpack_manager.create_modpack(
                        modpack_name,
                        modpack_info["description"],
                        modpack_info["mods"]
                    )
                    
                QMessageBox.information(self, "Success", "Backup restored successfully!")
                self.accept()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Failed to restore backup: {str(e)}") 