from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QCheckBox, QMessageBox, QGroupBox, QSpinBox,
    QTextEdit, QTabWidget, QWidget, QFormLayout
)
from PyQt6.QtCore import Qt
from mod_source_manager import ModSourceManager

class ModSourceDialog(QDialog):
    def __init__(self, source_manager: ModSourceManager, parent=None):
        super().__init__(parent)
        self.source_manager = source_manager
        self.setWindowTitle("Mod Source Settings")
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)
        
        # Initialize UI
        self.init_ui()
        
        # Load current settings
        self.load_settings()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Create tab widget
        self.tab_widget = QTabWidget()
        
        # Nexus Mods tab
        nexus_tab = QWidget()
        nexus_layout = QVBoxLayout()
        
        # API Key
        api_key_layout = QHBoxLayout()
        api_key_layout.addWidget(QLabel("API Key:"))
        self.nexus_api_key = QLineEdit()
        self.nexus_api_key.setEchoMode(QLineEdit.EchoMode.Password)
        api_key_layout.addWidget(self.nexus_api_key)
        nexus_layout.addLayout(api_key_layout)
        
        # Rate limit
        rate_limit_layout = QHBoxLayout()
        rate_limit_layout.addWidget(QLabel("Rate Limit (requests/hour):"))
        self.nexus_rate_limit = QSpinBox()
        self.nexus_rate_limit.setRange(1, 1000)
        rate_limit_layout.addWidget(self.nexus_rate_limit)
        nexus_layout.addLayout(rate_limit_layout)
        
        # Enable/Disable
        self.nexus_enabled = QCheckBox("Enable Nexus Mods")
        nexus_layout.addWidget(self.nexus_enabled)
        
        nexus_tab.setLayout(nexus_layout)
        self.tab_widget.addTab(nexus_tab, "Nexus Mods")
        
        # Google Docs tab
        docs_tab = QWidget()
        docs_layout = QVBoxLayout()
        
        # Spreadsheet ID
        spreadsheet_layout = QHBoxLayout()
        spreadsheet_layout.addWidget(QLabel("Spreadsheet ID:"))
        self.docs_spreadsheet_id = QLineEdit()
        spreadsheet_layout.addWidget(self.docs_spreadsheet_id)
        docs_layout.addLayout(spreadsheet_layout)
        
        # Sheet name
        sheet_layout = QHBoxLayout()
        sheet_layout.addWidget(QLabel("Sheet Name:"))
        self.docs_sheet_name = QLineEdit()
        sheet_layout.addWidget(self.docs_sheet_name)
        docs_layout.addLayout(sheet_layout)
        
        # Enable/Disable
        self.docs_enabled = QCheckBox("Enable Google Docs")
        docs_layout.addWidget(self.docs_enabled)
        
        docs_tab.setLayout(docs_layout)
        self.tab_widget.addTab(docs_tab, "Google Docs")
        
        # Other Sites tab
        other_tab = QWidget()
        other_layout = QVBoxLayout()
        
        # URL patterns
        patterns_group = QGroupBox("URL Patterns")
        patterns_layout = QVBoxLayout()
        self.patterns_text = QTextEdit()
        patterns_layout.addWidget(self.patterns_text)
        patterns_group.setLayout(patterns_layout)
        other_layout.addWidget(patterns_group)
        
        # Enable/Disable
        self.other_enabled = QCheckBox("Enable Other Sites")
        other_layout.addWidget(self.other_enabled)
        
        other_tab.setLayout(other_layout)
        self.tab_widget.addTab(other_tab, "Other Sites")
        
        layout.addWidget(self.tab_widget)
        
        # Buttons
        buttons_layout = QHBoxLayout()
        
        save_button = QPushButton("Save")
        save_button.clicked.connect(self.save_settings)
        buttons_layout.addWidget(save_button)
        
        cancel_button = QPushButton("Cancel")
        cancel_button.clicked.connect(self.reject)
        buttons_layout.addWidget(cancel_button)
        
        layout.addLayout(buttons_layout)
        
        self.setLayout(layout)
        
    def load_settings(self):
        """Load current source settings"""
        # Nexus Mods
        nexus_config = self.source_manager.get_source_config("nexus")
        if nexus_config:
            self.nexus_api_key.setText(nexus_config.get("api_key", ""))
            self.nexus_rate_limit.setValue(nexus_config.get("rate_limit", 100))
            self.nexus_enabled.setChecked(nexus_config.get("enabled", True))
            
        # Google Docs
        docs_config = self.source_manager.get_source_config("google_docs")
        if docs_config:
            self.docs_spreadsheet_id.setText(docs_config.get("spreadsheet_id", ""))
            self.docs_sheet_name.setText(docs_config.get("sheet_name", "Mods"))
            self.docs_enabled.setChecked(docs_config.get("enabled", True))
            
        # Other Sites
        other_config = self.source_manager.get_source_config("other_sites")
        if other_config:
            self.patterns_text.setText("\n".join(other_config.get("patterns", [])))
            self.other_enabled.setChecked(other_config.get("enabled", True))
            
    def save_settings(self):
        """Save new source settings"""
        try:
            # Save Nexus Mods settings
            self.source_manager.set_source_config("nexus", {
                "api_key": self.nexus_api_key.text(),
                "rate_limit": self.nexus_rate_limit.value(),
                "enabled": self.nexus_enabled.isChecked()
            })
            
            # Save Google Docs settings
            self.source_manager.set_source_config("google_docs", {
                "spreadsheet_id": self.docs_spreadsheet_id.text(),
                "sheet_name": self.docs_sheet_name.text(),
                "enabled": self.docs_enabled.isChecked()
            })
            
            # Save Other Sites settings
            patterns = [p.strip() for p in self.patterns_text.toPlainText().split("\n") if p.strip()]
            self.source_manager.set_source_config("other_sites", {
                "patterns": patterns,
                "enabled": self.other_enabled.isChecked()
            })
            
            QMessageBox.information(self, "Success", "Settings saved successfully")
            self.accept()
            
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings: {str(e)}") 