import os
import json
import shutil
from datetime import datetime
from typing import Dict, List, Optional
from error_handler import ProfileError, error_handler

class ModProfile:
    def __init__(self, profiles_dir: str = "profiles"):
        self.profiles_dir = profiles_dir
        if not os.path.exists(profiles_dir):
            os.makedirs(profiles_dir)

    def create_profile(self, game_name: str, profile_name: str, mods_dir: str) -> Dict:
        """Create a new mod profile"""
        try:
            # Validate profile name
            profile_name = self._sanitize_name(profile_name)
            profile_dir = os.path.join(self.profiles_dir, game_name, profile_name)

            if os.path.exists(profile_dir):
                raise ProfileError(f"Profile {profile_name} already exists")

            # Create profile directory
            os.makedirs(profile_dir)

            # Create mod list
            mod_list = []
            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    # Read mod manifest
                    manifest_path = os.path.join(mod_path, "manifest.json")
                    if os.path.exists(manifest_path):
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                            mod_list.append({
                                "name": mod,
                                "version": manifest.get("version", "1.0.0"),
                                "enabled": True
                            })

            # Save profile data
            profile_data = {
                "name": profile_name,
                "game": game_name,
                "created": datetime.now().isoformat(),
                "mods": mod_list
            }

            with open(os.path.join(profile_dir, "profile.json"), "w") as f:
                json.dump(profile_data, f, indent=4)

            error_handler.log_info(f"Created profile: {profile_name}")
            return profile_data

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "profile": profile_name,
                "mods_dir": mods_dir
            })
            raise

    def load_profile(self, game_name: str, profile_name: str, mods_dir: str) -> bool:
        """Load a mod profile"""
        try:
            profile_dir = os.path.join(self.profiles_dir, game_name, profile_name)
            if not os.path.exists(profile_dir):
                raise ProfileError(f"Profile {profile_name} not found")

            # Read profile data
            with open(os.path.join(profile_dir, "profile.json"), "r") as f:
                profile_data = json.load(f)

            # Backup current mods
            backup_dir = f"{mods_dir}.backup"
            if os.path.exists(backup_dir):
                shutil.rmtree(backup_dir)
            if os.path.exists(mods_dir):
                shutil.move(mods_dir, backup_dir)

            # Create new mods directory
            os.makedirs(mods_dir)

            # Copy mods from profile
            for mod in profile_data["mods"]:
                if mod["enabled"]:
                    mod_path = os.path.join(profile_dir, "mods", mod["name"])
                    if os.path.exists(mod_path):
                        shutil.copytree(mod_path, os.path.join(mods_dir, mod["name"]))

            error_handler.log_info(f"Loaded profile: {profile_name}")
            return True

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "profile": profile_name,
                "mods_dir": mods_dir
            })
            return False

    def delete_profile(self, game_name: str, profile_name: str) -> bool:
        """Delete a mod profile"""
        try:
            profile_dir = os.path.join(self.profiles_dir, game_name, profile_name)
            if not os.path.exists(profile_dir):
                raise ProfileError(f"Profile {profile_name} not found")

            shutil.rmtree(profile_dir)
            error_handler.log_info(f"Deleted profile: {profile_name}")
            return True

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "profile": profile_name
            })
            return False

    def list_profiles(self, game_name: str) -> List[Dict]:
        """List all profiles for a game"""
        profiles = []
        game_profiles_dir = os.path.join(self.profiles_dir, game_name)

        if not os.path.exists(game_profiles_dir):
            return profiles

        for profile in os.listdir(game_profiles_dir):
            profile_dir = os.path.join(game_profiles_dir, profile)
            if os.path.isdir(profile_dir):
                try:
                    with open(os.path.join(profile_dir, "profile.json"), "r") as f:
                        profile_data = json.load(f)
                        profiles.append({
                            "name": profile,
                            "game": game_name,
                            "created": profile_data.get("created", ""),
                            "mod_count": len(profile_data.get("mods", []))
                        })
                except Exception as e:
                    error_handler.log_warning(f"Error reading profile {profile}: {str(e)}")
                    continue

        return sorted(profiles, key=lambda x: x["created"], reverse=True)

    def update_profile(self, game_name: str, profile_name: str, mods_dir: str) -> bool:
        """Update a profile with current mods"""
        try:
            profile_dir = os.path.join(self.profiles_dir, game_name, profile_name)
            if not os.path.exists(profile_dir):
                raise ProfileError(f"Profile {profile_name} not found")

            # Create mod list
            mod_list = []
            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    # Read mod manifest
                    manifest_path = os.path.join(mod_path, "manifest.json")
                    if os.path.exists(manifest_path):
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                            mod_list.append({
                                "name": mod,
                                "version": manifest.get("version", "1.0.0"),
                                "enabled": True
                            })

            # Update profile data
            profile_data = {
                "name": profile_name,
                "game": game_name,
                "created": datetime.now().isoformat(),
                "mods": mod_list
            }

            with open(os.path.join(profile_dir, "profile.json"), "w") as f:
                json.dump(profile_data, f, indent=4)

            error_handler.log_info(f"Updated profile: {profile_name}")
            return True

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "profile": profile_name,
                "mods_dir": mods_dir
            })
            return False

    def _sanitize_name(self, name: str) -> str:
        """Sanitize profile name for filesystem"""
        # Replace invalid characters
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            name = name.replace(char, "_")
        return name

# Create a global mod profile instance
mod_profile = ModProfile() 