#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from mod_deployment import ModDeployment

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    parser = argparse.ArgumentParser(description='Mod Deployment CLI')
    parser.add_argument('--game-path', required=True, help='Path to game directory')
    parser.add_argument('--mods-path', required=True, help='Path to mods directory')
    parser.add_argument('--action', required=True, choices=['deploy', 'undeploy', 'verify', 'status'],
                      help='Action to perform')
    parser.add_argument('--mod-path', required=True, help='Path to mod directory')
    parser.add_argument('--exclude', nargs='+', help='File patterns to exclude')

    args = parser.parse_args()

    # Setup logging
    setup_logging()
    logger = logging.getLogger("DeployCLI")

    # Initialize deployment system
    try:
        deployment = ModDeployment(args.game_path, args.mods_path)
    except Exception as e:
        logger.error(f"Failed to initialize deployment system: {e}")
        sys.exit(1)

    # Perform requested action
    if args.action == 'deploy':
        rules = {"exclude_patterns": args.exclude} if args.exclude else None
        if deployment.deploy_mod(args.mod_path, rules):
            logger.info(f"Successfully deployed mod: {args.mod_path}")
        else:
            logger.error(f"Failed to deploy mod: {args.mod_path}")
            sys.exit(1)

    elif args.action == 'undeploy':
        if deployment.undeploy_mod(args.mod_path):
            logger.info(f"Successfully undeployed mod: {args.mod_path}")
        else:
            logger.error(f"Failed to undeploy mod: {args.mod_path}")
            sys.exit(1)

    elif args.action == 'verify':
        is_valid, issues = deployment.verify_deployment(args.mod_path)
        if is_valid:
            logger.info(f"Mod deployment is valid: {args.mod_path}")
        else:
            logger.error(f"Mod deployment has issues: {args.mod_path}")
            for issue in issues:
                logger.error(f"  - {issue}")
            sys.exit(1)

    elif args.action == 'status':
        status = deployment.get_deployment_status(args.mod_path)
        logger.info(f"Deployment status for {args.mod_path}:")
        for key, value in status.items():
            logger.info(f"  {key}: {value}")

if __name__ == '__main__':
    main() 