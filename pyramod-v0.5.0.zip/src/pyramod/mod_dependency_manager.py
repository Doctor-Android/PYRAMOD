import json
from pathlib import Path
from typing import Dict, List, Optional, Set
import logging
from dataclasses import dataclass
import networkx as nx
from datetime import datetime

@dataclass
class ModDependency:
    mod_id: str
    version: str
    required: bool
    optional: bool = False
    conflicts: List[str] = None

class ModDependencyManager:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.dependencies_path = base_path / "dependencies"
        self.dependencies_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=self.base_path / "dependency_manager.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Initialize dependency graph
        self.dependency_graph = nx.DiGraph()
        
    def add_mod_dependencies(self, mod_id: str, dependencies: List[ModDependency]) -> bool:
        """Add dependencies for a mod"""
        try:
            # Create dependency file
            dep_file = self.dependencies_path / f"{mod_id}.json"
            with open(dep_file, 'w') as f:
                json.dump([dep.__dict__ for dep in dependencies], f, indent=2)
                
            # Update dependency graph
            self.dependency_graph.add_node(mod_id)
            for dep in dependencies:
                if dep.required:
                    self.dependency_graph.add_edge(mod_id, dep.mod_id)
                    
            logging.info(f"Added dependencies for mod: {mod_id}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to add mod dependencies: {e}")
            return False
            
    def get_mod_dependencies(self, mod_id: str) -> List[ModDependency]:
        """Get dependencies for a mod"""
        try:
            dep_file = self.dependencies_path / f"{mod_id}.json"
            if not dep_file.exists():
                return []
                
            with open(dep_file, 'r') as f:
                dep_data = json.load(f)
                return [ModDependency(**dep) for dep in dep_data]
                
        except Exception as e:
            logging.error(f"Failed to get mod dependencies: {e}")
            return []
            
    def check_dependencies(self, mod_id: str, installed_mods: Set[str]) -> Dict[str, List[str]]:
        """Check if all dependencies are satisfied"""
        try:
            dependencies = self.get_mod_dependencies(mod_id)
            missing = []
            conflicts = []
            
            for dep in dependencies:
                if dep.required and dep.mod_id not in installed_mods:
                    missing.append(dep.mod_id)
                if dep.conflicts:
                    for conflict in dep.conflicts:
                        if conflict in installed_mods:
                            conflicts.append(conflict)
                            
            return {
                "missing": missing,
                "conflicts": conflicts
            }
            
        except Exception as e:
            logging.error(f"Failed to check dependencies: {e}")
            return {"missing": [], "conflicts": []}
            
    def get_dependency_tree(self, mod_id: str) -> Dict:
        """Get the complete dependency tree for a mod"""
        try:
            if not nx.has_path(self.dependency_graph, mod_id):
                return {}
                
            # Get all dependencies
            dependencies = set()
            for node in nx.descendants(self.dependency_graph, mod_id):
                dependencies.add(node)
                
            # Build tree
            tree = {}
            for dep in dependencies:
                dep_info = self.get_mod_dependencies(dep)
                tree[dep] = [d.mod_id for d in dep_info if d.required]
                
            return tree
            
        except Exception as e:
            logging.error(f"Failed to get dependency tree: {e}")
            return {}
            
    def validate_mod_installation(self, mod_id: str, installed_mods: Set[str]) -> bool:
        """Validate if a mod can be installed with current mods"""
        try:
            # Check direct dependencies
            deps = self.check_dependencies(mod_id, installed_mods)
            if deps["missing"] or deps["conflicts"]:
                return False
                
            # Check for circular dependencies
            if nx.is_directed_acyclic_graph(self.dependency_graph):
                return True
                
            # Check if adding this mod would create a cycle
            temp_graph = self.dependency_graph.copy()
            temp_graph.add_node(mod_id)
            for dep in self.get_mod_dependencies(mod_id):
                if dep.required:
                    temp_graph.add_edge(mod_id, dep.mod_id)
                    
            return nx.is_directed_acyclic_graph(temp_graph)
            
        except Exception as e:
            logging.error(f"Failed to validate mod installation: {e}")
            return False
            
    def get_installation_order(self, mod_ids: List[str]) -> List[str]:
        """Get the correct installation order for a list of mods"""
        try:
            # Create temporary graph with only the requested mods
            temp_graph = nx.DiGraph()
            for mod_id in mod_ids:
                temp_graph.add_node(mod_id)
                for dep in self.get_mod_dependencies(mod_id):
                    if dep.required and dep.mod_id in mod_ids:
                        temp_graph.add_edge(mod_id, dep.mod_id)
                        
            # Get topological sort
            if nx.is_directed_acyclic_graph(temp_graph):
                return list(nx.topological_sort(temp_graph))
            return []
            
        except Exception as e:
            logging.error(f"Failed to get installation order: {e}")
            return []
            
    def update_dependency_graph(self):
        """Update the dependency graph from all dependency files"""
        try:
            self.dependency_graph.clear()
            
            for dep_file in self.dependencies_path.glob("*.json"):
                mod_id = dep_file.stem
                self.dependency_graph.add_node(mod_id)
                
                with open(dep_file, 'r') as f:
                    dependencies = json.load(f)
                    for dep in dependencies:
                        if dep["required"]:
                            self.dependency_graph.add_edge(mod_id, dep["mod_id"])
                            
            logging.info("Updated dependency graph")
            
        except Exception as e:
            logging.error(f"Failed to update dependency graph: {e}")
            
    def export_dependencies(self, mod_id: str, export_path: Path) -> bool:
        """Export dependencies for a mod"""
        try:
            dependencies = self.get_mod_dependencies(mod_id)
            if not dependencies:
                return False
                
            export_file = export_path / f"{mod_id}_dependencies.json"
            with open(export_file, 'w') as f:
                json.dump([dep.__dict__ for dep in dependencies], f, indent=2)
                
            return True
            
        except Exception as e:
            logging.error(f"Failed to export dependencies: {e}")
            return False
            
    def import_dependencies(self, import_path: Path) -> bool:
        """Import dependencies from a file"""
        try:
            with open(import_path, 'r') as f:
                dependencies = json.load(f)
                
            mod_id = import_path.stem.split('_')[0]
            return self.add_mod_dependencies(mod_id, [ModDependency(**dep) for dep in dependencies])
            
        except Exception as e:
            logging.error(f"Failed to import dependencies: {e}")
            return False 