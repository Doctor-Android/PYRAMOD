#!/usr/bin/env python3
"""
Pyramod Launcher
Created by BLUDSTAR

Simple launcher script to start Pyramod with splash screen.
"""

import sys
import os
import subprocess

def main():
    """Launch Pyramod with GUI"""
    try:
        # Get the directory where this script is located
        script_dir = os.path.dirname(os.path.abspath(__file__))
        
        # Change to the script directory
        os.chdir(script_dir)
        
        # Launch Pyramod with GUI
        subprocess.run([sys.executable, "main.py", "--gui"], check=True)
        
    except subprocess.CalledProcessError as e:
        print(f"Error launching Pyramod: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 