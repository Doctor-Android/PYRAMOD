from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, 
    QTableWidget, QTableWidgetItem, QProgressBar, QMessageBox,
    QTextEdit, QCheckBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from pathlib import Path
from typing import Dict, List, Optional
from mod_update_manager import ModUpdateManager, ModVersion

class UpdateCheckThread(QThread):
    update_found = pyqtSignal(str, ModVersion)
    check_complete = pyqtSignal()
    
    def __init__(self, update_manager: ModUpdateManager, mods: Dict[str, str]):
        super().__init__()
        self.update_manager = update_manager
        self.mods = mods
        
    def run(self):
        updates = self.update_manager.check_all_updates(self.mods)
        for mod_id, update in updates.items():
            self.update_found.emit(mod_id, update)
        self.check_complete.emit()

class ModUpdateDialog(QDialog):
    def __init__(self, update_manager: ModUpdateManager, mods: Dict[str, str], parent=None):
        super().__init__(parent)
        self.update_manager = update_manager
        self.mods = mods
        self.available_updates: Dict[str, ModVersion] = {}
        
        self.setWindowTitle("Mod Update Manager")
        self.setMinimumWidth(800)
        self.setMinimumHeight(600)
        
        # Initialize UI
        self.init_ui()
        
        # Start update check
        self.check_for_updates()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Update check progress
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        layout.addWidget(self.progress_bar)
        
        # Updates table
        self.updates_table = QTableWidget()
        self.updates_table.setColumnCount(5)
        self.updates_table.setHorizontalHeaderLabels([
            "Mod ID", "Current Version", "New Version", "Release Date", "Update"
        ])
        self.updates_table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        layout.addWidget(self.updates_table)
        
        # Changelog
        changelog_layout = QVBoxLayout()
        changelog_layout.addWidget(QLabel("Changelog:"))
        self.changelog_text = QTextEdit()
        self.changelog_text.setReadOnly(True)
        changelog_layout.addWidget(self.changelog_text)
        layout.addLayout(changelog_layout)
        
        # Update options
        options_layout = QHBoxLayout()
        self.backup_checkbox = QCheckBox("Create backup before updating")
        self.backup_checkbox.setChecked(True)
        options_layout.addWidget(self.backup_checkbox)
        layout.addLayout(options_layout)
        
        # Action buttons
        buttons_layout = QHBoxLayout()
        
        self.check_updates_button = QPushButton("Check for Updates")
        self.check_updates_button.clicked.connect(self.check_for_updates)
        buttons_layout.addWidget(self.check_updates_button)
        
        self.update_selected_button = QPushButton("Update Selected")
        self.update_selected_button.clicked.connect(self.update_selected)
        self.update_selected_button.setEnabled(False)
        buttons_layout.addWidget(self.update_selected_button)
        
        self.update_all_button = QPushButton("Update All")
        self.update_all_button.clicked.connect(self.update_all)
        self.update_all_button.setEnabled(False)
        buttons_layout.addWidget(self.update_all_button)
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)
        buttons_layout.addWidget(close_button)
        
        layout.addLayout(buttons_layout)
        
        self.setLayout(layout)
        
    def check_for_updates(self):
        self.progress_bar.setVisible(True)
        self.updates_table.setRowCount(0)
        self.available_updates.clear()
        self.update_selected_button.setEnabled(False)
        self.update_all_button.setEnabled(False)
        
        self.check_thread = UpdateCheckThread(self.update_manager, self.mods)
        self.check_thread.update_found.connect(self.add_update)
        self.check_thread.check_complete.connect(self.check_complete)
        self.check_thread.start()
        
    def add_update(self, mod_id: str, update: ModVersion):
        self.available_updates[mod_id] = update
        
        row = self.updates_table.rowCount()
        self.updates_table.insertRow(row)
        
        self.updates_table.setItem(row, 0, QTableWidgetItem(mod_id))
        self.updates_table.setItem(row, 1, QTableWidgetItem(self.mods[mod_id]))
        self.updates_table.setItem(row, 2, QTableWidgetItem(update.version))
        self.updates_table.setItem(row, 3, QTableWidgetItem(update.release_date.strftime("%Y-%m-%d")))
        
        update_button = QPushButton("Update")
        update_button.clicked.connect(lambda: self.update_single(mod_id))
        self.updates_table.setCellWidget(row, 4, update_button)
        
    def check_complete(self):
        self.progress_bar.setVisible(False)
        if self.available_updates:
            self.update_selected_button.setEnabled(True)
            self.update_all_button.setEnabled(True)
            QMessageBox.information(self, "Updates Available", 
                                  f"Found {len(self.available_updates)} updates available")
        else:
            QMessageBox.information(self, "No Updates", "All mods are up to date")
            
    def update_single(self, mod_id: str):
        update = self.available_updates[mod_id]
        if self.show_update_confirmation(mod_id, update):
            self.apply_update(mod_id, update)
            
    def update_selected(self):
        selected_rows = self.updates_table.selectedItems()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select mods to update")
            return
            
        mod_ids = set()
        for item in selected_rows:
            if item.column() == 0:  # Mod ID column
                mod_ids.add(item.text())
                
        if self.show_update_confirmation(None, None, len(mod_ids)):
            for mod_id in mod_ids:
                if mod_id in self.available_updates:
                    self.apply_update(mod_id, self.available_updates[mod_id])
                    
    def update_all(self):
        if not self.available_updates:
            return
            
        if self.show_update_confirmation(None, None, len(self.available_updates)):
            for mod_id, update in self.available_updates.items():
                self.apply_update(mod_id, update)
                
    def show_update_confirmation(self, mod_id: Optional[str], update: Optional[ModVersion], 
                               count: Optional[int] = None) -> bool:
        message = "Are you sure you want to update "
        if mod_id:
            message += f"{mod_id} to version {update.version}?"
        else:
            message += f"{count} mods?"
            
        if self.backup_checkbox.isChecked():
            message += "\n\nA backup will be created before updating."
            
        reply = QMessageBox.question(
            self, "Confirm Update", message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
        )
        return reply == QMessageBox.StandardButton.Yes
        
    def apply_update(self, mod_id: str, update: ModVersion):
        try:
            # Create backup if requested
            if self.backup_checkbox.isChecked():
                mod_path = Path(self.mods[mod_id])
                if not self.update_manager.backup_mod(mod_id, mod_path):
                    QMessageBox.warning(self, "Backup Failed", 
                                      f"Failed to create backup for {mod_id}")
                    return
                    
            # Download and apply update
            if self.update_manager.download_update(mod_id, update, Path(self.mods[mod_id])):
                QMessageBox.information(self, "Update Successful", 
                                      f"Successfully updated {mod_id} to version {update.version}")
                # Update current version
                self.mods[mod_id] = update.version
                # Remove from available updates
                del self.available_updates[mod_id]
                # Refresh table
                self.check_for_updates()
            else:
                QMessageBox.warning(self, "Update Failed", 
                                  f"Failed to update {mod_id}")
                
        except Exception as e:
            QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")
            
    def show_changelog(self, mod_id: str, update: ModVersion):
        self.changelog_text.setText(f"Changelog for {mod_id} {update.version}:\n\n{update.changelog}") 