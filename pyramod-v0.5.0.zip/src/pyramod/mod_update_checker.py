import os
import json
import requests
from datetime import datetime
from typing import Dict, List, Optional
from error_handler import error_handler

class ModUpdateChecker:
    def __init__(self):
        self.update_sources = {
            "nexus": "https://api.nexusmods.com/v1",
            "curseforge": "https://api.curseforge.com/v1",
            "github": "https://api.github.com"
        }
        self.cache_dir = "cache/updates"
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

    def check_updates(self, game_name: str, mods_dir: str) -> Dict[str, List[Dict]]:
        """Check for updates for all installed mods"""
        try:
            updates = {
                "available": [],
                "failed": [],
                "up_to_date": []
            }

            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    try:
                        update_info = self._check_mod_update(mod_path, game_name)
                        if update_info:
                            if update_info["has_update"]:
                                updates["available"].append(update_info)
                            else:
                                updates["up_to_date"].append(update_info)
                        else:
                            updates["failed"].append({
                                "mod": mod,
                                "error": "Failed to check for updates"
                            })
                    except Exception as e:
                        error_handler.log_warning(f"Error checking updates for {mod}: {str(e)}")
                        updates["failed"].append({
                            "mod": mod,
                            "error": str(e)
                        })

            return updates

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "mods_dir": mods_dir
            })
            raise

    def _check_mod_update(self, mod_path: str, game_name: str) -> Optional[Dict]:
        """Check for updates for a specific mod"""
        try:
            # Read mod manifest
            manifest_path = os.path.join(mod_path, "manifest.json")
            if not os.path.exists(manifest_path):
                return None

            with open(manifest_path, "r") as f:
                manifest = json.load(f)

            # Get current version
            current_version = manifest.get("version", "0.0.0")
            source = manifest.get("source", "nexus")
            mod_id = manifest.get("mod_id")

            if not mod_id:
                return None

            # Check cache first
            cache_file = os.path.join(self.cache_dir, f"{mod_id}.json")
            if os.path.exists(cache_file):
                with open(cache_file, "r") as f:
                    cache_data = json.load(f)
                    if datetime.now().timestamp() - cache_data["timestamp"] < 3600:  # 1 hour cache
                        return cache_data["update_info"]

            # Get latest version from source
            latest_version = self._get_latest_version(source, mod_id, game_name)
            if not latest_version:
                return None

            # Compare versions
            has_update = self._compare_versions(current_version, latest_version["version"])
            update_info = {
                "mod": os.path.basename(mod_path),
                "current_version": current_version,
                "latest_version": latest_version["version"],
                "has_update": has_update,
                "update_url": latest_version.get("url", ""),
                "release_date": latest_version.get("release_date", ""),
                "changelog": latest_version.get("changelog", "")
            }

            # Cache the result
            with open(cache_file, "w") as f:
                json.dump({
                    "timestamp": datetime.now().timestamp(),
                    "update_info": update_info
                }, f)

            return update_info

        except Exception as e:
            error_handler.log_warning(f"Error checking update for {mod_path}: {str(e)}")
            return None

    def _get_latest_version(self, source: str, mod_id: str, game_name: str) -> Optional[Dict]:
        """Get the latest version from the mod source"""
        try:
            if source == "nexus":
                return self._get_nexus_version(mod_id, game_name)
            elif source == "curseforge":
                return self._get_curseforge_version(mod_id)
            elif source == "github":
                return self._get_github_version(mod_id)
            else:
                return None
        except Exception as e:
            error_handler.log_warning(f"Error getting latest version from {source}: {str(e)}")
            return None

    def _get_nexus_version(self, mod_id: str, game_name: str) -> Optional[Dict]:
        """Get latest version from Nexus Mods"""
        # This is a placeholder. In a real implementation, you would need to:
        # 1. Use the Nexus Mods API
        # 2. Handle authentication
        # 3. Parse the response
        return {
            "version": "1.0.0",
            "url": f"https://www.nexusmods.com/{game_name}/mods/{mod_id}",
            "release_date": datetime.now().isoformat(),
            "changelog": "Update available"
        }

    def _get_curseforge_version(self, mod_id: str) -> Optional[Dict]:
        """Get latest version from CurseForge"""
        # This is a placeholder. In a real implementation, you would need to:
        # 1. Use the CurseForge API
        # 2. Handle authentication
        # 3. Parse the response
        return {
            "version": "1.0.0",
            "url": f"https://www.curseforge.com/minecraft/mc-mods/{mod_id}",
            "release_date": datetime.now().isoformat(),
            "changelog": "Update available"
        }

    def _get_github_version(self, mod_id: str) -> Optional[Dict]:
        """Get latest version from GitHub"""
        # This is a placeholder. In a real implementation, you would need to:
        # 1. Use the GitHub API
        # 2. Handle authentication
        # 3. Parse the response
        return {
            "version": "1.0.0",
            "url": f"https://github.com/{mod_id}/releases/latest",
            "release_date": datetime.now().isoformat(),
            "changelog": "Update available"
        }

    def _compare_versions(self, current: str, latest: str) -> bool:
        """Compare version strings"""
        current_parts = [int(x) for x in current.split(".")]
        latest_parts = [int(x) for x in latest.split(".")]
        
        for i in range(max(len(current_parts), len(latest_parts))):
            current_part = current_parts[i] if i < len(current_parts) else 0
            latest_part = latest_parts[i] if i < len(latest_parts) else 0
            
            if latest_part > current_part:
                return True
            elif latest_part < current_part:
                return False
        
        return False

# Create a global mod update checker instance
mod_update_checker = ModUpdateChecker() 