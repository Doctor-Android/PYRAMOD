from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                            QLineEdit, QPushButton, QTextEdit, QComboBox,
                            QTableWidget, QTableWidgetItem, QHeaderView,
                            QMessageBox, QProgressBar)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from pathlib import Path
import json
from typing import Dict, Optional
from datetime import datetime

class ScraperWorker(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, scraper, url: str):
        super().__init__()
        self.scraper = scraper
        self.url = url
        
    def run(self):
        try:
            self.progress.emit(10)
            data = self.scraper.scrape_url(self.url)
            self.progress.emit(50)
            
            if data:
                self.finished.emit(data)
            else:
                self.error.emit("Failed to scrape mod information")
                
            self.progress.emit(100)
        except Exception as e:
            self.error.emit(str(e))
            self.progress.emit(100)

class ModSourceScraperDialog(QDialog):
    def __init__(self, scraper, parent=None):
        super().__init__(parent)
        self.scraper = scraper
        self.setWindowTitle("Mod Source Scraper")
        self.setMinimumWidth(600)
        self.setMinimumHeight(400)
        
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout()
        
        # URL input
        url_layout = QHBoxLayout()
        url_layout.addWidget(QLabel("Mod URL:"))
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Enter mod URL (Nexus Mods, Google Docs, etc.)")
        url_layout.addWidget(self.url_input)
        self.scrape_button = QPushButton("Scrape")
        self.scrape_button.clicked.connect(self.start_scraping)
        url_layout.addWidget(self.scrape_button)
        layout.addLayout(url_layout)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        layout.addWidget(self.progress_bar)
        
        # Results table
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(2)
        self.results_table.setHorizontalHeaderLabels(["Property", "Value"])
        self.results_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.results_table)
        
        # Changelog
        layout.addWidget(QLabel("Changelog:"))
        self.changelog_text = QTextEdit()
        self.changelog_text.setReadOnly(True)
        layout.addWidget(self.changelog_text)
        
        # Buttons
        button_layout = QHBoxLayout()
        self.save_button = QPushButton("Save Data")
        self.save_button.clicked.connect(self.save_data)
        self.save_button.setEnabled(False)
        button_layout.addWidget(self.save_button)
        
        self.close_button = QPushButton("Close")
        self.close_button.clicked.connect(self.close)
        button_layout.addWidget(self.close_button)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
    def start_scraping(self):
        url = self.url_input.text().strip()
        if not url:
            QMessageBox.warning(self, "Error", "Please enter a URL")
            return
            
        if not self.scraper.validate_url(url):
            QMessageBox.warning(self, "Error", "Unsupported URL format")
            return
            
        # Clear previous results
        self.results_table.setRowCount(0)
        self.changelog_text.clear()
        
        # Show progress
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.scrape_button.setEnabled(False)
        self.save_button.setEnabled(False)
        
        # Start worker thread
        self.worker = ScraperWorker(self.scraper, url)
        self.worker.progress.connect(self.update_progress)
        self.worker.finished.connect(self.show_results)
        self.worker.error.connect(self.show_error)
        self.worker.start()
        
    def update_progress(self, value: int):
        self.progress_bar.setValue(value)
        
    def show_results(self, data: Dict):
        # Update table
        self.results_table.setRowCount(len(data))
        for i, (key, value) in enumerate(data.items()):
            if key == "changelog":
                continue
                
            self.results_table.setItem(i, 0, QTableWidgetItem(key))
            self.results_table.setItem(i, 1, QTableWidgetItem(str(value)))
            
        # Update changelog
        if "changelog" in data:
            self.changelog_text.setText(data["changelog"])
            
        # Enable save button
        self.save_button.setEnabled(True)
        self.scrape_button.setEnabled(True)
        
    def show_error(self, message: str):
        QMessageBox.critical(self, "Error", message)
        self.progress_bar.setVisible(False)
        self.scrape_button.setEnabled(True)
        
    def save_data(self):
        # Get current data
        data = {}
        for row in range(self.results_table.rowCount()):
            key = self.results_table.item(row, 0).text()
            value = self.results_table.item(row, 1).text()
            data[key] = value
            
        data["changelog"] = self.changelog_text.toPlainText()
        
        # Save to file
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"mod_data_{timestamp}.json"
            
            with open(filename, 'w') as f:
                json.dump(data, f, indent=2)
                
            QMessageBox.information(self, "Success", f"Data saved to {filename}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save data: {str(e)}") 