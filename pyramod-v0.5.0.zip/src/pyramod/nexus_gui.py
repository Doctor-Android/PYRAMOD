import tkinter as tk
from tkinter import ttk, messagebox
from typing import Optional, Dict, List
import webbrowser
from nexus_api import NexusAPI

class NexusModsPanel:
    """Nexus Mods integration panel for Pyramod."""
    
    def __init__(self, parent: tk.Frame, nexus_api: NexusAPI):
        """Initialize the Nexus Mods panel.
        
        Args:
            parent: Parent frame
            nexus_api: NexusAPI instance
        """
        self.parent = parent
        self.nexus_api = nexus_api
        self.setup_ui()
        
    def setup_ui(self):
        """Set up the Nexus Mods panel UI."""
        # Main frame
        self.frame = tk.Frame(self.parent, bg='#282c34')
        self.frame.pack(fill='both', expand=True, padx=20, pady=20)
        
        # API Key section
        api_frame = tk.Frame(self.frame, bg='#282c34')
        api_frame.pack(fill='x', pady=(0, 20))
        
        tk.Label(
            api_frame,
            text="Nexus Mods API Key:",
            bg='#282c34',
            fg='white'
        ).pack(side='left')
        
        self.api_key_var = tk.StringVar()
        self.api_key_entry = tk.Entry(
            api_frame,
            textvariable=self.api_key_var,
            bg='#23272e',
            fg='white',
            insertbackground='white',
            width=40
        )
        self.api_key_entry.pack(side='left', padx=10)
        
        self.validate_btn = tk.Button(
            api_frame,
            text="Validate",
            command=self.validate_api_key,
            bg='#23272e',
            fg='white',
            bd=0,
            relief='flat',
            activebackground='#2c313a',
            activeforeground='white'
        )
        self.validate_btn.pack(side='left')
        
        # Search section
        search_frame = tk.Frame(self.frame, bg='#282c34')
        search_frame.pack(fill='x', pady=(0, 20))
        
        tk.Label(
            search_frame,
            text="Search Mods:",
            bg='#282c34',
            fg='white'
        ).pack(side='left')
        
        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(
            search_frame,
            textvariable=self.search_var,
            bg='#23272e',
            fg='white',
            insertbackground='white',
            width=40
        )
        self.search_entry.pack(side='left', padx=10)
        
        self.search_btn = tk.Button(
            search_frame,
            text="Search",
            command=self.search_mods,
            bg='#23272e',
            fg='white',
            bd=0,
            relief='flat',
            activebackground='#2c313a',
            activeforeground='white'
        )
        self.search_btn.pack(side='left')
        
        # Results section
        results_frame = tk.Frame(self.frame, bg='#282c34')
        results_frame.pack(fill='both', expand=True)
        
        # Results table
        columns = ('Name', 'Author', 'Downloads', 'Endorsements', 'Last Updated')
        self.results_table = ttk.Treeview(
            results_frame,
            columns=columns,
            show='headings',
            style='Custom.Treeview'
        )
        
        # Configure columns
        self.results_table.heading('Name', text='Name')
        self.results_table.heading('Author', text='Author')
        self.results_table.heading('Downloads', text='Downloads')
        self.results_table.heading('Endorsements', text='Endorsements')
        self.results_table.heading('Last Updated', text='Last Updated')
        
        self.results_table.column('Name', width=200)
        self.results_table.column('Author', width=150)
        self.results_table.column('Downloads', width=100)
        self.results_table.column('Endorsements', width=100)
        self.results_table.column('Last Updated', width=150)
        
        self.results_table.pack(fill='both', expand=True)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(
            results_frame,
            orient='vertical',
            command=self.results_table.yview
        )
        scrollbar.pack(side='right', fill='y')
        self.results_table.configure(yscrollcommand=scrollbar.set)
        
        # Context menu
        self.context_menu = tk.Menu(self.results_table, tearoff=0)
        self.context_menu.add_command(label="View on Nexus", command=self.view_on_nexus)
        self.context_menu.add_command(label="Download", command=self.download_mod)
        self.context_menu.add_command(label="Track Mod", command=self.track_mod)
        self.context_menu.add_command(label="Endorse", command=self.endorse_mod)
        
        self.results_table.bind("<Button-3>", self.show_context_menu)
        self.results_table.bind("<Double-1>", lambda e: self.view_on_nexus())
        
        # Load saved API key
        self.api_key_var.set(self.nexus_api.api_key)
        
    def validate_api_key(self):
        """Validate the entered API key."""
        api_key = self.api_key_var.get().strip()
        if not api_key:
            messagebox.showerror("Error", "Please enter an API key")
            return
            
        try:
            if self.nexus_api.validate_api_key():
                self.nexus_api.save_api_key(api_key)
                messagebox.showinfo("Success", "API key validated successfully")
            else:
                messagebox.showerror("Error", "Invalid API key")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to validate API key: {e}")
            
    def search_mods(self):
        """Search for mods on Nexus."""
        if not self.nexus_api.validate_api_key():
            messagebox.showerror("Error", "Please enter a valid API key")
            return
            
        search_term = self.search_var.get().strip()
        if not search_term:
            messagebox.showerror("Error", "Please enter a search term")
            return
            
        try:
            # Clear existing results
            for item in self.results_table.get_children():
                self.results_table.delete(item)
                
            # Search mods
            results = self.nexus_api.search_mods('skyrim', search_term)
            
            # Display results
            for mod in results:
                self.results_table.insert('', 'end', values=(
                    mod['name'],
                    mod['author'],
                    mod['downloads'],
                    mod['endorsements'],
                    mod['last_updated']
                ))
                
        except Exception as e:
            messagebox.showerror("Error", f"Failed to search mods: {e}")
            
    def view_on_nexus(self):
        """Open the selected mod on Nexus Mods website."""
        selection = self.results_table.selection()
        if not selection:
            return
            
        item = selection[0]
        mod_name = self.results_table.item(item, 'values')[0]
        
        # Search for the mod to get its ID
        try:
            results = self.nexus_api.search_mods('skyrim', mod_name)
            if results:
                mod_id = results[0]['id']
                url = f"https://www.nexusmods.com/skyrim/mods/{mod_id}"
                webbrowser.open(url)
        except Exception as e:
            messagebox.showerror("Error", f"Failed to open mod page: {e}")
            
    def download_mod(self):
        """Download the selected mod."""
        selection = self.results_table.selection()
        if not selection:
            return
            
        item = selection[0]
        mod_name = self.results_table.item(item, 'values')[0]
        
        try:
            # Search for the mod to get its ID
            results = self.nexus_api.search_mods('skyrim', mod_name)
            if results:
                mod_id = results[0]['id']
                
                # Get latest file
                files = self.nexus_api.get_mod_files('skyrim', mod_id)
                if files:
                    latest_file = files[0]
                    download_url = self.nexus_api.get_download_url(
                        'skyrim',
                        mod_id,
                        latest_file['id']
                    )
                    
                    # Open download in browser
                    webbrowser.open(download_url)
                    
        except Exception as e:
            messagebox.showerror("Error", f"Failed to download mod: {e}")
            
    def track_mod(self):
        """Track the selected mod."""
        selection = self.results_table.selection()
        if not selection:
            return
            
        item = selection[0]
        mod_name = self.results_table.item(item, 'values')[0]
        
        try:
            # Search for the mod to get its ID
            results = self.nexus_api.search_mods('skyrim', mod_name)
            if results:
                mod_id = results[0]['id']
                
                if self.nexus_api.track_mod('skyrim', mod_id):
                    messagebox.showinfo("Success", f"Now tracking {mod_name}")
                else:
                    messagebox.showerror("Error", "Failed to track mod")
                    
        except Exception as e:
            messagebox.showerror("Error", f"Failed to track mod: {e}")
            
    def endorse_mod(self):
        """Endorse the selected mod."""
        selection = self.results_table.selection()
        if not selection:
            return
            
        item = selection[0]
        mod_name = self.results_table.item(item, 'values')[0]
        
        try:
            # Search for the mod to get its ID
            results = self.nexus_api.search_mods('skyrim', mod_name)
            if results:
                mod_id = results[0]['id']
                
                if self.nexus_api.endorse_mod('skyrim', mod_id):
                    messagebox.showinfo("Success", f"Endorsed {mod_name}")
                else:
                    messagebox.showerror("Error", "Failed to endorse mod")
                    
        except Exception as e:
            messagebox.showerror("Error", f"Failed to endorse mod: {e}")
            
    def show_context_menu(self, event):
        """Show the context menu for the selected mod."""
        item = self.results_table.identify_row(event.y)
        if item:
            self.results_table.selection_set(item)
            self.results_table.focus(item)
            self.context_menu.tk_popup(event.x_root, event.y_root) 