#!/usr/bin/env python3
import argparse
import logging
import sys
import json
from pathlib import Path
from system_optimizer import SystemOptimizer

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    parser = argparse.ArgumentParser(description='System Optimization CLI')
    parser.add_argument('--config-dir', default='config',
                      help='Directory for configuration files')
    parser.add_argument('--action', required=True,
                      choices=['create-profile', 'optimize', 'recommendations', 'list-profiles'],
                      help='Action to perform')
    parser.add_argument('--game', required=True,
                      help='Game name for the action')
    parser.add_argument('--profile-file',
                      help='Path to profile JSON file (for create-profile action)')

    args = parser.parse_args()

    # Setup logging
    setup_logging()
    logger = logging.getLogger("OptimizerCLI")

    # Initialize system optimizer
    try:
        optimizer = SystemOptimizer(args.config_dir)
    except Exception as e:
        logger.error(f"Failed to initialize system optimizer: {e}")
        sys.exit(1)

    # Perform requested action
    if args.action == 'create-profile':
        if not args.profile_file:
            logger.error("Profile file is required for create-profile action")
            sys.exit(1)

        try:
            with open(args.profile_file, 'r') as f:
                profile = json.load(f)
            optimizer.create_optimization_profile(args.game, profile)
            logger.info(f"Created optimization profile for {args.game}")
        except Exception as e:
            logger.error(f"Failed to create profile: {e}")
            sys.exit(1)

    elif args.action == 'optimize':
        optimizations = optimizer.optimize_system_for_game(args.game)
        if optimizations:
            logger.info(f"Applied optimizations for {args.game}:")
            for opt in optimizations:
                logger.info(f"  - {opt}")
        else:
            logger.warning(f"No optimizations were applied for {args.game}")

    elif args.action == 'recommendations':
        recommendations = optimizer.get_optimization_recommendations(args.game)
        if recommendations:
            logger.info(f"Optimization recommendations for {args.game}:")
            for rec in recommendations:
                logger.info(f"  - {rec}")
        else:
            logger.info(f"No recommendations available for {args.game}")

    elif args.action == 'list-profiles':
        profile = optimizer.get_optimization_profile(args.game)
        if profile:
            logger.info(f"Optimization profile for {args.game}:")
            logger.info(json.dumps(profile, indent=2))
        else:
            logger.info(f"No profile found for {args.game}")

if __name__ == '__main__':
    main() 