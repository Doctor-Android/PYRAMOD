import os
import shutil
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import hashlib
from datetime import datetime

class ModDeployment:
    def __init__(self, game_path: str, mods_path: str):
        self.game_path = Path(game_path)
        self.mods_path = Path(mods_path)
        self.deployment_log = self.mods_path / "deployment_log.json"
        self.deployment_history = self._load_deployment_history()
        self.logger = logging.getLogger("ModDeployment")

    def _load_deployment_history(self) -> Dict:
        """Load deployment history from log file."""
        if self.deployment_log.exists():
            try:
                with open(self.deployment_log, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                self.logger.error("Failed to load deployment history")
                return {}
        return {}

    def _save_deployment_history(self):
        """Save deployment history to log file."""
        try:
            with open(self.deployment_log, 'w') as f:
                json.dump(self.deployment_history, f, indent=2)
        except Exception as e:
            self.logger.error(f"Failed to save deployment history: {e}")

    def deploy_mod(self, mod_path: str, deployment_rules: Optional[Dict] = None) -> bool:
        """
        Deploy a mod to the game directory.
        
        Args:
            mod_path: Path to the mod to deploy
            deployment_rules: Optional rules for deployment (e.g., file exclusions)
            
        Returns:
            bool: True if deployment was successful
        """
        try:
            mod_path = Path(mod_path)
            if not mod_path.exists():
                self.logger.error(f"Mod path does not exist: {mod_path}")
                return False

            # Create deployment record
            deployment_id = hashlib.md5(str(datetime.now()).encode()).hexdigest()
            deployment_record = {
                "timestamp": str(datetime.now()),
                "mod_path": str(mod_path),
                "files": [],
                "status": "pending"
            }

            # Deploy files
            for root, _, files in os.walk(mod_path):
                for file in files:
                    src_path = Path(root) / file
                    rel_path = src_path.relative_to(mod_path)
                    dst_path = self.game_path / rel_path

                    # Check deployment rules
                    if deployment_rules and self._should_exclude_file(rel_path, deployment_rules):
                        continue

                    # Create destination directory if needed
                    dst_path.parent.mkdir(parents=True, exist_ok=True)

                    # Copy file
                    shutil.copy2(src_path, dst_path)
                    deployment_record["files"].append(str(rel_path))

            # Update deployment history
            deployment_record["status"] = "success"
            self.deployment_history[deployment_id] = deployment_record
            self._save_deployment_history()

            return True

        except Exception as e:
            self.logger.error(f"Failed to deploy mod: {e}")
            if deployment_id in self.deployment_history:
                self.deployment_history[deployment_id]["status"] = "failed"
                self.deployment_history[deployment_id]["error"] = str(e)
                self._save_deployment_history()
            return False

    def undeploy_mod(self, mod_path: str) -> bool:
        """
        Remove a deployed mod from the game directory.
        
        Args:
            mod_path: Path to the mod to undeploy
            
        Returns:
            bool: True if undeployment was successful
        """
        try:
            mod_path = Path(mod_path)
            if not mod_path.exists():
                self.logger.error(f"Mod path does not exist: {mod_path}")
                return False

            # Find deployment record
            deployment_id = None
            for d_id, record in self.deployment_history.items():
                if record["mod_path"] == str(mod_path):
                    deployment_id = d_id
                    break

            if not deployment_id:
                self.logger.error(f"No deployment record found for mod: {mod_path}")
                return False

            # Remove deployed files
            for file_path in self.deployment_history[deployment_id]["files"]:
                try:
                    (self.game_path / file_path).unlink()
                except FileNotFoundError:
                    self.logger.warning(f"File not found during undeployment: {file_path}")

            # Update deployment history
            self.deployment_history[deployment_id]["status"] = "undeployed"
            self._save_deployment_history()

            return True

        except Exception as e:
            self.logger.error(f"Failed to undeploy mod: {e}")
            return False

    def verify_deployment(self, mod_path: str) -> Tuple[bool, List[str]]:
        """
        Verify that a mod is correctly deployed.
        
        Args:
            mod_path: Path to the mod to verify
            
        Returns:
            Tuple[bool, List[str]]: (is_valid, list_of_issues)
        """
        try:
            mod_path = Path(mod_path)
            if not mod_path.exists():
                return False, ["Mod path does not exist"]

            issues = []
            for root, _, files in os.walk(mod_path):
                for file in files:
                    src_path = Path(root) / file
                    rel_path = src_path.relative_to(mod_path)
                    dst_path = self.game_path / rel_path

                    if not dst_path.exists():
                        issues.append(f"Missing file: {rel_path}")
                        continue

                    # Compare file hashes
                    src_hash = self._get_file_hash(src_path)
                    dst_hash = self._get_file_hash(dst_path)
                    if src_hash != dst_hash:
                        issues.append(f"File mismatch: {rel_path}")

            return len(issues) == 0, issues

        except Exception as e:
            self.logger.error(f"Failed to verify deployment: {e}")
            return False, [str(e)]

    def _get_file_hash(self, file_path: Path) -> str:
        """Calculate MD5 hash of a file."""
        hash_md5 = hashlib.md5()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_md5.update(chunk)
        return hash_md5.hexdigest()

    def _should_exclude_file(self, file_path: Path, rules: Dict) -> bool:
        """Check if a file should be excluded based on deployment rules."""
        if "exclude_patterns" in rules:
            for pattern in rules["exclude_patterns"]:
                if file_path.match(pattern):
                    return True
        return False

    def get_deployment_status(self, mod_path: str) -> Dict:
        """
        Get the deployment status of a mod.
        
        Args:
            mod_path: Path to the mod
            
        Returns:
            Dict: Deployment status information
        """
        mod_path = str(Path(mod_path))
        for record in self.deployment_history.values():
            if record["mod_path"] == mod_path:
                return record
        return {"status": "not_deployed"} 