"""
Mod installer for Pyramod.
"""

import os
import json
import logging
import shutil
import zipfile
import requests
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger("pyramod.installer")

class ModInstaller:
    """Installs and manages mods."""
    
    def __init__(self, config_dir: str):
        """Initialize the mod installer.
        
        Args:
            config_dir: Configuration directory
        """
        self.config_dir = Path(config_dir)
        self.mod_dir = self.config_dir / "mods"
        self.mod_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.mod_dir / "installed.json"
        if not self.config_file.exists():
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default mod installation configuration."""
        default_config = {
            "skyrim": {
                "game_path": "",
                "mods": {},
            },
            "fallout4": {
                "game_path": "",
                "mods": {},
            }
        }
        
        with open(self.config_file, "w") as f:
            json.dump(default_config, f, indent=4)
    
    def get_config(self) -> Dict[str, Dict[str, Union[str, Dict[str, Dict]]]]:
        """Get the current mod installation configuration.
        
        Returns:
            Current mod installation configuration
        """
        with open(self.config_file, "r") as f:
            return json.load(f)
    
    def update_config(self, config: Dict[str, Dict[str, Union[str, Dict[str, Dict]]]]):
        """Update the mod installation configuration.
        
        Args:
            config: New mod installation configuration
        """
        current_config = self.get_config()
        current_config.update(config)
        
        with open(self.config_file, "w") as f:
            json.dump(current_config, f, indent=4)
    
    def set_game_path(self, game: str, path: str) -> bool:
        """Set the game installation path.
        
        Args:
            game: Game to set path for
            path: Game installation path
        
        Returns:
            True if successful, False otherwise
        """
        if not os.path.exists(path):
            logger.error(f"Game path does not exist: {path}")
            return False
        
        config = self.get_config()
        
        if game not in config:
            config[game] = {
                "game_path": "",
                "mods": {},
            }
        
        config[game]["game_path"] = path
        self.update_config(config)
        return True
    
    def get_game_path(self, game: str) -> Optional[str]:
        """Get the game installation path.
        
        Args:
            game: Game to get path for
        
        Returns:
            Game installation path, or None if not set
        """
        config = self.get_config()
        
        if game not in config:
            return None
        
        return config[game]["game_path"]
    
    def install_mod(self, game: str, mod_id: str, mod_path: str) -> bool:
        """Install a mod.
        
        Args:
            game: Game to install mod for
            mod_id: Mod ID
            mod_path: Path to mod file
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            config[game] = {
                "game_path": "",
                "mods": {},
            }
        
        if not config[game]["game_path"]:
            logger.error("Game path not set")
            return False
        
        if not os.path.exists(mod_path):
            logger.error(f"Mod file does not exist: {mod_path}")
            return False
        
        # Create mod directory
        mod_dir = self.mod_dir / game / mod_id
        mod_dir.mkdir(parents=True, exist_ok=True)
        
        # Extract mod
        try:
            if mod_path.endswith(".zip"):
                with zipfile.ZipFile(mod_path, "r") as zip_ref:
                    zip_ref.extractall(mod_dir)
            else:
                shutil.copy2(mod_path, mod_dir)
        except Exception as e:
            logger.error(f"Failed to extract mod: {e}")
            return False
        
        # Add to config
        config[game]["mods"][mod_id] = {
            "path": str(mod_dir),
            "installed": True,
        }
        
        self.update_config(config)
        return True
    
    def uninstall_mod(self, game: str, mod_id: str) -> bool:
        """Uninstall a mod.
        
        Args:
            game: Game to uninstall mod from
            mod_id: Mod ID
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if mod_id not in config[game]["mods"]:
            return False
        
        # Remove mod directory
        mod_dir = Path(config[game]["mods"][mod_id]["path"])
        if mod_dir.exists():
            try:
                shutil.rmtree(mod_dir)
            except Exception as e:
                logger.error(f"Failed to remove mod directory: {e}")
                return False
        
        # Remove from config
        del config[game]["mods"][mod_id]
        
        self.update_config(config)
        return True
    
    def get_installed_mods(self, game: str) -> Dict[str, Dict[str, Union[str, bool]]]:
        """Get installed mods for a game.
        
        Args:
            game: Game to get mods for
        
        Returns:
            Dictionary of installed mods
        """
        config = self.get_config()
        
        if game not in config:
            return {}
        
        return config[game]["mods"]
    
    def download_mod(self, game: str, mod_id: str, url: str) -> Optional[str]:
        """Download a mod.
        
        Args:
            game: Game to download mod for
            mod_id: Mod ID
            url: URL to download mod from
        
        Returns:
            Path to downloaded mod file, or None if failed
        """
        # Create downloads directory
        downloads_dir = self.mod_dir / "downloads"
        downloads_dir.mkdir(parents=True, exist_ok=True)
        
        # Download mod
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()
            
            mod_path = downloads_dir / f"{mod_id}.zip"
            with open(mod_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            return str(mod_path)
        except Exception as e:
            logger.error(f"Failed to download mod: {e}")
            return None
    
    def update_mod(self, game: str, mod_id: str, mod_path: str) -> bool:
        """Update a mod.
        
        Args:
            game: Game to update mod for
            mod_id: Mod ID
            mod_path: Path to new mod file
        
        Returns:
            True if successful, False otherwise
        """
        # Uninstall old version
        if not self.uninstall_mod(game, mod_id):
            return False
        
        # Install new version
        return self.install_mod(game, mod_id, mod_path) 