from PyQt6.QtCore import QObject, QTimer, pyqtSignal
from datetime import datetime, time
import json
from pathlib import Path
from typing import Dict, Optional
import logging

class ModUpdateScheduler(QObject):
    update_check_triggered = pyqtSignal()
    
    def __init__(self, base_path: Path):
        super().__init__()
        self.base_path = base_path
        self.schedule_path = base_path / "update_schedule.json"
        self.timer = QTimer()
        self.timer.timeout.connect(self.check_schedule)
        
        # Load schedule
        self.schedule = self.load_schedule()
        
        # Start timer
        self.timer.start(60000)  # Check every minute
        
    def load_schedule(self) -> Dict:
        """Load schedule from file"""
        try:
            if self.schedule_path.exists():
                with open(self.schedule_path, 'r') as f:
                    return json.load(f)
            return {
                "enabled": False,
                "check_time": "12:00",
                "check_days": [0, 1, 2, 3, 4, 5, 6],  # All days
                "last_check": None
            }
        except Exception as e:
            logging.error(f"Failed to load schedule: {e}")
            return {
                "enabled": False,
                "check_time": "12:00",
                "check_days": [0, 1, 2, 3, 4, 5, 6],
                "last_check": None
            }
            
    def save_schedule(self):
        """Save schedule to file"""
        try:
            with open(self.schedule_path, 'w') as f:
                json.dump(self.schedule, f, indent=2)
        except Exception as e:
            logging.error(f"Failed to save schedule: {e}")
            
    def set_schedule(self, enabled: bool, check_time: str, check_days: list):
        """Set new schedule"""
        try:
            time.strptime(check_time, "%H:%M")  # Validate time format
            self.schedule.update({
                "enabled": enabled,
                "check_time": check_time,
                "check_days": check_days
            })
            self.save_schedule()
            return True
        except ValueError:
            logging.error("Invalid time format")
            return False
        except Exception as e:
            logging.error(f"Failed to set schedule: {e}")
            return False
            
    def check_schedule(self):
        """Check if it's time to run update check"""
        if not self.schedule["enabled"]:
            return
            
        now = datetime.now()
        current_time = now.strftime("%H:%M")
        current_day = now.weekday()
        
        # Check if it's the right day
        if current_day not in self.schedule["check_days"]:
            return
            
        # Check if it's the right time
        if current_time != self.schedule["check_time"]:
            return
            
        # Check if we've already run today
        last_check = self.schedule.get("last_check")
        if last_check and datetime.fromisoformat(last_check).date() == now.date():
            return
            
        # Trigger update check
        self.schedule["last_check"] = now.isoformat()
        self.save_schedule()
        self.update_check_triggered.emit()
        
    def get_schedule(self) -> Dict:
        """Get current schedule"""
        return self.schedule.copy()
        
    def is_enabled(self) -> bool:
        """Check if scheduler is enabled"""
        return self.schedule["enabled"]
        
    def get_next_check(self) -> Optional[datetime]:
        """Get datetime of next scheduled check"""
        if not self.schedule["enabled"]:
            return None
            
        now = datetime.now()
        check_time = time.fromisoformat(self.schedule["check_time"])
        
        # Find next check day
        days_ahead = 0
        while True:
            next_day = (now.weekday() + days_ahead) % 7
            if next_day in self.schedule["check_days"]:
                break
            days_ahead += 1
            
        # Calculate next check datetime
        next_check = datetime.combine(now.date(), check_time)
        next_check = next_check.replace(day=now.day + days_ahead)
        
        # If next check is today but time has passed, move to next day
        if next_check < now:
            next_check = next_check.replace(day=next_check.day + 1)
            
        return next_check 