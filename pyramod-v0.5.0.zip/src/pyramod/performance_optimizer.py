import os
import sys
import psutil
import logging
from typing import Dict, List, Optional
import json
import threading
from concurrent.futures import ThreadPoolExecutor

class PerformanceOptimizer:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.config = self.load_config()
        self.executor = ThreadPoolExecutor(max_workers=self.config.get("max_threads", 4))
        self.optimization_cache = {}
        
    def load_config(self) -> Dict:
        """Load optimization configuration"""
        try:
            with open("optimization_config.json", "r") as f:
                return json.load(f)
        except:
            return {
                "max_threads": 4,
                "memory_limit": 0.8,  # 80% of available memory
                "cpu_limit": 0.7,     # 70% of available CPU
                "io_priority": "normal",
                "cache_size": 1000,
                "optimization_level": "balanced"
            }
            
    def optimize_system(self):
        """Optimize system performance"""
        try:
            # Set process priority
            self.set_process_priority()
            
            # Optimize memory usage
            self.optimize_memory()
            
            # Optimize CPU usage
            self.optimize_cpu()
            
            # Optimize disk I/O
            self.optimize_io()
            
            # Clear unnecessary caches
            self.clear_caches()
            
            self.logger.info("System optimization completed")
            return True
        except Exception as e:
            self.logger.error(f"Optimization failed: {str(e)}")
            return False
            
    def set_process_priority(self):
        """Set process priority"""
        try:
            process = psutil.Process(os.getpid())
            if sys.platform == "linux":
                process.nice(10)  # Lower priority for better system responsiveness
            self.logger.info("Process priority set")
        except Exception as e:
            self.logger.error(f"Failed to set process priority: {str(e)}")
            
    def optimize_memory(self):
        """Optimize memory usage"""
        try:
            # Get system memory info
            memory = psutil.virtual_memory()
            
            # Calculate memory limit
            memory_limit = int(memory.total * self.config["memory_limit"])
            
            # Set memory limit for the process
            if sys.platform == "linux":
                import resource
                resource.setrlimit(resource.RLIMIT_AS, (memory_limit, memory_limit))
                
            self.logger.info(f"Memory optimized: {memory_limit / 1024 / 1024:.2f} MB limit")
        except Exception as e:
            self.logger.error(f"Memory optimization failed: {str(e)}")
            
    def optimize_cpu(self):
        """Optimize CPU usage"""
        try:
            # Get CPU info
            cpu_count = psutil.cpu_count()
            
            # Calculate CPU limit
            cpu_limit = int(cpu_count * self.config["cpu_limit"])
            
            # Set CPU affinity
            process = psutil.Process(os.getpid())
            process.cpu_affinity(list(range(cpu_limit)))
            
            self.logger.info(f"CPU optimized: {cpu_limit} cores")
        except Exception as e:
            self.logger.error(f"CPU optimization failed: {str(e)}")
            
    def optimize_io(self):
        """Optimize disk I/O"""
        try:
            if sys.platform == "linux":
                # Set I/O priority
                os.system(f"ionice -c2 -n0 -p {os.getpid()}")
                
            self.logger.info("I/O optimized")
        except Exception as e:
            self.logger.error(f"I/O optimization failed: {str(e)}")
            
    def clear_caches(self):
        """Clear unnecessary caches"""
        try:
            # Clear Python's memory cache
            import gc
            gc.collect()
            
            # Clear optimization cache if too large
            if len(self.optimization_cache) > self.config["cache_size"]:
                self.optimization_cache.clear()
                
            self.logger.info("Caches cleared")
        except Exception as e:
            self.logger.error(f"Cache clearing failed: {str(e)}")
            
    def monitor_performance(self):
        """Monitor system performance"""
        try:
            # Get system metrics
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk_io = psutil.disk_io_counters()
            
            # Check for performance issues
            if cpu_percent > 90:
                self.logger.warning("High CPU usage detected")
                self.optimize_cpu()
                
            if memory.percent > 90:
                self.logger.warning("High memory usage detected")
                self.optimize_memory()
                
            if disk_io.read_bytes > 1e9 or disk_io.write_bytes > 1e9:  # 1GB
                self.logger.warning("High disk I/O detected")
                self.optimize_io()
                
            return {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "disk_io": {
                    "read_bytes": disk_io.read_bytes,
                    "write_bytes": disk_io.write_bytes
                }
            }
        except Exception as e:
            self.logger.error(f"Performance monitoring failed: {str(e)}")
            return None
            
    def apply_optimization_profile(self, profile: str):
        """Apply a specific optimization profile"""
        profiles = {
            "performance": {
                "max_threads": 8,
                "memory_limit": 0.9,
                "cpu_limit": 0.9,
                "io_priority": "high",
                "optimization_level": "aggressive"
            },
            "balanced": {
                "max_threads": 4,
                "memory_limit": 0.8,
                "cpu_limit": 0.7,
                "io_priority": "normal",
                "optimization_level": "balanced"
            },
            "power_save": {
                "max_threads": 2,
                "memory_limit": 0.6,
                "cpu_limit": 0.5,
                "io_priority": "low",
                "optimization_level": "conservative"
            }
        }
        
        if profile in profiles:
            self.config.update(profiles[profile])
            self.optimize_system()
            self.logger.info(f"Applied {profile} optimization profile")
            return True
        else:
            self.logger.error(f"Unknown optimization profile: {profile}")
            return False
            
    def cleanup(self):
        """Cleanup resources"""
        try:
            self.executor.shutdown(wait=True)
            self.clear_caches()
            self.logger.info("Cleanup completed")
        except Exception as e:
            self.logger.error(f"Cleanup failed: {str(e)}")
            
    def __del__(self):
        """Destructor"""
        self.cleanup() 