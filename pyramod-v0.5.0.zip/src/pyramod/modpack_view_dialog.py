from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QPushButton, QListWidget, QMessageBox)
from PyQt6.QtCore import Qt

class ModpackViewDialog(QDialog):
    def __init__(self, modpack_name: str, mod_manager, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"View Modpack - {modpack_name}")
        self.setGeometry(200, 200, 600, 500)
        
        self.modpack_name = modpack_name
        self.mod_manager = mod_manager
        self.modpack_manager = modpack_manager
        
        # Load modpack info
        try:
            self.modpack_info = modpack_manager.get_modpack_info(modpack_name)
        except ValueError as e:
            QMessageBox.warning(self, "Error", str(e))
            self.reject()
            return
            
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Name and description
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Name:"))
        name_layout.addWidget(QLabel(self.modpack_info["name"]))
        layout.addLayout(name_layout)
        
        desc_layout = QVBoxLayout()
        desc_layout.addWidget(QLabel("Description:"))
        desc_label = QLabel(self.modpack_info["description"])
        desc_label.setWordWrap(True)
        desc_layout.addWidget(desc_label)
        layout.addLayout(desc_layout)
        
        # Mods in pack
        layout.addWidget(QLabel("Mods in Pack:"))
        self.mods_list = QListWidget()
        for mod in self.modpack_info["mods"]:
            self.mods_list.addItem(mod)
        layout.addWidget(self.mods_list)
        
        # Buttons
        button_layout = QHBoxLayout()
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        button_layout.addWidget(close_btn)
        layout.addLayout(button_layout)
        
        self.setLayout(layout) 