#!/usr/bin/env python3
import os
import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

class WindowsCompat:
    """Windows mod compatibility layer for Linux."""
    
    def __init__(self, config_dir: str):
        """Initialize the Windows compatibility layer.
        
        Args:
            config_dir: Directory to store configuration and compatibility data
        """
        self.config_dir = Path(config_dir)
        self.compat_dir = self.config_dir / "compat"
        self.registry_dir = self.compat_dir / "registry"
        self.dll_dir = self.compat_dir / "dlls"
        self.script_ext_dir = self.compat_dir / "script_extenders"
        
        # Create necessary directories
        self.compat_dir.mkdir(parents=True, exist_ok=True)
        self.registry_dir.mkdir(parents=True, exist_ok=True)
        self.dll_dir.mkdir(parents=True, exist_ok=True)
        self.script_ext_dir.mkdir(parents=True, exist_ok=True)
        
        # Set up logging
        self.logger = logging.getLogger("windows_compat")
        
        # Load configuration
        self.config = self._load_config()
        self.registry = self._load_registry()
        self.dll_cache = self._load_dll_cache()
        self.script_ext_cache = self._load_script_ext_cache()
        
    def _load_config(self) -> Dict:
        """Load compatibility configuration."""
        config_file = self.config_dir / "compat_config.json"
        if config_file.exists():
            with open(config_file) as f:
                return json.load(f)
        return {
            "path_translations": {},
            "registry_mappings": {},
            "dll_redirects": {},
            "script_extender_configs": {}
        }
    
    def _save_config(self):
        """Save compatibility configuration."""
        config_file = self.config_dir / "compat_config.json"
        with open(config_file, "w") as f:
            json.dump(self.config, f, indent=4)
    
    def _load_registry(self) -> Dict:
        """Load registry emulation data."""
        registry_file = self.registry_dir / "registry.json"
        if registry_file.exists():
            with open(registry_file) as f:
                return json.load(f)
        return {}
    
    def _save_registry(self):
        """Save registry emulation data."""
        registry_file = self.registry_dir / "registry.json"
        with open(registry_file, "w") as f:
            json.dump(self.registry, f, indent=4)
    
    def _load_dll_cache(self) -> Dict:
        """Load DLL cache information."""
        cache_file = self.dll_dir / "dll_cache.json"
        if cache_file.exists():
            with open(cache_file) as f:
                return json.load(f)
        return {}
    
    def _save_dll_cache(self):
        """Save DLL cache information."""
        cache_file = self.dll_dir / "dll_cache.json"
        with open(cache_file, "w") as f:
            json.dump(self.dll_cache, f, indent=4)
    
    def _load_script_ext_cache(self) -> Dict:
        """Load script extender cache information."""
        cache_file = self.script_ext_dir / "script_ext_cache.json"
        if cache_file.exists():
            with open(cache_file) as f:
                return json.load(f)
        return {}
    
    def _save_script_ext_cache(self):
        """Save script extender cache information."""
        cache_file = self.script_ext_dir / "script_ext_cache.json"
        with open(cache_file, "w") as f:
            json.dump(self.script_ext_cache, f, indent=4)
    
    def translate_path(self, windows_path: str) -> str:
        """Translate a Windows path to a Linux path.
        
        Args:
            windows_path: Windows-style path to translate
            
        Returns:
            Translated Linux path
        """
        # Check for direct mapping
        if windows_path in self.config["path_translations"]:
            return self.config["path_translations"][windows_path]
        
        # Convert Windows path to Linux path
        linux_path = windows_path.replace("\\", "/")
        if ":" in linux_path:
            drive, path = linux_path.split(":", 1)
            linux_path = f"/mnt/{drive.lower()}{path}"
        
        return linux_path
    
    def add_path_translation(self, windows_path: str, linux_path: str):
        """Add a path translation mapping.
        
        Args:
            windows_path: Windows path to map
            linux_path: Corresponding Linux path
        """
        self.config["path_translations"][windows_path] = linux_path
        self._save_config()
    
    def set_registry_value(self, key: str, value: str, data: str):
        """Set a registry value.
        
        Args:
            key: Registry key
            value: Registry value name
            data: Registry value data
        """
        if key not in self.registry:
            self.registry[key] = {}
        self.registry[key][value] = data
        self._save_registry()
    
    def get_registry_value(self, key: str, value: str) -> Optional[str]:
        """Get a registry value.
        
        Args:
            key: Registry key
            value: Registry value name
            
        Returns:
            Registry value data if found, None otherwise
        """
        return self.registry.get(key, {}).get(value)
    
    def handle_dll(self, dll_path: str, target_dir: str) -> bool:
        """Handle a Windows DLL file.
        
        Args:
            dll_path: Path to the DLL file
            target_dir: Directory to install the DLL
            
        Returns:
            True if successful, False otherwise
        """
        try:
            dll_name = os.path.basename(dll_path)
            cache_path = self.dll_dir / dll_name
            
            # Check if DLL is already cached
            if not cache_path.exists():
                # Copy DLL to cache
                shutil.copy2(dll_path, cache_path)
                self.dll_cache[dll_name] = {
                    "original_path": dll_path,
                    "cached_path": str(cache_path)
                }
                self._save_dll_cache()
            
            # Create symbolic link in target directory
            target_path = os.path.join(target_dir, dll_name)
            if os.path.exists(target_path):
                os.remove(target_path)
            os.symlink(cache_path, target_path)
            
            return True
        except Exception as e:
            self.logger.error(f"Failed to handle DLL {dll_path}: {e}")
            return False
    
    def install_script_extender(self, game_name: str, extender_path: str) -> bool:
        """Install a script extender.
        
        Args:
            game_name: Name of the game
            extender_path: Path to the script extender files
            
        Returns:
            True if successful, False otherwise
        """
        try:
            game_dir = self.script_ext_dir / game_name
            game_dir.mkdir(parents=True, exist_ok=True)
            
            # Copy script extender files
            for item in os.listdir(extender_path):
                src = os.path.join(extender_path, item)
                dst = game_dir / item
                if os.path.isdir(src):
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(src, dst)
            
            # Update cache
            self.script_ext_cache[game_name] = {
                "path": str(game_dir),
                "files": os.listdir(game_dir)
            }
            self._save_script_ext_cache()
            
            return True
        except Exception as e:
            self.logger.error(f"Failed to install script extender for {game_name}: {e}")
            return False
    
    def get_script_extender_path(self, game_name: str) -> Optional[str]:
        """Get the path to an installed script extender.
        
        Args:
            game_name: Name of the game
            
        Returns:
            Path to the script extender if installed, None otherwise
        """
        return self.script_ext_cache.get(game_name, {}).get("path")
    
    def run_installer(self, installer_path: str, game_dir: str, args: List[str] = None) -> bool:
        """Run a Windows mod installer.
        
        Args:
            installer_path: Path to the installer executable
            game_dir: Game installation directory
            args: Additional arguments for the installer
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Translate paths
            linux_installer = self.translate_path(installer_path)
            linux_game_dir = self.translate_path(game_dir)
            
            # Prepare command
            cmd = ["wine", linux_installer]
            if args:
                cmd.extend(args)
            
            # Set environment variables
            env = os.environ.copy()
            env["WINEPREFIX"] = str(self.compat_dir / "wine")
            env["WINEDLLOVERRIDES"] = "mscoree,mshtml="
            
            # Run installer
            result = subprocess.run(cmd, env=env, cwd=linux_game_dir)
            return result.returncode == 0
        except Exception as e:
            self.logger.error(f"Failed to run installer {installer_path}: {e}")
            return False
    
    def cleanup(self):
        """Clean up temporary files and caches."""
        try:
            # Clean up old DLL cache entries
            for dll_name, info in list(self.dll_cache.items()):
                cache_path = Path(info["cached_path"])
                if not cache_path.exists():
                    del self.dll_cache[dll_name]
            
            # Clean up old script extender installations
            for game_name, info in list(self.script_ext_cache.items()):
                game_dir = Path(info["path"])
                if not game_dir.exists():
                    del self.script_ext_cache[game_name]
            
            self._save_dll_cache()
            self._save_script_ext_cache()
        except Exception as e:
            self.logger.error(f"Failed to clean up: {e}") 