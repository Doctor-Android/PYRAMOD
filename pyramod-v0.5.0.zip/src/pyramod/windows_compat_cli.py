#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from windows_compat import WindowsCompat

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the Windows compatibility layer CLI."""
    parser = argparse.ArgumentParser(
        description="Windows Mod Compatibility Layer CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "windows_compat"),
        help="Directory to store configuration and compatibility data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Path translation commands
    translate_parser = subparsers.add_parser("translate", help="Translate a Windows path")
    translate_parser.add_argument("windows_path", help="Windows path to translate")

    add_translation_parser = subparsers.add_parser("add-translation", help="Add a path translation")
    add_translation_parser.add_argument("windows_path", help="Windows path")
    add_translation_parser.add_argument("linux_path", help="Linux path")

    # Registry commands
    set_registry_parser = subparsers.add_parser("set-registry", help="Set a registry value")
    set_registry_parser.add_argument("key", help="Registry key")
    set_registry_parser.add_argument("value", help="Registry value name")
    set_registry_parser.add_argument("data", help="Registry value data")

    get_registry_parser = subparsers.add_parser("get-registry", help="Get a registry value")
    get_registry_parser.add_argument("key", help="Registry key")
    get_registry_parser.add_argument("value", help="Registry value name")

    # DLL commands
    handle_dll_parser = subparsers.add_parser("handle-dll", help="Handle a Windows DLL")
    handle_dll_parser.add_argument("dll_path", help="Path to the DLL file")
    handle_dll_parser.add_argument("target_dir", help="Directory to install the DLL")

    # Script extender commands
    install_script_ext_parser = subparsers.add_parser(
        "install-script-extender",
        help="Install a script extender"
    )
    install_script_ext_parser.add_argument("game_name", help="Name of the game")
    install_script_ext_parser.add_argument("extender_path", help="Path to the script extender files")

    get_script_ext_parser = subparsers.add_parser(
        "get-script-extender",
        help="Get script extender path"
    )
    get_script_ext_parser.add_argument("game_name", help="Name of the game")

    # Installer commands
    run_installer_parser = subparsers.add_parser("run-installer", help="Run a Windows mod installer")
    run_installer_parser.add_argument("installer_path", help="Path to the installer executable")
    run_installer_parser.add_argument("game_dir", help="Game installation directory")
    run_installer_parser.add_argument(
        "--args",
        nargs="*",
        help="Additional arguments for the installer"
    )

    # Cleanup command
    cleanup_parser = subparsers.add_parser("cleanup", help="Clean up temporary files and caches")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("windows_compat_cli")
    compat = WindowsCompat(args.config_dir)

    try:
        if args.command == "translate":
            linux_path = compat.translate_path(args.windows_path)
            print(f"Linux path: {linux_path}")

        elif args.command == "add-translation":
            compat.add_path_translation(args.windows_path, args.linux_path)
            logger.info(f"Added path translation: {args.windows_path} -> {args.linux_path}")

        elif args.command == "set-registry":
            compat.set_registry_value(args.key, args.value, args.data)
            logger.info(f"Set registry value: {args.key}\\{args.value} = {args.data}")

        elif args.command == "get-registry":
            value = compat.get_registry_value(args.key, args.value)
            if value is not None:
                print(f"Registry value: {value}")
            else:
                logger.error(f"Registry value not found: {args.key}\\{args.value}")
                sys.exit(1)

        elif args.command == "handle-dll":
            success = compat.handle_dll(args.dll_path, args.target_dir)
            if success:
                logger.info(f"Successfully handled DLL: {args.dll_path}")
            else:
                logger.error(f"Failed to handle DLL: {args.dll_path}")
                sys.exit(1)

        elif args.command == "install-script-extender":
            success = compat.install_script_extender(args.game_name, args.extender_path)
            if success:
                logger.info(f"Successfully installed script extender for {args.game_name}")
            else:
                logger.error(f"Failed to install script extender for {args.game_name}")
                sys.exit(1)

        elif args.command == "get-script-extender":
            path = compat.get_script_extender_path(args.game_name)
            if path:
                print(f"Script extender path: {path}")
            else:
                logger.error(f"No script extender found for {args.game_name}")
                sys.exit(1)

        elif args.command == "run-installer":
            success = compat.run_installer(
                args.installer_path,
                args.game_dir,
                args.args
            )
            if success:
                logger.info(f"Successfully ran installer: {args.installer_path}")
            else:
                logger.error(f"Failed to run installer: {args.installer_path}")
                sys.exit(1)

        elif args.command == "cleanup":
            compat.cleanup()
            logger.info("Successfully cleaned up temporary files and caches")

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 