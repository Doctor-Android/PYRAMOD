#!/usr/bin/env python3
import os
import json
import logging
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import hashlib
import icalendar
from icalendar import Calendar, Event
import pytz
import shutil

class EventsCalendar:
    def __init__(self, config_dir: str):
        self.config_dir = Path(config_dir)
        self.events_dir = self.config_dir / "events"
        self.events_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger("EventsCalendar")
        self.events = self._load_events()
        self.calendar_file = self.events_dir / "events.ics"

    def _load_events(self) -> Dict:
        """Load events from config file."""
        events_file = self.events_dir / "events.json"
        if events_file.exists():
            try:
                with open(events_file, 'r') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                self.logger.error("Failed to load events")
                return {}
        return {}

    def _save_events(self):
        """Save events to config file."""
        events_file = self.events_dir / "events.json"
        try:
            with open(events_file, 'w') as f:
                json.dump(self.events, f, indent=2)
            self._update_icalendar()
        except Exception as e:
            self.logger.error(f"Failed to save events: {e}")

    def _update_icalendar(self):
        """Update the iCalendar file."""
        try:
            cal = Calendar()
            cal.add('prodid', '-//Pyramod//Modding Events Calendar//EN')
            cal.add('version', '2.0')

            for event in self.events.values():
                ical_event = Event()
                ical_event.add('summary', event['title'])
                ical_event.add('description', event['description'])
                ical_event.add('dtstart', datetime.fromisoformat(event['start_time']))
                ical_event.add('dtend', datetime.fromisoformat(event['end_time']))
                ical_event.add('location', event.get('location', ''))
                ical_event.add('url', event.get('url', ''))
                ical_event.add('categories', event['tags'])
                cal.add_component(ical_event)

            with open(self.calendar_file, 'wb') as f:
                f.write(cal.to_ical())

        except Exception as e:
            self.logger.error(f"Failed to update iCalendar: {e}")

    def add_event(self, title: str, description: str, start_time: str,
                 end_time: str, event_type: str, tags: List[str] = None,
                 location: str = "", url: str = "") -> Optional[str]:
        """Add a new event to the calendar."""
        try:
            # Validate times
            start = datetime.fromisoformat(start_time)
            end = datetime.fromisoformat(end_time)
            if end <= start:
                self.logger.error("End time must be after start time")
                return None

            # Generate unique ID
            event_id = hashlib.md5(
                f"{title}{start_time}{end_time}".encode()
            ).hexdigest()

            # Create event
            event = {
                "id": event_id,
                "title": title,
                "description": description,
                "start_time": start_time,
                "end_time": end_time,
                "event_type": event_type,
                "tags": tags or [],
                "location": location,
                "url": url,
                "created_at": datetime.now().isoformat(),
                "participants": []
            }

            self.events[event_id] = event
            self._save_events()

            return event_id

        except Exception as e:
            self.logger.error(f"Failed to add event: {e}")
            return None

    def get_event(self, event_id: str) -> Optional[Dict]:
        """Get event by ID."""
        return self.events.get(event_id)

    def list_events(self, event_type: Optional[str] = None,
                   tags: Optional[List[str]] = None,
                   start_date: Optional[str] = None,
                   end_date: Optional[str] = None) -> List[Dict]:
        """List events with optional filtering."""
        events = []
        for event in self.events.values():
            if event_type and event["event_type"] != event_type:
                continue
            if tags and not all(tag in event["tags"] for tag in tags):
                continue

            event_start = datetime.fromisoformat(event["start_time"])
            if start_date:
                start = datetime.fromisoformat(start_date)
                if event_start < start:
                    continue
            if end_date:
                end = datetime.fromisoformat(end_date)
                if event_start > end:
                    continue

            events.append(event)
        return events

    def update_event(self, event_id: str, updates: Dict) -> bool:
        """Update an existing event."""
        try:
            if event_id not in self.events:
                return False

            event = self.events[event_id]
            
            # Validate time updates
            if "start_time" in updates or "end_time" in updates:
                start = datetime.fromisoformat(
                    updates.get("start_time", event["start_time"])
                )
                end = datetime.fromisoformat(
                    updates.get("end_time", event["end_time"])
                )
                if end <= start:
                    self.logger.error("End time must be after start time")
                    return False

            # Update event
            event.update(updates)
            self._save_events()

            return True

        except Exception as e:
            self.logger.error(f"Failed to update event: {e}")
            return False

    def delete_event(self, event_id: str) -> bool:
        """Delete an event."""
        try:
            if event_id not in self.events:
                return False

            del self.events[event_id]
            self._save_events()

            return True

        except Exception as e:
            self.logger.error(f"Failed to delete event: {e}")
            return False

    def add_participant(self, event_id: str, user_id: str) -> bool:
        """Add a participant to an event."""
        try:
            if event_id not in self.events:
                return False

            event = self.events[event_id]
            if user_id not in event["participants"]:
                event["participants"].append(user_id)
                self._save_events()

            return True

        except Exception as e:
            self.logger.error(f"Failed to add participant: {e}")
            return False

    def remove_participant(self, event_id: str, user_id: str) -> bool:
        """Remove a participant from an event."""
        try:
            if event_id not in self.events:
                return False

            event = self.events[event_id]
            if user_id in event["participants"]:
                event["participants"].remove(user_id)
                self._save_events()

            return True

        except Exception as e:
            self.logger.error(f"Failed to remove participant: {e}")
            return False

    def get_upcoming_events(self, days: int = 7) -> List[Dict]:
        """Get upcoming events within the specified number of days."""
        now = datetime.now()
        end_date = now + timedelta(days=days)
        
        upcoming = []
        for event in self.events.values():
            event_start = datetime.fromisoformat(event["start_time"])
            if now <= event_start <= end_date:
                upcoming.append(event)
        
        return sorted(upcoming, key=lambda x: x["start_time"])

    def export_calendar(self, output_file: str) -> bool:
        """Export events to an iCalendar file."""
        try:
            shutil.copy2(self.calendar_file, output_file)
            return True
        except Exception as e:
            self.logger.error(f"Failed to export calendar: {e}")
            return False

if __name__ == '__main__':
    # Example usage
    logging.basicConfig(level=logging.INFO)
    calendar = EventsCalendar("config")
    
    # Add an event
    event_id = calendar.add_event(
        title="Skyrim Modding Competition",
        description="Annual modding competition for Skyrim",
        start_time="2024-07-01T10:00:00",
        end_time="2024-07-31T23:59:59",
        event_type="competition",
        tags=["skyrim", "competition"],
        url="https://example.com/competition"
    )
    
    if event_id:
        # Add participants
        calendar.add_participant(event_id, "user123")
        calendar.add_participant(event_id, "user456") 