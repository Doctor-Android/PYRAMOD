from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QLineEdit, QTextEdit, QListWidget, QPushButton,
                           QMessageBox)
from PyQt6.QtCore import Qt

class ModpackDetailsDialog(QDialog):
    def __init__(self, modpack_name: str, mod_manager, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Modpack Details - {modpack_name}")
        self.setGeometry(200, 200, 600, 500)
        
        self.modpack_name = modpack_name
        self.mod_manager = mod_manager
        self.modpack_manager = modpack_manager
        
        # Load modpack info
        try:
            self.modpack_info = modpack_manager.get_modpack_info(modpack_name)
        except ValueError as e:
            QMessageBox.warning(self, "Error", str(e))
            self.reject()
            return
            
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Name and description
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Name:"))
        self.name_input = QLineEdit(self.modpack_info["name"])
        name_layout.addWidget(self.name_input)
        layout.addLayout(name_layout)
        
        desc_layout = QVBoxLayout()
        desc_layout.addWidget(QLabel("Description:"))
        self.desc_input = QTextEdit(self.modpack_info["description"])
        self.desc_input.setMaximumHeight(100)
        desc_layout.addWidget(self.desc_input)
        layout.addLayout(desc_layout)
        
        # Available mods
        layout.addWidget(QLabel("Available Mods:"))
        self.available_mods = QListWidget()
        for mod in self.mod_manager.get_installed_mods():
            if mod not in self.modpack_info["mods"]:
                self.available_mods.addItem(mod)
        layout.addWidget(self.available_mods)
        
        # Add/Remove buttons
        mod_buttons = QHBoxLayout()
        add_btn = QPushButton("Add Mod")
        remove_btn = QPushButton("Remove Mod")
        add_btn.clicked.connect(self.add_mod)
        remove_btn.clicked.connect(self.remove_mod)
        mod_buttons.addWidget(add_btn)
        mod_buttons.addWidget(remove_btn)
        layout.addLayout(mod_buttons)
        
        # Current mods
        layout.addWidget(QLabel("Mods in Pack:"))
        self.current_mods = QListWidget()
        for mod in self.modpack_info["mods"]:
            self.current_mods.addItem(mod)
        layout.addWidget(self.current_mods)
        
        # Save/Cancel buttons
        button_layout = QHBoxLayout()
        save_btn = QPushButton("Save Changes")
        cancel_btn = QPushButton("Cancel")
        save_btn.clicked.connect(self.save_changes)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(save_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
    def add_mod(self):
        selected = self.available_mods.selectedItems()
        if not selected:
            return
            
        mod_name = selected[0].text()
        self.current_mods.addItem(mod_name)
        self.available_mods.takeItem(self.available_mods.row(selected[0]))
        
    def remove_mod(self):
        selected = self.current_mods.selectedItems()
        if not selected:
            return
            
        mod_name = selected[0].text()
        self.available_mods.addItem(mod_name)
        self.current_mods.takeItem(self.current_mods.row(selected[0]))
        
    def save_changes(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Modpack name cannot be empty")
            return
            
        description = self.desc_input.toPlainText().strip()
        mods = [self.current_mods.item(i).text() for i in range(self.current_mods.count())]
        
        try:
            if name != self.modpack_name:
                # If name changed, delete old file and create new one
                self.modpack_manager.delete_modpack(self.modpack_name)
                self.modpack_manager.create_modpack(name, description, mods)
            else:
                # Otherwise just update the existing modpack
                self.modpack_manager.update_modpack(name, description, mods)
                
            QMessageBox.information(self, "Success", "Modpack updated successfully!")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to update modpack: {str(e)}") 