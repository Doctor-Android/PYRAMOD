import os
import json
import logging
from typing import Dict, List, Optional
from error_handler import GameDetectionError, error_handler

class GameDetector:
    def __init__(self):
        self.supported_games = {
            "Stardew Valley": {
                "steam_id": "413150",
                "default_path": "~/.steam/steam/steamapps/common/Stardew Valley",
                "mod_path": "Mods",
                "mod_type": "smapi"
            },
            "Terraria": {
                "steam_id": "105600",
                "default_path": "~/.steam/steam/steamapps/common/Terraria",
                "mod_path": "tModLoader/Mods",
                "mod_type": "tmodloader"
            },
            "The Elder Scrolls V: Skyrim": {
                "steam_id": "72850",
                "default_path": "~/.steam/steam/steamapps/common/Skyrim",
                "mod_path": "Data",
                "mod_type": "esp"
            },
            "Fallout 4": {
                "steam_id": "377160",
                "default_path": "~/.steam/steam/steamapps/common/Fallout 4",
                "mod_path": "Data",
                "mod_type": "esp"
            }
        }
        self.logger = logging.getLogger("Pyramod.GameDetector")

    def detect_games(self) -> Dict[str, Dict[str, str]]:
        """Detect installed games"""
        detected_games = {}
        
        for game_name, game_info in self.supported_games.items():
            try:
                # Check default Steam path
                default_path = os.path.expanduser(game_info["default_path"])
                if os.path.exists(default_path):
                    detected_games[game_name] = {
                        "path": default_path,
                        "mod_path": os.path.join(default_path, game_info["mod_path"]),
                        "mod_type": game_info["mod_type"]
                    }
                    self.logger.info(f"Detected {game_name} at {default_path}")
                    continue

                # Check other common locations
                common_paths = [
                    f"~/.steam/steam/steamapps/common/{game_name}",
                    f"~/.local/share/Steam/steamapps/common/{game_name}",
                    f"/usr/share/games/{game_name}",
                    f"/opt/{game_name}"
                ]

                for path in common_paths:
                    expanded_path = os.path.expanduser(path)
                    if os.path.exists(expanded_path):
                        detected_games[game_name] = {
                            "path": expanded_path,
                            "mod_path": os.path.join(expanded_path, game_info["mod_path"]),
                            "mod_type": game_info["mod_type"]
                        }
                        self.logger.info(f"Detected {game_name} at {expanded_path}")
                        break

            except Exception as e:
                error_handler.log_warning(f"Error detecting {game_name}: {str(e)}")
                continue

        return detected_games

    def add_game_manually(self, game_name: str, game_path: str) -> bool:
        """Add a game manually"""
        if game_name not in self.supported_games:
            raise GameDetectionError(f"Game {game_name} is not supported")

        if not os.path.exists(game_path):
            raise GameDetectionError(f"Game path {game_path} does not exist")

        game_info = self.supported_games[game_name]
        mod_path = os.path.join(game_path, game_info["mod_path"])

        # Create mod directory if it doesn't exist
        if not os.path.exists(mod_path):
            try:
                os.makedirs(mod_path)
            except Exception as e:
                raise GameDetectionError(f"Failed to create mod directory: {str(e)}")

        return True

    def get_game_info(self, game_name: str) -> Optional[Dict[str, str]]:
        """Get information about a specific game"""
        return self.supported_games.get(game_name)

    def is_game_supported(self, game_name: str) -> bool:
        """Check if a game is supported"""
        return game_name in self.supported_games

    def get_supported_games(self) -> List[str]:
        """Get list of supported games"""
        return list(self.supported_games.keys())

# Create a global game detector instance
game_detector = GameDetector() 