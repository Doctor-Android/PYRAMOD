"""
Mod compatibility checker for Pyramod.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger("pyramod.mod")

class ModCompatibilityChecker:
    """Checks compatibility between mods."""
    
    def __init__(self, config_dir: str):
        """Initialize the mod compatibility checker.
        
        Args:
            config_dir: Configuration directory
        """
        self.config_dir = Path(config_dir)
        self.mod_config_dir = self.config_dir / "mods"
        self.mod_config_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.mod_config_dir / "compatibility.json"
        if not self.config_file.exists():
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default mod compatibility configuration."""
        default_config = {
            "skyrim": {
                "mods": {},
                "conflicts": {},
                "dependencies": {},
                "load_order": [],
            },
            "fallout4": {
                "mods": {},
                "conflicts": {},
                "dependencies": {},
                "load_order": [],
            }
        }
        
        with open(self.config_file, "w") as f:
            json.dump(default_config, f, indent=4)
    
    def get_config(self) -> Dict[str, Dict[str, Union[Dict[str, Dict], List[str]]]]:
        """Get the current mod compatibility configuration.
        
        Returns:
            Current mod compatibility configuration
        """
        with open(self.config_file, "r") as f:
            return json.load(f)
    
    def update_config(self, config: Dict[str, Dict[str, Union[Dict[str, Dict], List[str]]]]):
        """Update the mod compatibility configuration.
        
        Args:
            config: New mod compatibility configuration
        """
        current_config = self.get_config()
        current_config.update(config)
        
        with open(self.config_file, "w") as f:
            json.dump(current_config, f, indent=4)
    
    def add_mod(self, game: str, mod_id: str, mod_info: Dict[str, Union[str, List[str]]]):
        """Add a mod to the compatibility configuration.
        
        Args:
            game: Game the mod is for
            mod_id: Mod ID
            mod_info: Mod information
        """
        config = self.get_config()
        
        if game not in config:
            config[game] = {
                "mods": {},
                "conflicts": {},
                "dependencies": {},
                "load_order": [],
            }
        
        config[game]["mods"][mod_id] = mod_info
        
        # Add conflicts
        if "conflicts" in mod_info:
            for conflict in mod_info["conflicts"]:
                if conflict not in config[game]["conflicts"]:
                    config[game]["conflicts"][conflict] = []
                config[game]["conflicts"][conflict].append(mod_id)
        
        # Add dependencies
        if "dependencies" in mod_info:
            for dependency in mod_info["dependencies"]:
                if dependency not in config[game]["dependencies"]:
                    config[game]["dependencies"][dependency] = []
                config[game]["dependencies"][dependency].append(mod_id)
        
        # Add to load order
        if mod_id not in config[game]["load_order"]:
            config[game]["load_order"].append(mod_id)
        
        self.update_config(config)
    
    def remove_mod(self, game: str, mod_id: str):
        """Remove a mod from the compatibility configuration.
        
        Args:
            game: Game the mod is for
            mod_id: Mod ID
        """
        config = self.get_config()
        
        if game not in config:
            return
        
        # Remove from mods
        if mod_id in config[game]["mods"]:
            del config[game]["mods"][mod_id]
        
        # Remove from conflicts
        for conflict, mods in list(config[game]["conflicts"].items()):
            if mod_id in mods:
                mods.remove(mod_id)
            if not mods:
                del config[game]["conflicts"][conflict]
        
        # Remove from dependencies
        for dependency, mods in list(config[game]["dependencies"].items()):
            if mod_id in mods:
                mods.remove(mod_id)
            if not mods:
                del config[game]["dependencies"][dependency]
        
        # Remove from load order
        if mod_id in config[game]["load_order"]:
            config[game]["load_order"].remove(mod_id)
        
        self.update_config(config)
    
    def check_compatibility(self, game: str, mod_ids: List[str]) -> Dict[str, Union[bool, List[str]]]:
        """Check compatibility between mods.
        
        Args:
            game: Game the mods are for
            mod_ids: List of mod IDs to check
        
        Returns:
            Compatibility check results
        """
        config = self.get_config()
        
        if game not in config:
            return {
                "compatible": False,
                "warnings": [f"Unknown game: {game}"]
            }
        
        warnings = []
        
        # Check conflicts
        for mod_id in mod_ids:
            if mod_id in config[game]["conflicts"]:
                for conflict in config[game]["conflicts"][mod_id]:
                    if conflict in mod_ids:
                        warnings.append(f"Conflict between {mod_id} and {conflict}")
        
        # Check dependencies
        for mod_id in mod_ids:
            if mod_id in config[game]["dependencies"]:
                for dependency in config[game]["dependencies"][mod_id]:
                    if dependency not in mod_ids:
                        warnings.append(f"{mod_id} requires {dependency}")
        
        # Check load order
        load_order = config[game]["load_order"]
        for i, mod_id in enumerate(mod_ids):
            if mod_id in load_order:
                for j, other_mod_id in enumerate(mod_ids):
                    if other_mod_id in load_order:
                        if load_order.index(mod_id) > load_order.index(other_mod_id):
                            warnings.append(f"{mod_id} should load after {other_mod_id}")
        
        return {
            "compatible": len(warnings) == 0,
            "warnings": warnings
        }
    
    def get_load_order(self, game: str, mod_ids: List[str]) -> List[str]:
        """Get the recommended load order for mods.
        
        Args:
            game: Game the mods are for
            mod_ids: List of mod IDs to order
        
        Returns:
            Recommended load order
        """
        config = self.get_config()
        
        if game not in config:
            return mod_ids
        
        load_order = config[game]["load_order"]
        return [mod_id for mod_id in load_order if mod_id in mod_ids] 