#!/usr/bin/env python3
import os
import json
import time
import psutil
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Union
import GPUtil

class SystemMonitor:
    """Manages system resource monitoring for modded games."""
    
    def __init__(self, config_dir: str):
        """Initialize the system monitoring system.
        
        Args:
            config_dir: Directory to store monitoring data
        """
        self.config_dir = Path(config_dir)
        self.monitoring_dir = self.config_dir / "monitoring"
        self.history_dir = self.config_dir / "history"
        
        # Create necessary directories
        self.monitoring_dir.mkdir(parents=True, exist_ok=True)
        self.history_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        self.logger = logging.getLogger("system_monitor")
        
        # Load monitoring configuration
        self._load_config()
        
        # Initialize monitoring state
        self.monitoring = False
        self.current_game = None
        self.monitoring_start = None
        self.metrics_history = []
    
    def _load_config(self):
        """Load monitoring configuration from JSON file."""
        self.config_file = self.monitoring_dir / "config.json"
        if self.config_file.exists():
            with open(self.config_file, "r") as f:
                self.config = json.load(f)
        else:
            self.config = {
                "monitoring_interval": 1.0,  # seconds
                "history_retention": 7,  # days
                "alert_thresholds": {
                    "cpu_percent": 90,
                    "memory_percent": 85,
                    "gpu_percent": 90,
                    "gpu_memory_percent": 85,
                    "disk_percent": 90
                },
                "monitored_processes": []
            }
            self._save_config()
    
    def _save_config(self):
        """Save monitoring configuration to JSON file."""
        with open(self.config_file, "w") as f:
            json.dump(self.config, f, indent=4)
    
    def start_monitoring(self, game_name: str):
        """Start monitoring system resources for a game.
        
        Args:
            game_name: Name of the game to monitor
        """
        if self.monitoring:
            self.logger.warning("Monitoring already in progress")
            return False
        
        self.monitoring = True
        self.current_game = game_name
        self.monitoring_start = datetime.now()
        self.metrics_history = []
        
        # Start monitoring thread
        import threading
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            daemon=True
        )
        self.monitor_thread.start()
        
        return True
    
    def stop_monitoring(self):
        """Stop monitoring system resources."""
        if not self.monitoring:
            self.logger.warning("No monitoring in progress")
            return False
        
        self.monitoring = False
        self.monitor_thread.join()
        
        # Save monitoring history
        if self.metrics_history:
            history_file = self.history_dir / f"{self.current_game}_{self.monitoring_start.strftime('%Y%m%d_%H%M%S')}.json"
            with open(history_file, "w") as f:
                json.dump({
                    "game": self.current_game,
                    "start_time": self.monitoring_start.isoformat(),
                    "end_time": datetime.now().isoformat(),
                    "metrics": self.metrics_history
                }, f, indent=4)
        
        self.current_game = None
        self.monitoring_start = None
        self.metrics_history = []
        
        return True
    
    def _monitoring_loop(self):
        """Main monitoring loop."""
        while self.monitoring:
            try:
                metrics = self._collect_metrics()
                self.metrics_history.append(metrics)
                
                # Check for alerts
                alerts = self._check_alerts(metrics)
                if alerts:
                    self._handle_alerts(alerts)
                
                time.sleep(self.config["monitoring_interval"])
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(1)
    
    def _collect_metrics(self) -> Dict:
        """Collect current system metrics.
        
        Returns:
            Dictionary of system metrics
        """
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "cpu": {
                "percent": psutil.cpu_percent(interval=None),
                "count": psutil.cpu_count(),
                "frequency": psutil.cpu_freq().current if psutil.cpu_freq() else None
            },
            "memory": {
                "total": psutil.virtual_memory().total,
                "available": psutil.virtual_memory().available,
                "percent": psutil.virtual_memory().percent,
                "used": psutil.virtual_memory().used
            },
            "disk": {
                "total": psutil.disk_usage("/").total,
                "used": psutil.disk_usage("/").used,
                "free": psutil.disk_usage("/").free,
                "percent": psutil.disk_usage("/").percent
            },
            "gpu": []
        }
        
        # Get GPU metrics if available
        try:
            gpus = GPUtil.getGPUs()
            for gpu in gpus:
                metrics["gpu"].append({
                    "id": gpu.id,
                    "name": gpu.name,
                    "load": gpu.load * 100,
                    "memory_total": gpu.memoryTotal,
                    "memory_used": gpu.memoryUsed,
                    "memory_percent": gpu.memoryUtil * 100,
                    "temperature": gpu.temperature
                })
        except Exception as e:
            self.logger.warning(f"Could not get GPU metrics: {e}")
        
        # Get process metrics for monitored processes
        metrics["processes"] = []
        for proc_name in self.config["monitored_processes"]:
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                if proc.info["name"] == proc_name:
                    metrics["processes"].append({
                        "name": proc_name,
                        "pid": proc.info["pid"],
                        "cpu_percent": proc.info["cpu_percent"],
                        "memory_percent": proc.info["memory_percent"]
                    })
        
        return metrics
    
    def _check_alerts(self, metrics: Dict) -> List[Dict]:
        """Check metrics against alert thresholds.
        
        Args:
            metrics: Current system metrics
            
        Returns:
            List of triggered alerts
        """
        alerts = []
        thresholds = self.config["alert_thresholds"]
        
        # Check CPU usage
        if metrics["cpu"]["percent"] > thresholds["cpu_percent"]:
            alerts.append({
                "type": "cpu",
                "level": "warning",
                "message": f"High CPU usage: {metrics['cpu']['percent']}%"
            })
        
        # Check memory usage
        if metrics["memory"]["percent"] > thresholds["memory_percent"]:
            alerts.append({
                "type": "memory",
                "level": "warning",
                "message": f"High memory usage: {metrics['memory']['percent']}%"
            })
        
        # Check GPU usage
        for gpu in metrics["gpu"]:
            if gpu["load"] > thresholds["gpu_percent"]:
                alerts.append({
                    "type": "gpu",
                    "level": "warning",
                    "message": f"High GPU usage on {gpu['name']}: {gpu['load']}%"
                })
            if gpu["memory_percent"] > thresholds["gpu_memory_percent"]:
                alerts.append({
                    "type": "gpu_memory",
                    "level": "warning",
                    "message": f"High GPU memory usage on {gpu['name']}: {gpu['memory_percent']}%"
                })
        
        # Check disk usage
        if metrics["disk"]["percent"] > thresholds["disk_percent"]:
            alerts.append({
                "type": "disk",
                "level": "warning",
                "message": f"High disk usage: {metrics['disk']['percent']}%"
            })
        
        return alerts
    
    def _handle_alerts(self, alerts: List[Dict]):
        """Handle triggered alerts.
        
        Args:
            alerts: List of triggered alerts
        """
        for alert in alerts:
            self.logger.warning(alert["message"])
            # TODO: Implement alert handling (e.g., notifications, actions)
    
    def get_current_metrics(self) -> Optional[Dict]:
        """Get current system metrics.
        
        Returns:
            Current system metrics or None if not monitoring
        """
        if not self.monitoring:
            return None
        
        return self._collect_metrics()
    
    def get_metrics_history(
        self,
        game_name: str = None,
        start_time: str = None,
        end_time: str = None
    ) -> List[Dict]:
        """Get historical metrics.
        
        Args:
            game_name: Filter by game name
            start_time: Filter by start time (ISO format)
            end_time: Filter by end time (ISO format)
            
        Returns:
            List of historical metrics
        """
        history = []
        
        # Load history files
        for history_file in self.history_dir.glob("*.json"):
            with open(history_file, "r") as f:
                data = json.load(f)
                
                # Apply filters
                if game_name and data["game"] != game_name:
                    continue
                if start_time and data["start_time"] < start_time:
                    continue
                if end_time and data["end_time"] > end_time:
                    continue
                
                history.append(data)
        
        return history
    
    def add_monitored_process(self, process_name: str):
        """Add a process to monitor.
        
        Args:
            process_name: Name of the process to monitor
        """
        if process_name not in self.config["monitored_processes"]:
            self.config["monitored_processes"].append(process_name)
            self._save_config()
    
    def remove_monitored_process(self, process_name: str):
        """Remove a monitored process.
        
        Args:
            process_name: Name of the process to remove
        """
        if process_name in self.config["monitored_processes"]:
            self.config["monitored_processes"].remove(process_name)
            self._save_config()
    
    def update_alert_thresholds(self, thresholds: Dict):
        """Update alert thresholds.
        
        Args:
            thresholds: New alert thresholds
        """
        self.config["alert_thresholds"].update(thresholds)
        self._save_config()
    
    def cleanup_history(self):
        """Clean up old history files."""
        retention_days = self.config["history_retention"]
        cutoff_time = datetime.now().timestamp() - (retention_days * 24 * 60 * 60)
        
        for history_file in self.history_dir.glob("*.json"):
            if history_file.stat().st_mtime < cutoff_time:
                history_file.unlink()

# Example usage
if __name__ == "__main__":
    # Initialize system monitor
    monitor = SystemMonitor("~/.config/pyramod/monitor")
    
    # Start monitoring
    monitor.start_monitoring("Skyrim")
    
    # Add process to monitor
    monitor.add_monitored_process("TESV.exe")
    
    # Monitor for 10 seconds
    import time
    time.sleep(10)
    
    # Get current metrics
    metrics = monitor.get_current_metrics()
    print("Current metrics:", metrics)
    
    # Stop monitoring
    monitor.stop_monitoring()
    
    # Get history
    history = monitor.get_metrics_history(game_name="Skyrim")
    print("History:", history) 