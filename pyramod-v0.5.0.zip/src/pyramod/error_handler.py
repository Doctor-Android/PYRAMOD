import logging
import os
import traceback
from datetime import datetime
from typing import Optional, Dict, Any

class PyramodError(Exception):
    """Base exception class for Pyramod"""
    def __init__(self, message: str, error_code: Optional[str] = None):
        self.message = message
        self.error_code = error_code
        self.timestamp = datetime.now()
        super().__init__(self.message)

class ModInstallationError(PyramodError):
    """Raised when mod installation fails"""
    pass

class ModUninstallationError(PyramodError):
    """Raised when mod uninstallation fails"""
    pass

class GameDetectionError(PyramodError):
    """Raised when game detection fails"""
    pass

class ProfileError(PyramodError):
    """Raised when profile operations fail"""
    pass

class ConflictError(PyramodError):
    """Raised when mod conflicts are detected"""
    pass

class ErrorHandler:
    def __init__(self, log_dir: str = "logs"):
        self.log_dir = log_dir
        self.setup_logging()

    def setup_logging(self):
        """Set up logging configuration"""
        if not os.path.exists(self.log_dir):
            os.makedirs(self.log_dir)

        log_file = os.path.join(self.log_dir, f"pyramod_{datetime.now().strftime('%Y%m%d')}.log")
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file),
                logging.StreamHandler()
            ]
        )
        
        self.logger = logging.getLogger("Pyramod")

    def handle_error(self, error: Exception, context: Optional[Dict[str, Any]] = None):
        """Handle an error and log it"""
        error_info = {
            "error_type": type(error).__name__,
            "error_message": str(error),
            "timestamp": datetime.now().isoformat(),
            "context": context or {},
            "traceback": traceback.format_exc()
        }

        # Log the error
        self.logger.error(f"Error occurred: {error_info['error_type']} - {error_info['error_message']}")
        self.logger.debug(f"Error details: {error_info}")

        # Return user-friendly error message
        if isinstance(error, PyramodError):
            return f"Error: {error.message}"
        else:
            return "An unexpected error occurred. Please check the logs for details."

    def log_info(self, message: str, data: Optional[Dict[str, Any]] = None):
        """Log an informational message"""
        self.logger.info(message, extra={"data": data})

    def log_warning(self, message: str, data: Optional[Dict[str, Any]] = None):
        """Log a warning message"""
        self.logger.warning(message, extra={"data": data})

    def log_debug(self, message: str, data: Optional[Dict[str, Any]] = None):
        """Log a debug message"""
        self.logger.debug(message, extra={"data": data})

# Create a global error handler instance
error_handler = ErrorHandler()

def handle_error(error: Exception, context: Optional[Dict[str, Any]] = None) -> str:
    """Global function to handle errors"""
    return error_handler.handle_error(error, context) 