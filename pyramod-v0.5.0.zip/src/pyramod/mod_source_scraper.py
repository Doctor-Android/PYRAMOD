import requests
from bs4 import BeautifulSoup
import re
from datetime import datetime
from typing import Dict, Optional, List
import logging
from urllib.parse import urlparse, parse_qs
import json
from pathlib import Path
import time

class ModSourceScraper:
    def __init__(self, cache_path: Path):
        self.cache_path = cache_path / "scraper_cache"
        self.cache_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=cache_path / "scraper.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # User agent for requests
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        
    def get_cached_data(self, url: str) -> Optional[Dict]:
        """Get cached data for a URL"""
        try:
            cache_file = self.cache_path / f"{hash(url)}.json"
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    data = json.load(f)
                    # Check if cache is still valid (24 hours)
                    if datetime.fromisoformat(data["timestamp"]) > datetime.now() - timedelta(hours=24):
                        return data["data"]
        except Exception as e:
            logging.error(f"Failed to read cache: {e}")
        return None
        
    def cache_data(self, url: str, data: Dict):
        """Cache data for a URL"""
        try:
            cache_file = self.cache_path / f"{hash(url)}.json"
            with open(cache_file, 'w') as f:
                json.dump({
                    "timestamp": datetime.now().isoformat(),
                    "data": data
                }, f)
        except Exception as e:
            logging.error(f"Failed to write cache: {e}")
            
    def scrape_nexus_mod(self, url: str) -> Optional[Dict]:
        """Scrape mod information from Nexus Mods"""
        try:
            # Check cache first
            cached_data = self.get_cached_data(url)
            if cached_data:
                return cached_data
                
            # Extract mod ID
            mod_id = re.search(r"mods/(\d+)", url)
            if not mod_id:
                return None
            mod_id = mod_id.group(1)
            
            # Make request
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract version
            version_element = soup.find("div", class_="file-version")
            version = version_element.text.strip() if version_element else "Unknown"
            
            # Extract release date
            date_element = soup.find("time")
            release_date = datetime.fromisoformat(date_element["datetime"]) if date_element else datetime.now()
            
            # Extract download URL
            download_element = soup.find("a", class_="download-button")
            download_url = download_element["href"] if download_element else None
            
            # Extract changelog
            changelog_element = soup.find("div", class_="changelog")
            changelog = changelog_element.text.strip() if changelog_element else ""
            
            # Extract file hash
            hash_element = soup.find("div", class_="file-hash")
            file_hash = hash_element.text.strip() if hash_element else None
            
            data = {
                "version": version,
                "release_date": release_date,
                "download_url": download_url,
                "changelog": changelog,
                "file_hash": file_hash
            }
            
            # Cache the data
            self.cache_data(url, data)
            
            return data
            
        except Exception as e:
            logging.error(f"Failed to scrape Nexus mod: {e}")
            return None
            
    def scrape_google_docs(self, url: str) -> Optional[Dict]:
        """Scrape mod information from Google Docs spreadsheet"""
        try:
            # Check cache first
            cached_data = self.get_cached_data(url)
            if cached_data:
                return cached_data
                
            # Extract spreadsheet ID
            spreadsheet_id = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", url)
            if not spreadsheet_id:
                return None
            spreadsheet_id = spreadsheet_id.group(1)
            
            # Make request
            response = requests.get(f"https://docs.google.com/spreadsheets/d/{spreadsheet_id}/export?format=html",
                                 headers=self.headers)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract data from table
            table = soup.find("table")
            if not table:
                return None
                
            # Process table data
            # This is a simplified example - actual implementation would need to parse the specific spreadsheet format
            data = {
                "version": "Unknown",
                "release_date": datetime.now(),
                "download_url": None,
                "changelog": "",
                "file_hash": None
            }
            
            # Cache the data
            self.cache_data(url, data)
            
            return data
            
        except Exception as e:
            logging.error(f"Failed to scrape Google Docs: {e}")
            return None
            
    def scrape_other_site(self, url: str) -> Optional[Dict]:
        """Scrape mod information from other sites"""
        try:
            # Check cache first
            cached_data = self.get_cached_data(url)
            if cached_data:
                return cached_data
                
            # Make request
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Try to find Nexus Mods link
            nexus_link = soup.find("a", href=re.compile(r"nexusmods\.com/\w+/mods/\d+"))
            if nexus_link:
                return self.scrape_nexus_mod(nexus_link["href"])
                
            # Try to find version information
            version_element = soup.find(string=re.compile(r"v?\d+\.\d+(\.\d+)?", re.IGNORECASE))
            version = version_element.strip() if version_element else "Unknown"
            
            # Try to find release date
            date_element = soup.find("time") or soup.find(string=re.compile(r"\d{4}-\d{2}-\d{2}"))
            release_date = datetime.fromisoformat(date_element["datetime"]) if date_element and hasattr(date_element, "datetime") else datetime.now()
            
            # Try to find download link
            download_element = soup.find("a", href=re.compile(r"\.(zip|rar|7z)$", re.IGNORECASE))
            download_url = download_element["href"] if download_element else None
            
            # Try to find changelog
            changelog_element = soup.find(string=re.compile(r"changelog", re.IGNORECASE))
            changelog = changelog_element.parent.parent.text if changelog_element else ""
            
            data = {
                "version": version,
                "release_date": release_date,
                "download_url": download_url,
                "changelog": changelog,
                "file_hash": None
            }
            
            # Cache the data
            self.cache_data(url, data)
            
            return data
            
        except Exception as e:
            logging.error(f"Failed to scrape other site: {e}")
            return None
            
    def scrape_url(self, url: str) -> Optional[Dict]:
        """Scrape mod information from any supported URL"""
        try:
            if "nexusmods.com" in url:
                return self.scrape_nexus_mod(url)
            elif "docs.google.com" in url:
                return self.scrape_google_docs(url)
            else:
                return self.scrape_other_site(url)
                
        except Exception as e:
            logging.error(f"Failed to scrape URL: {e}")
            return None
            
    def find_nexus_links(self, text: str) -> List[str]:
        """Find Nexus Mods links in text"""
        try:
            return re.findall(r"https?://(?:www\.)?nexusmods\.com/\w+/mods/\d+", text)
        except Exception as e:
            logging.error(f"Failed to find Nexus links: {e}")
            return []
            
    def validate_url(self, url: str) -> bool:
        """Validate if a URL is supported"""
        try:
            parsed = urlparse(url)
            return any([
                "nexusmods.com" in parsed.netloc,
                "docs.google.com" in parsed.netloc,
                any(re.search(pattern, url) for pattern in [
                    r"moddb\.com/mods/[\w-]+",
                    r"steamcommunity\.com/sharedfiles/filedetails/\?id=\d+"
                ])
            ])
        except Exception as e:
            logging.error(f"Failed to validate URL: {e}")
            return False 