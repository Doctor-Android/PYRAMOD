import tkinter as tk
from tkinter import ttk
import json
import os
from typing import Dict, Any

class AboutDialog:
    def __init__(self, parent):
        self.parent = parent
        self.window = tk.Toplevel(parent)
        self.window.title("About Pyramod")
        self.window.geometry("500x400")
        
        # Load version info
        self.version_info = self.load_version_info()
        
        # Create main frame
        self.main_frame = ttk.Frame(self.window)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        
        # Logo/Title
        title = ttk.Label(self.main_frame, text="Pyramod", font=('Helvetica', 20, 'bold'))
        title.pack(pady=10)
        
        # Version
        version = ttk.Label(self.main_frame, text=f"Version {self.version_info['version']}")
        version.pack(pady=5)
        
        # Description
        desc = ttk.Label(self.main_frame, text="A powerful mod manager for Linux games", wraplength=400)
        desc.pack(pady=10)
        
        # Features
        features_frame = ttk.LabelFrame(self.main_frame, text="Features")
        features_frame.pack(fill=tk.X, pady=10)
        
        features = [
            "Proton/Wine compatibility",
            "Multi-source mod support",
            "Load order management",
            "Mod deployment system",
            "System resource monitoring",
            "Mod showcase gallery"
        ]
        
        for feature in features:
            ttk.Label(features_frame, text=f"• {feature}").pack(anchor=tk.W, padx=5, pady=2)
            
        # Credits
        credits_frame = ttk.LabelFrame(self.main_frame, text="Credits")
        credits_frame.pack(fill=tk.X, pady=10)
        
        credits = [
            "Developed by: Pyramod Team",
            "Special thanks to:",
            "• Proton Team",
            "• Wine Team",
            "• Linux Gaming Community"
        ]
        
        for credit in credits:
            ttk.Label(credits_frame, text=credit).pack(anchor=tk.W, padx=5, pady=2)
            
        # License
        license_frame = ttk.LabelFrame(self.main_frame, text="License")
        license_frame.pack(fill=tk.X, pady=10)
        
        ttk.Label(license_frame, text="GNU General Public License v3.0").pack(padx=5, pady=5)
        
        # Close button
        ttk.Button(self.main_frame, text="Close", command=self.window.destroy).pack(pady=10)
        
    def load_version_info(self) -> Dict[str, Any]:
        """Load version info from file"""
        try:
            with open("version.json", "r") as f:
                return json.load(f)
        except:
            return {
                "version": "1.0.0",
                "build": "2024.1",
                "release_date": "2024-03-14"
            } 