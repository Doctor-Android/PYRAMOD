import json
from pathlib import Path
from typing import Dict, List, Optional
import logging
import requests
from bs4 import BeautifulSoup
import re
from datetime import datetime
import hashlib
from urllib.parse import urlparse, parse_qs

class ModSourceManager:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.sources_path = base_path / "sources"
        self.sources_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=self.base_path / "source_manager.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Load source configurations
        self.sources = self.load_sources()
        
    def load_sources(self) -> Dict:
        """Load source configurations"""
        try:
            sources_file = self.sources_path / "sources.json"
            if sources_file.exists():
                with open(sources_file, 'r') as f:
                    return json.load(f)
            return {
                "nexus": {
                    "enabled": True,
                    "api_key": None,
                    "rate_limit": 100,
                    "last_check": None
                },
                "google_docs": {
                    "enabled": True,
                    "spreadsheet_id": None,
                    "sheet_name": "Mods",
                    "last_check": None
                },
                "other_sites": {
                    "enabled": True,
                    "patterns": [
                        r"nexusmods\.com/\w+/mods/\d+",
                        r"moddb\.com/mods/[\w-]+",
                        r"steamcommunity\.com/sharedfiles/filedetails/\?id=\d+"
                    ],
                    "last_check": None
                }
            }
        except Exception as e:
            logging.error(f"Failed to load sources: {e}")
            return {}
            
    def save_sources(self):
        """Save source configurations"""
        try:
            sources_file = self.sources_path / "sources.json"
            with open(sources_file, 'w') as f:
                json.dump(self.sources, f, indent=2)
        except Exception as e:
            logging.error(f"Failed to save sources: {e}")
            
    def check_nexus_mod(self, mod_url: str) -> Optional[Dict]:
        """Check for updates on Nexus Mods"""
        try:
            if not self.sources["nexus"]["enabled"]:
                return None
                
            # Extract mod ID from URL
            mod_id = re.search(r"mods/(\d+)", mod_url)
            if not mod_id:
                return None
            mod_id = mod_id.group(1)
            
            # Make API request
            headers = {"apikey": self.sources["nexus"]["api_key"]} if self.sources["nexus"]["api_key"] else {}
            response = requests.get(f"https://api.nexusmods.com/v1/games/skyrimspecialedition/mods/{mod_id}", 
                                 headers=headers)
            response.raise_for_status()
            
            data = response.json()
            return {
                "version": data["version"],
                "release_date": datetime.fromisoformat(data["updated_at"]),
                "download_url": data["main_file"]["download_url"],
                "changelog": data["description"],
                "file_hash": data["main_file"]["md5"]
            }
            
        except Exception as e:
            logging.error(f"Failed to check Nexus mod: {e}")
            return None
            
    def check_google_docs(self, doc_url: str) -> Optional[Dict]:
        """Check for updates in Google Docs spreadsheet"""
        try:
            if not self.sources["google_docs"]["enabled"]:
                return None
                
            # Extract spreadsheet ID from URL
            spreadsheet_id = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", doc_url)
            if not spreadsheet_id:
                return None
            spreadsheet_id = spreadsheet_id.group(1)
            
            # Make API request
            response = requests.get(
                f"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/{self.sources['google_docs']['sheet_name']}"
            )
            response.raise_for_status()
            
            data = response.json()
            # Process spreadsheet data to find mod info
            # This is a simplified example - actual implementation would need to parse the spreadsheet format
            return None
            
        except Exception as e:
            logging.error(f"Failed to check Google Docs: {e}")
            return None
            
    def check_other_sites(self, url: str) -> Optional[Dict]:
        """Check for updates on other sites"""
        try:
            if not self.sources["other_sites"]["enabled"]:
                return None
                
            # Check if URL matches any known patterns
            for pattern in self.sources["other_sites"]["patterns"]:
                if re.search(pattern, url):
                    # If it's a Nexus Mods link, use the Nexus checker
                    if "nexusmods.com" in url:
                        return self.check_nexus_mod(url)
                        
                    # For other sites, we'll need to implement specific scrapers
                    # This is a placeholder for future implementation
                    return None
                    
            return None
            
        except Exception as e:
            logging.error(f"Failed to check other site: {e}")
            return None
            
    def check_all_sources(self, mod_url: str) -> Optional[Dict]:
        """Check all enabled sources for updates"""
        try:
            # Try Nexus first
            if "nexusmods.com" in mod_url:
                result = self.check_nexus_mod(mod_url)
                if result:
                    return result
                    
            # Try Google Docs
            if "docs.google.com" in mod_url:
                result = self.check_google_docs(mod_url)
                if result:
                    return result
                    
            # Try other sites
            result = self.check_other_sites(mod_url)
            if result:
                return result
                
            return None
            
        except Exception as e:
            logging.error(f"Failed to check all sources: {e}")
            return None
            
    def set_source_config(self, source: str, config: Dict) -> bool:
        """Update configuration for a source"""
        try:
            if source not in self.sources:
                return False
                
            self.sources[source].update(config)
            self.save_sources()
            return True
            
        except Exception as e:
            logging.error(f"Failed to set source config: {e}")
            return False
            
    def get_source_config(self, source: str) -> Optional[Dict]:
        """Get configuration for a source"""
        return self.sources.get(source)
        
    def enable_source(self, source: str, enabled: bool) -> bool:
        """Enable or disable a source"""
        try:
            if source not in self.sources:
                return False
                
            self.sources[source]["enabled"] = enabled
            self.save_sources()
            return True
            
        except Exception as e:
            logging.error(f"Failed to enable/disable source: {e}")
            return False 