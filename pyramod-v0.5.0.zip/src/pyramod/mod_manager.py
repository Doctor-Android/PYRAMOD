"""
Mod manager for Linux Vortex Nexus.
"""

import os
import json
import logging
import shutil
from pathlib import Path
from typing import Dict, List, Optional, Union

from .mod_installer import ModInstaller
from .mod_compatibility import ModCompatibilityChecker

logger = logging.getLogger("vortex.manager")

class ModManager:
    """Manages mods and profiles."""
    
    def __init__(self, config_dir: str):
        """Initialize the mod manager.
        
        Args:
            config_dir: Configuration directory
        """
        self.config_dir = Path(config_dir)
        self.profile_dir = self.config_dir / "profiles"
        self.profile_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.profile_dir / "profiles.json"
        if not self.config_file.exists():
            self._create_default_config()
        
        self.installer = ModInstaller(config_dir)
        self.compatibility = ModCompatibilityChecker(config_dir)
    
    def _create_default_config(self):
        """Create default profile configuration."""
        default_config = {
            "skyrim": {
                "profiles": {},
                "active_profile": None,
            },
            "fallout4": {
                "profiles": {},
                "active_profile": None,
            }
        }
        
        with open(self.config_file, "w") as f:
            json.dump(default_config, f, indent=4)
    
    def get_config(self) -> Dict[str, Dict[str, Union[Dict[str, Dict], Optional[str]]]]:
        """Get the current profile configuration.
        
        Returns:
            Current profile configuration
        """
        with open(self.config_file, "r") as f:
            return json.load(f)
    
    def update_config(self, config: Dict[str, Dict[str, Union[Dict[str, Dict], Optional[str]]]]):
        """Update the profile configuration.
        
        Args:
            config: New profile configuration
        """
        current_config = self.get_config()
        current_config.update(config)
        
        with open(self.config_file, "w") as f:
            json.dump(current_config, f, indent=4)
    
    def create_profile(self, game: str, profile_id: str, name: str) -> bool:
        """Create a new mod profile.
        
        Args:
            game: Game to create profile for
            profile_id: Profile ID
            name: Profile name
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            config[game] = {
                "profiles": {},
                "active_profile": None,
            }
        
        if profile_id in config[game]["profiles"]:
            logger.error(f"Profile already exists: {profile_id}")
            return False
        
        # Create profile directory
        profile_dir = self.profile_dir / game / profile_id
        profile_dir.mkdir(parents=True, exist_ok=True)
        
        # Add to config
        config[game]["profiles"][profile_id] = {
            "name": name,
            "mods": [],
        }
        
        self.update_config(config)
        return True
    
    def delete_profile(self, game: str, profile_id: str) -> bool:
        """Delete a mod profile.
        
        Args:
            game: Game to delete profile from
            profile_id: Profile ID
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if profile_id not in config[game]["profiles"]:
            return False
        
        # Remove profile directory
        profile_dir = self.profile_dir / game / profile_id
        if profile_dir.exists():
            try:
                shutil.rmtree(profile_dir)
            except Exception as e:
                logger.error(f"Failed to remove profile directory: {e}")
                return False
        
        # Remove from config
        del config[game]["profiles"][profile_id]
        
        # Update active profile if needed
        if config[game]["active_profile"] == profile_id:
            config[game]["active_profile"] = None
        
        self.update_config(config)
        return True
    
    def activate_profile(self, game: str, profile_id: str) -> bool:
        """Activate a mod profile.
        
        Args:
            game: Game to activate profile for
            profile_id: Profile ID
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if profile_id not in config[game]["profiles"]:
            return False
        
        config[game]["active_profile"] = profile_id
        self.update_config(config)
        return True
    
    def get_active_profile(self, game: str) -> Optional[str]:
        """Get the active profile for a game.
        
        Args:
            game: Game to get active profile for
        
        Returns:
            Active profile ID, or None if none active
        """
        config = self.get_config()
        
        if game not in config:
            return None
        
        return config[game]["active_profile"]
    
    def list_profiles(self, game: str) -> List[Dict[str, Union[str, bool]]]:
        """List profiles for a game.
        
        Args:
            game: Game to list profiles for
        
        Returns:
            List of profiles
        """
        config = self.get_config()
        
        if game not in config:
            return []
        
        profiles = []
        for profile_id, profile in config[game]["profiles"].items():
            profiles.append({
                "id": profile_id,
                "name": profile["name"],
                "active": config[game]["active_profile"] == profile_id,
            })
        
        return profiles
    
    def add_mod_to_profile(self, game: str, profile_id: str, mod_id: str) -> bool:
        """Add a mod to a profile.
        
        Args:
            game: Game to add mod to
            profile_id: Profile ID
            mod_id: Mod ID
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if profile_id not in config[game]["profiles"]:
            return False
        
        if mod_id not in self.installer.get_installed_mods(game):
            logger.error(f"Mod not installed: {mod_id}")
            return False
        
        if mod_id in config[game]["profiles"][profile_id]["mods"]:
            logger.error(f"Mod already in profile: {mod_id}")
            return False
        
        config[game]["profiles"][profile_id]["mods"].append(mod_id)
        self.update_config(config)
        return True
    
    def remove_mod_from_profile(self, game: str, profile_id: str, mod_id: str) -> bool:
        """Remove a mod from a profile.
        
        Args:
            game: Game to remove mod from
            profile_id: Profile ID
            mod_id: Mod ID
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if profile_id not in config[game]["profiles"]:
            return False
        
        if mod_id not in config[game]["profiles"][profile_id]["mods"]:
            return False
        
        config[game]["profiles"][profile_id]["mods"].remove(mod_id)
        self.update_config(config)
        return True
    
    def get_profile_mods(self, game: str, profile_id: str) -> List[str]:
        """Get mods in a profile.
        
        Args:
            game: Game to get mods for
            profile_id: Profile ID
        
        Returns:
            List of mod IDs
        """
        config = self.get_config()
        
        if game not in config:
            return []
        
        if profile_id not in config[game]["profiles"]:
            return []
        
        return config[game]["profiles"][profile_id]["mods"]
    
    def check_profile_compatibility(self, game: str, profile_id: str) -> Dict[str, Union[bool, List[str]]]:
        """Check compatibility of mods in a profile.
        
        Args:
            game: Game to check compatibility for
            profile_id: Profile ID
        
        Returns:
            Compatibility check results
        """
        mod_ids = self.get_profile_mods(game, profile_id)
        return self.compatibility.check_compatibility(game, mod_ids)
    
    def export_profile(self, game: str, profile_id: str, path: str) -> bool:
        """Export a mod profile.
        
        Args:
            game: Game to export profile from
            profile_id: Profile ID
            path: Path to export to
        
        Returns:
            True if successful, False otherwise
        """
        config = self.get_config()
        
        if game not in config:
            return False
        
        if profile_id not in config[game]["profiles"]:
            return False
        
        profile = config[game]["profiles"][profile_id]
        
        try:
            with open(path, "w") as f:
                json.dump(profile, f, indent=4)
            return True
        except Exception as e:
            logger.error(f"Failed to export profile: {e}")
            return False
    
    def import_profile(self, path: str) -> bool:
        """Import a mod profile.
        
        Args:
            path: Path to import from
        
        Returns:
            True if successful, False otherwise
        """
        try:
            with open(path, "r") as f:
                profile = json.load(f)
        except Exception as e:
            logger.error(f"Failed to import profile: {e}")
            return False
        
        if "name" not in profile or "mods" not in profile:
            logger.error("Invalid profile format")
            return False
        
        # Extract game and profile ID from path
        path_parts = Path(path).stem.split("_")
        if len(path_parts) < 2:
            logger.error("Invalid profile filename")
            return False
        
        game = path_parts[0]
        profile_id = path_parts[1]
        
        return self.create_profile(game, profile_id, profile["name"]) 