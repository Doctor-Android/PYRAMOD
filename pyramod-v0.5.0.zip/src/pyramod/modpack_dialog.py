from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
                           QListWidget, QLabel, QLineEdit, QTextEdit,
                           QMessageBox, QListWidgetItem)
from PyQt6.QtCore import Qt
from typing import List, Dict

class ModpackDialog(QDialog):
    def __init__(self, mod_manager, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Create Modpack")
        self.setGeometry(300, 300, 600, 700)
        self.mod_manager = mod_manager
        self.modpack_manager = modpack_manager
        
        layout = QVBoxLayout()
        
        # Name and description
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("Name:"))
        self.name_input = QLineEdit()
        name_layout.addWidget(self.name_input)
        layout.addLayout(name_layout)
        
        layout.addWidget(QLabel("Description:"))
        self.description_input = QTextEdit()
        layout.addWidget(self.description_input)
        
        # Available mods
        layout.addWidget(QLabel("Available Mods:"))
        self.available_mods = QListWidget()
        self.load_available_mods()
        layout.addWidget(self.available_mods)
        
        # Add/Remove buttons
        button_layout = QHBoxLayout()
        
        add_btn = QPushButton("Add to Pack")
        add_btn.clicked.connect(self.add_to_pack)
        button_layout.addWidget(add_btn)
        
        remove_btn = QPushButton("Remove from Pack")
        remove_btn.clicked.connect(self.remove_from_pack)
        button_layout.addWidget(remove_btn)
        
        layout.addLayout(button_layout)
        
        # Selected mods
        layout.addWidget(QLabel("Mods in Pack:"))
        self.selected_mods = QListWidget()
        self.selected_mods.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        layout.addWidget(self.selected_mods)
        
        # Create button
        create_btn = QPushButton("Create Modpack")
        create_btn.clicked.connect(self.create_modpack)
        layout.addWidget(create_btn)
        
        self.setLayout(layout)
        
    def load_available_mods(self):
        """Load list of installed mods"""
        self.available_mods.clear()
        for mod_name in self.mod_manager.get_installed_mods():
            if not self.is_mod_in_pack(mod_name):
                self.available_mods.addItem(mod_name)
                
    def is_mod_in_pack(self, mod_name: str) -> bool:
        """Check if a mod is already in the pack"""
        for i in range(self.selected_mods.count()):
            if self.selected_mods.item(i).text() == mod_name:
                return True
        return False
        
    def add_to_pack(self):
        """Add selected mod to the pack"""
        selected = self.available_mods.selectedItems()
        if not selected:
            return
            
        for item in selected:
            mod_name = item.text()
            if not self.is_mod_in_pack(mod_name):
                self.selected_mods.addItem(mod_name)
                self.available_mods.takeItem(self.available_mods.row(item))
                
    def remove_from_pack(self):
        """Remove selected mod from the pack"""
        selected = self.selected_mods.selectedItems()
        if not selected:
            return
            
        for item in selected:
            mod_name = item.text()
            self.available_mods.addItem(mod_name)
            self.selected_mods.takeItem(self.selected_mods.row(item))
            
    def create_modpack(self):
        """Create the modpack with selected mods"""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Please enter a name for the modpack")
            return
            
        if self.selected_mods.count() == 0:
            QMessageBox.warning(self, "Error", "Please select at least one mod for the pack")
            return
            
        try:
            mods = [self.selected_mods.item(i).text() for i in range(self.selected_mods.count())]
            description = self.description_input.toPlainText().strip()
            
            self.modpack_manager.create_modpack(name, description, mods)
            QMessageBox.information(self, "Success", "Modpack created successfully!")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to create modpack: {str(e)}") 