from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QListWidget, QComboBox, QLineEdit, QTextEdit,
                           QMessageBox)
from PyQt6.QtCore import Qt

class ModpackMergeDialog(QDialog):
    def __init__(self, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Merge Modpacks")
        self.setGeometry(200, 200, 800, 600)
        
        self.modpack_manager = modpack_manager
        self.modpacks = modpack_manager.get_modpacks()
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Modpack selection
        selection_layout = QHBoxLayout()
        
        # First modpack
        first_layout = QVBoxLayout()
        first_layout.addWidget(QLabel("First Modpack:"))
        self.first_combo = QComboBox()
        self.first_combo.addItems(self.modpacks)
        self.first_combo.currentTextChanged.connect(self.update_preview)
        first_layout.addWidget(self.first_combo)
        selection_layout.addLayout(first_layout)
        
        # Second modpack
        second_layout = QVBoxLayout()
        second_layout.addWidget(QLabel("Second Modpack:"))
        self.second_combo = QComboBox()
        self.second_combo.addItems(self.modpacks)
        self.second_combo.currentTextChanged.connect(self.update_preview)
        second_layout.addWidget(self.second_combo)
        selection_layout.addLayout(second_layout)
        
        layout.addLayout(selection_layout)
        
        # New modpack details
        details_layout = QVBoxLayout()
        
        # Name
        name_layout = QHBoxLayout()
        name_layout.addWidget(QLabel("New Modpack Name:"))
        self.name_input = QLineEdit()
        name_layout.addWidget(self.name_input)
        details_layout.addLayout(name_layout)
        
        # Description
        desc_layout = QVBoxLayout()
        desc_layout.addWidget(QLabel("Description:"))
        self.desc_input = QTextEdit()
        self.desc_input.setMaximumHeight(100)
        desc_layout.addWidget(self.desc_input)
        details_layout.addLayout(desc_layout)
        
        layout.addLayout(details_layout)
        
        # Preview
        preview_layout = QVBoxLayout()
        preview_layout.addWidget(QLabel("Mods in New Pack:"))
        self.preview_list = QListWidget()
        preview_layout.addWidget(self.preview_list)
        layout.addLayout(preview_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        merge_btn = QPushButton("Merge Modpacks")
        cancel_btn = QPushButton("Cancel")
        merge_btn.clicked.connect(self.merge_modpacks)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(merge_btn)
        button_layout.addWidget(cancel_btn)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        
        # Initial preview
        self.update_preview()
        
    def update_preview(self):
        first_name = self.first_combo.currentText()
        second_name = self.second_combo.currentText()
        
        if not first_name or not second_name:
            return
            
        try:
            first_info = self.modpack_manager.get_modpack_info(first_name)
            second_info = self.modpack_manager.get_modpack_info(second_name)
            
            # Combine mods
            combined_mods = set(first_info["mods"] + second_info["mods"])
            
            # Update preview
            self.preview_list.clear()
            for mod in sorted(combined_mods):
                self.preview_list.addItem(mod)
                
            # Update name and description
            if not self.name_input.text():
                self.name_input.setText(f"{first_name} + {second_name}")
            if not self.desc_input.toPlainText():
                self.desc_input.setPlainText(
                    f"Merged from:\n{first_name}: {first_info['description']}\n"
                    f"{second_name}: {second_info['description']}"
                )
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to update preview: {str(e)}")
            
    def merge_modpacks(self):
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "Error", "Please enter a name for the new modpack")
            return
            
        if name in self.modpacks:
            QMessageBox.warning(self, "Error", "A modpack with this name already exists")
            return
            
        description = self.desc_input.toPlainText().strip()
        if not description:
            QMessageBox.warning(self, "Error", "Please enter a description for the new modpack")
            return
            
        try:
            # Get mods from both packs
            first_info = self.modpack_manager.get_modpack_info(self.first_combo.currentText())
            second_info = self.modpack_manager.get_modpack_info(self.second_combo.currentText())
            
            # Combine mods
            combined_mods = list(set(first_info["mods"] + second_info["mods"]))
            
            # Create new modpack
            self.modpack_manager.create_modpack(name, description, combined_mods)
            
            QMessageBox.information(self, "Success", "Modpacks merged successfully!")
            self.accept()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to merge modpacks: {str(e)}") 