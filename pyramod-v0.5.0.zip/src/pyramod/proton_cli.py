#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from proton_manager import ProtonManager

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the Proton manager CLI."""
    parser = argparse.ArgumentParser(
        description="Proton/Wine Prefix Manager CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "proton"),
        help="Directory to store configuration and prefix data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # List Proton installations command
    list_proton_parser = subparsers.add_parser("list-proton", help="List Proton installations")

    # Create prefix command
    create_parser = subparsers.add_parser("create", help="Create a new prefix")
    create_parser.add_argument("game_name", help="Name of the game")
    create_parser.add_argument("--proton-version", help="Version of Proton/Wine to use")

    # Delete prefix command
    delete_parser = subparsers.add_parser("delete", help="Delete a prefix")
    delete_parser.add_argument("game_name", help="Name of the game")

    # List prefixes command
    list_parser = subparsers.add_parser("list", help="List all prefixes")

    # Get prefix info command
    info_parser = subparsers.add_parser("info", help="Get prefix information")
    info_parser.add_argument("game_name", help="Name of the game")

    # Update settings command
    settings_parser = subparsers.add_parser("update-settings", help="Update prefix settings")
    settings_parser.add_argument("game_name", help="Name of the game")
    settings_parser.add_argument("--dxvk", type=bool, help="Enable/disable DXVK")
    settings_parser.add_argument("--vkd3d", type=bool, help="Enable/disable VKD3D")
    settings_parser.add_argument("--esync", type=bool, help="Enable/disable ESync")
    settings_parser.add_argument("--fsync", type=bool, help="Enable/disable FSync")
    settings_parser.add_argument("--gamemode", type=bool, help="Enable/disable GameMode")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("proton_cli")
    manager = ProtonManager(args.config_dir)

    try:
        if args.command == "list-proton":
            installations = manager.detect_proton_installations()
            print("\nDetected Proton/Wine Installations:")
            for source, versions in installations.items():
                print(f"\n{source.upper()}:")
                for version in versions:
                    print(f"  - {version}")

        elif args.command == "create":
            success = manager.create_prefix(args.game_name, args.proton_version)
            if success:
                logger.info(f"Created prefix for {args.game_name}")
            else:
                logger.error("Failed to create prefix")
                sys.exit(1)

        elif args.command == "delete":
            success = manager.delete_prefix(args.game_name)
            if success:
                logger.info(f"Deleted prefix for {args.game_name}")
            else:
                logger.error("Failed to delete prefix")
                sys.exit(1)

        elif args.command == "list":
            prefixes = manager.list_prefixes()
            if prefixes:
                print("\nInstalled Prefixes:")
                for game_name, info in prefixes:
                    print(f"\n{game_name}:")
                    print(f"  Proton Version: {info['proton_version']}")
                    print(f"  Path: {info['path']}")
                    print(f"  Created: {info['created_at']}")
                    print("\n  Settings:")
                    for setting, value in info['settings'].items():
                        print(f"    {setting}: {value}")
            else:
                print("No prefixes installed")

        elif args.command == "info":
            info = manager.get_prefix_info(args.game_name)
            if info:
                print(f"\nPrefix Information for {args.game_name}:")
                print(f"  Proton Version: {info['proton_version']}")
                print(f"  Path: {info['path']}")
                print(f"  Created: {info['created_at']}")
                print("\n  Settings:")
                for setting, value in info['settings'].items():
                    print(f"    {setting}: {value}")
            else:
                logger.error(f"No prefix found for {args.game_name}")
                sys.exit(1)

        elif args.command == "update-settings":
            settings = {}
            if args.dxvk is not None:
                settings["dxvk"] = args.dxvk
            if args.vkd3d is not None:
                settings["vkd3d"] = args.vkd3d
            if args.esync is not None:
                settings["esync"] = args.esync
            if args.fsync is not None:
                settings["fsync"] = args.fsync
            if args.gamemode is not None:
                settings["gamemode"] = args.gamemode

            if not settings:
                logger.error("No settings provided")
                sys.exit(1)

            success = manager.update_prefix_settings(args.game_name, settings)
            if success:
                logger.info(f"Updated settings for {args.game_name}")
            else:
                logger.error("Failed to update settings")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 