import os
import json
import hashlib
from typing import Dict, List, Set, Tuple
from error_handler import ConflictError, error_handler

class ConflictDetector:
    def __init__(self):
        self.conflict_types = {
            "file_conflict": "Files that are modified by multiple mods",
            "dependency_conflict": "Missing or incompatible dependencies",
            "load_order_conflict": "Load order issues",
            "version_conflict": "Incompatible mod versions"
        }

    def detect_conflicts(self, game_name: str, mods_dir: str) -> Dict[str, List[Dict]]:
        """Detect conflicts between installed mods"""
        try:
            conflicts = {
                "file_conflicts": [],
                "dependency_conflicts": [],
                "load_order_conflicts": [],
                "version_conflicts": []
            }

            # Get all mod files
            mod_files = self._get_mod_files(mods_dir)
            
            # Check for file conflicts
            file_conflicts = self._check_file_conflicts(mod_files)
            conflicts["file_conflicts"] = file_conflicts

            # Check for dependency conflicts
            dep_conflicts = self._check_dependency_conflicts(mods_dir)
            conflicts["dependency_conflicts"] = dep_conflicts

            # Check for load order conflicts
            load_conflicts = self._check_load_order_conflicts(game_name, mods_dir)
            conflicts["load_order_conflicts"] = load_conflicts

            # Check for version conflicts
            version_conflicts = self._check_version_conflicts(mods_dir)
            conflicts["version_conflicts"] = version_conflicts

            return conflicts

        except Exception as e:
            error_handler.handle_error(e, {
                "game": game_name,
                "mods_dir": mods_dir
            })
            raise ConflictError("Failed to detect conflicts")

    def _get_mod_files(self, mods_dir: str) -> Dict[str, Set[str]]:
        """Get all files from all mods"""
        mod_files = {}
        for mod in os.listdir(mods_dir):
            mod_path = os.path.join(mods_dir, mod)
            if os.path.isdir(mod_path):
                files = set()
                for root, _, filenames in os.walk(mod_path):
                    for filename in filenames:
                        file_path = os.path.join(root, filename)
                        rel_path = os.path.relpath(file_path, mod_path)
                        files.add(rel_path)
                mod_files[mod] = files
        return mod_files

    def _check_file_conflicts(self, mod_files: Dict[str, Set[str]]) -> List[Dict]:
        """Check for files that are modified by multiple mods"""
        conflicts = []
        all_files = set()
        for mod, files in mod_files.items():
            for file in files:
                if file in all_files:
                    # Find all mods that modify this file
                    conflicting_mods = [
                        m for m, f in mod_files.items()
                        if file in f
                    ]
                    conflicts.append({
                        "file": file,
                        "mods": conflicting_mods,
                        "type": "file_conflict"
                    })
                all_files.add(file)
        return conflicts

    def _check_dependency_conflicts(self, mods_dir: str) -> List[Dict]:
        """Check for missing or incompatible dependencies"""
        conflicts = []
        for mod in os.listdir(mods_dir):
            mod_path = os.path.join(mods_dir, mod)
            if os.path.isdir(mod_path):
                # Check for manifest file
                manifest_path = os.path.join(mod_path, "manifest.json")
                if os.path.exists(manifest_path):
                    try:
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                            if "dependencies" in manifest:
                                for dep in manifest["dependencies"]:
                                    dep_path = os.path.join(mods_dir, dep["name"])
                                    if not os.path.exists(dep_path):
                                        conflicts.append({
                                            "mod": mod,
                                            "missing_dependency": dep["name"],
                                            "type": "dependency_conflict"
                                        })
                    except Exception as e:
                        error_handler.log_warning(f"Error reading manifest for {mod}: {str(e)}")
        return conflicts

    def _check_load_order_conflicts(self, game_name: str, mods_dir: str) -> List[Dict]:
        """Check for load order conflicts"""
        conflicts = []
        # Implementation depends on game type
        if game_name in ["The Elder Scrolls V: Skyrim", "Fallout 4"]:
            # Check for ESP/ESM load order conflicts
            esp_files = []
            for mod in os.listdir(mods_dir):
                mod_path = os.path.join(mods_dir, mod)
                if os.path.isdir(mod_path):
                    for file in os.listdir(mod_path):
                        if file.endswith((".esp", ".esm")):
                            esp_files.append({
                                "mod": mod,
                                "file": file
                            })
            
            # Check for potential load order issues
            for i, esp1 in enumerate(esp_files):
                for esp2 in esp_files[i+1:]:
                    if self._check_esp_conflict(esp1["file"], esp2["file"]):
                        conflicts.append({
                            "mod1": esp1["mod"],
                            "mod2": esp2["mod"],
                            "file1": esp1["file"],
                            "file2": esp2["file"],
                            "type": "load_order_conflict"
                        })
        return conflicts

    def _check_version_conflicts(self, mods_dir: str) -> List[Dict]:
        """Check for incompatible mod versions"""
        conflicts = []
        for mod in os.listdir(mods_dir):
            mod_path = os.path.join(mods_dir, mod)
            if os.path.isdir(mod_path):
                manifest_path = os.path.join(mod_path, "manifest.json")
                if os.path.exists(manifest_path):
                    try:
                        with open(manifest_path, "r") as f:
                            manifest = json.load(f)
                            if "compatible_versions" in manifest:
                                game_version = self._get_game_version(mod_path)
                                if game_version not in manifest["compatible_versions"]:
                                    conflicts.append({
                                        "mod": mod,
                                        "version": manifest.get("version", "unknown"),
                                        "game_version": game_version,
                                        "type": "version_conflict"
                                    })
                    except Exception as e:
                        error_handler.log_warning(f"Error checking version for {mod}: {str(e)}")
        return conflicts

    def _check_esp_conflict(self, esp1: str, esp2: str) -> bool:
        """Check if two ESP files might conflict"""
        # This is a simplified check. A real implementation would need to
        # analyze the ESP files' content to detect actual conflicts
        return esp1.lower() == esp2.lower()

    def _get_game_version(self, mod_path: str) -> str:
        """Get the game version for a mod"""
        # This would need to be implemented based on the game
        return "1.0.0"

# Create a global conflict detector instance
conflict_detector = ConflictDetector() 