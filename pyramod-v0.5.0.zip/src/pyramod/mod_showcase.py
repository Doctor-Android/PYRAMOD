#!/usr/bin/env python3
import os
import json
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import hashlib
from PIL import Image
import mimetypes

class ModShowcase:
    """Manages mod showcases with media support."""
    
    def __init__(self, config_dir: str):
        """Initialize the mod showcase system.
        
        Args:
            config_dir: Directory to store showcase data
        """
        self.config_dir = Path(config_dir)
        self.showcases_dir = self.config_dir / "showcases"
        self.media_dir = self.config_dir / "media"
        
        # Create necessary directories
        self.showcases_dir.mkdir(parents=True, exist_ok=True)
        self.media_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        self.logger = logging.getLogger("mod_showcase")
        
        # Load existing showcases
        self._load_showcases()
    
    def _load_showcases(self):
        """Load existing showcases from JSON file."""
        self.showcases_file = self.showcases_dir / "showcases.json"
        if self.showcases_file.exists():
            with open(self.showcases_file, "r") as f:
                self.showcases = json.load(f)
        else:
            self.showcases = {}
            self._save_showcases()
    
    def _save_showcases(self):
        """Save showcases to JSON file."""
        with open(self.showcases_file, "w") as f:
            json.dump(self.showcases, f, indent=4)
    
    def create_showcase(
        self,
        mod_id: str,
        title: str,
        description: str,
        author_id: str,
        media_files: List[str],
        tags: List[str] = None,
        featured: bool = False
    ) -> str:
        """Create a new mod showcase.
        
        Args:
            mod_id: ID of the mod being showcased
            title: Showcase title
            description: Showcase description
            author_id: ID of the showcase author
            media_files: List of paths to media files (images/videos)
            tags: List of tags for the showcase
            featured: Whether this is a featured showcase
            
        Returns:
            ID of the created showcase
        """
        showcase_id = f"showcase_{len(self.showcases) + 1}"
        
        # Process and store media files
        media_paths = []
        for media_file in media_files:
            if not os.path.exists(media_file):
                self.logger.warning(f"Media file not found: {media_file}")
                continue
                
            # Determine file type
            mime_type, _ = mimetypes.guess_type(media_file)
            if not mime_type:
                self.logger.warning(f"Could not determine type of media file: {media_file}")
                continue
                
            # Create media directory for this showcase
            media_dir = self.media_dir / showcase_id
            media_dir.mkdir(exist_ok=True)
            
            # Copy and process media file
            filename = os.path.basename(media_file)
            dest_path = media_dir / filename
            
            if mime_type.startswith("image/"):
                # Process image
                with Image.open(media_file) as img:
                    # Resize if too large
                    if max(img.size) > 1920:
                        img.thumbnail((1920, 1920))
                    img.save(dest_path, optimize=True)
            else:
                # Copy other media files as is
                shutil.copy2(media_file, dest_path)
            
            media_paths.append(str(dest_path))
        
        # Create showcase entry
        showcase = {
            "id": showcase_id,
            "mod_id": mod_id,
            "title": title,
            "description": description,
            "author_id": author_id,
            "media_files": media_paths,
            "tags": tags or [],
            "featured": featured,
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat(),
            "views": 0,
            "likes": 0,
            "comments": []
        }
        
        self.showcases[showcase_id] = showcase
        self._save_showcases()
        
        return showcase_id
    
    def get_showcase(self, showcase_id: str) -> Optional[Dict]:
        """Get showcase information.
        
        Args:
            showcase_id: ID of the showcase
            
        Returns:
            Showcase information or None if not found
        """
        return self.showcases.get(showcase_id)
    
    def update_showcase(
        self,
        showcase_id: str,
        title: str = None,
        description: str = None,
        media_files: List[str] = None,
        tags: List[str] = None,
        featured: bool = None
    ) -> bool:
        """Update a showcase.
        
        Args:
            showcase_id: ID of the showcase to update
            title: New title
            description: New description
            media_files: New list of media files
            tags: New list of tags
            featured: New featured status
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        showcase = self.showcases[showcase_id]
        
        if title is not None:
            showcase["title"] = title
        if description is not None:
            showcase["description"] = description
        if tags is not None:
            showcase["tags"] = tags
        if featured is not None:
            showcase["featured"] = featured
        
        if media_files is not None:
            # Process new media files
            media_paths = []
            for media_file in media_files:
                if not os.path.exists(media_file):
                    continue
                    
                mime_type, _ = mimetypes.guess_type(media_file)
                if not mime_type:
                    continue
                    
                media_dir = self.media_dir / showcase_id
                media_dir.mkdir(exist_ok=True)
                
                filename = os.path.basename(media_file)
                dest_path = media_dir / filename
                
                if mime_type.startswith("image/"):
                    with Image.open(media_file) as img:
                        if max(img.size) > 1920:
                            img.thumbnail((1920, 1920))
                        img.save(dest_path, optimize=True)
                else:
                    shutil.copy2(media_file, dest_path)
                
                media_paths.append(str(dest_path))
            
            showcase["media_files"] = media_paths
        
        showcase["updated_at"] = datetime.now().isoformat()
        self._save_showcases()
        
        return True
    
    def delete_showcase(self, showcase_id: str) -> bool:
        """Delete a showcase.
        
        Args:
            showcase_id: ID of the showcase to delete
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        # Delete media files
        media_dir = self.media_dir / showcase_id
        if media_dir.exists():
            shutil.rmtree(media_dir)
        
        # Remove showcase entry
        del self.showcases[showcase_id]
        self._save_showcases()
        
        return True
    
    def list_showcases(
        self,
        mod_id: str = None,
        author_id: str = None,
        tags: List[str] = None,
        featured: bool = None,
        limit: int = 50,
        offset: int = 0
    ) -> List[Dict]:
        """List showcases with optional filtering.
        
        Args:
            mod_id: Filter by mod ID
            author_id: Filter by author ID
            tags: Filter by tags
            featured: Filter by featured status
            limit: Maximum number of results
            offset: Number of results to skip
            
        Returns:
            List of matching showcases
        """
        showcases = list(self.showcases.values())
        
        # Apply filters
        if mod_id:
            showcases = [s for s in showcases if s["mod_id"] == mod_id]
        if author_id:
            showcases = [s for s in showcases if s["author_id"] == author_id]
        if tags:
            showcases = [s for s in showcases if all(tag in s["tags"] for tag in tags)]
        if featured is not None:
            showcases = [s for s in showcases if s["featured"] == featured]
        
        # Sort by creation date (newest first)
        showcases.sort(key=lambda x: x["created_at"], reverse=True)
        
        # Apply pagination
        return showcases[offset:offset + limit]
    
    def add_comment(
        self,
        showcase_id: str,
        author_id: str,
        content: str
    ) -> bool:
        """Add a comment to a showcase.
        
        Args:
            showcase_id: ID of the showcase
            author_id: ID of the comment author
            content: Comment content
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        comment = {
            "id": f"comment_{len(self.showcases[showcase_id]['comments']) + 1}",
            "author_id": author_id,
            "content": content,
            "created_at": datetime.now().isoformat()
        }
        
        self.showcases[showcase_id]["comments"].append(comment)
        self._save_showcases()
        
        return True
    
    def delete_comment(
        self,
        showcase_id: str,
        comment_id: str
    ) -> bool:
        """Delete a comment from a showcase.
        
        Args:
            showcase_id: ID of the showcase
            comment_id: ID of the comment to delete
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        showcase = self.showcases[showcase_id]
        showcase["comments"] = [
            c for c in showcase["comments"]
            if c["id"] != comment_id
        ]
        
        self._save_showcases()
        return True
    
    def increment_views(self, showcase_id: str) -> bool:
        """Increment the view count for a showcase.
        
        Args:
            showcase_id: ID of the showcase
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        self.showcases[showcase_id]["views"] += 1
        self._save_showcases()
        return True
    
    def toggle_like(self, showcase_id: str) -> bool:
        """Toggle the like status for a showcase.
        
        Args:
            showcase_id: ID of the showcase
            
        Returns:
            True if successful, False otherwise
        """
        if showcase_id not in self.showcases:
            return False
        
        self.showcases[showcase_id]["likes"] += 1
        self._save_showcases()
        return True

# Example usage
if __name__ == "__main__":
    # Initialize showcase system
    showcase = ModShowcase("~/.config/pyramod/showcase")
    
    # Create a showcase
    showcase_id = showcase.create_showcase(
        mod_id="mod_123",
        title="Amazing Graphics Overhaul",
        description="A complete graphics overhaul for your game",
        author_id="author_456",
        media_files=["screenshot1.jpg", "screenshot2.jpg"],
        tags=["graphics", "overhaul", "textures"],
        featured=True
    )
    
    # Add a comment
    showcase.add_comment(
        showcase_id,
        author_id="user_789",
        content="This looks amazing! Great work!"
    )
    
    # List featured showcases
    featured = showcase.list_showcases(featured=True)
    for s in featured:
        print(f"Featured: {s['title']}") 