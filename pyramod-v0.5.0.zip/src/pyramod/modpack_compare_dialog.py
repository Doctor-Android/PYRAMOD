from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel,
                           QListWidget, QComboBox, QMessageBox)
from PyQt6.QtCore import Qt

class ModpackCompareDialog(QDialog):
    def __init__(self, modpack_manager, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Compare Modpacks")
        self.setGeometry(200, 200, 800, 600)
        
        self.modpack_manager = modpack_manager
        self.modpacks = modpack_manager.get_modpacks()
        
        self.setup_ui()
        
    def setup_ui(self):
        layout = QVBoxLayout()
        
        # Modpack selection
        selection_layout = QHBoxLayout()
        
        # First modpack
        first_layout = QVBoxLayout()
        first_layout.addWidget(QLabel("First Modpack:"))
        self.first_combo = QComboBox()
        self.first_combo.addItems(self.modpacks)
        self.first_combo.currentTextChanged.connect(self.update_comparison)
        first_layout.addWidget(self.first_combo)
        selection_layout.addLayout(first_layout)
        
        # Second modpack
        second_layout = QVBoxLayout()
        second_layout.addWidget(QLabel("Second Modpack:"))
        self.second_combo = QComboBox()
        self.second_combo.addItems(self.modpacks)
        self.second_combo.currentTextChanged.connect(self.update_comparison)
        second_layout.addWidget(self.second_combo)
        selection_layout.addLayout(second_layout)
        
        layout.addLayout(selection_layout)
        
        # Comparison results
        results_layout = QHBoxLayout()
        
        # Common mods
        common_layout = QVBoxLayout()
        common_layout.addWidget(QLabel("Common Mods:"))
        self.common_list = QListWidget()
        common_layout.addWidget(self.common_list)
        results_layout.addLayout(common_layout)
        
        # Unique to first
        first_unique_layout = QVBoxLayout()
        first_unique_layout.addWidget(QLabel("Unique to First:"))
        self.first_unique_list = QListWidget()
        first_unique_layout.addWidget(self.first_unique_list)
        results_layout.addLayout(first_unique_layout)
        
        # Unique to second
        second_unique_layout = QVBoxLayout()
        second_unique_layout.addWidget(QLabel("Unique to Second:"))
        self.second_unique_list = QListWidget()
        second_unique_layout.addWidget(self.second_unique_list)
        results_layout.addLayout(second_unique_layout)
        
        layout.addLayout(results_layout)
        
        self.setLayout(layout)
        
        # Initial comparison
        self.update_comparison()
        
    def update_comparison(self):
        first_name = self.first_combo.currentText()
        second_name = self.second_combo.currentText()
        
        if not first_name or not second_name:
            return
            
        try:
            first_info = self.modpack_manager.get_modpack_info(first_name)
            second_info = self.modpack_manager.get_modpack_info(second_name)
            
            first_mods = set(first_info["mods"])
            second_mods = set(second_info["mods"])
            
            # Clear lists
            self.common_list.clear()
            self.first_unique_list.clear()
            self.second_unique_list.clear()
            
            # Update lists
            for mod in sorted(first_mods & second_mods):
                self.common_list.addItem(mod)
                
            for mod in sorted(first_mods - second_mods):
                self.first_unique_list.addItem(mod)
                
            for mod in sorted(second_mods - first_mods):
                self.second_unique_list.addItem(mod)
                
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Failed to compare modpacks: {str(e)}") 