import json
from pathlib import Path
from typing import Dict, List, Optional, Set
import logging
from dataclasses import dataclass
import requests
from datetime import datetime
import hashlib
import os
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed

@dataclass
class ModVersion:
    version: str
    release_date: datetime
    download_url: str
    changelog: str
    file_hash: str

class ModUpdateManager:
    def __init__(self, base_path: Path):
        self.base_path = base_path
        self.updates_path = base_path / "updates"
        self.updates_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize logging
        logging.basicConfig(
            filename=self.base_path / "update_manager.log",
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Cache for mod versions
        self.version_cache: Dict[str, List[ModVersion]] = {}
        
    def check_for_updates(self, mod_id: str, current_version: str) -> Optional[ModVersion]:
        """Check if a newer version of the mod is available"""
        try:
            # Get version history
            versions = self.get_mod_versions(mod_id)
            if not versions:
                return None
                
            # Find latest version
            latest = versions[0]
            if latest.version > current_version:
                return latest
            return None
            
        except Exception as e:
            logging.error(f"Failed to check for updates: {e}")
            return None
            
    def get_mod_versions(self, mod_id: str) -> List[ModVersion]:
        """Get all available versions for a mod"""
        try:
            # Check cache first
            if mod_id in self.version_cache:
                return self.version_cache[mod_id]
                
            # Load from file
            version_file = self.updates_path / f"{mod_id}_versions.json"
            if version_file.exists():
                with open(version_file, 'r') as f:
                    versions_data = json.load(f)
                    versions = []
                    for v in versions_data:
                        versions.append(ModVersion(
                            version=v['version'],
                            release_date=datetime.fromisoformat(v['release_date']),
                            download_url=v['download_url'],
                            changelog=v['changelog'],
                            file_hash=v['file_hash']
                        ))
                    self.version_cache[mod_id] = versions
                    return versions
                    
            return []
            
        except Exception as e:
            logging.error(f"Failed to get mod versions: {e}")
            return []
            
    def download_update(self, mod_id: str, version: ModVersion, target_path: Path) -> bool:
        """Download a mod update"""
        try:
            # Create temporary directory
            temp_dir = self.updates_path / "temp" / mod_id
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            # Download file
            response = requests.get(version.download_url, stream=True)
            response.raise_for_status()
            
            temp_file = temp_dir / f"{mod_id}_{version.version}.zip"
            with open(temp_file, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    
            # Verify hash
            if not self.verify_file_hash(temp_file, version.file_hash):
                logging.error(f"File hash verification failed for {mod_id}")
                return False
                
            # Move to target
            shutil.move(temp_file, target_path)
            
            # Cleanup
            shutil.rmtree(temp_dir)
            
            logging.info(f"Successfully downloaded update for {mod_id}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to download update: {e}")
            return False
            
    def verify_file_hash(self, file_path: Path, expected_hash: str) -> bool:
        """Verify file hash matches expected value"""
        try:
            sha256_hash = hashlib.sha256()
            with open(file_path, "rb") as f:
                for byte_block in iter(lambda: f.read(4096), b""):
                    sha256_hash.update(byte_block)
            return sha256_hash.hexdigest() == expected_hash
        except Exception as e:
            logging.error(f"Failed to verify file hash: {e}")
            return False
            
    def check_all_updates(self, mods: Dict[str, str]) -> Dict[str, ModVersion]:
        """Check for updates for multiple mods in parallel"""
        updates = {}
        
        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_mod = {
                executor.submit(self.check_for_updates, mod_id, version): mod_id
                for mod_id, version in mods.items()
            }
            
            for future in as_completed(future_to_mod):
                mod_id = future_to_mod[future]
                try:
                    update = future.result()
                    if update:
                        updates[mod_id] = update
                except Exception as e:
                    logging.error(f"Failed to check update for {mod_id}: {e}")
                    
        return updates
        
    def backup_mod(self, mod_id: str, mod_path: Path) -> bool:
        """Create a backup of a mod before updating"""
        try:
            backup_dir = self.updates_path / "backups" / mod_id
            backup_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_path = backup_dir / f"{mod_id}_{timestamp}"
            
            if mod_path.is_file():
                shutil.copy2(mod_path, backup_path)
            else:
                shutil.copytree(mod_path, backup_path)
                
            logging.info(f"Created backup for {mod_id}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to create backup: {e}")
            return False
            
    def restore_backup(self, mod_id: str, mod_path: Path) -> bool:
        """Restore a mod from backup"""
        try:
            backup_dir = self.updates_path / "backups" / mod_id
            if not backup_dir.exists():
                return False
                
            # Get latest backup
            backups = sorted(backup_dir.glob("*"), key=os.path.getmtime, reverse=True)
            if not backups:
                return False
                
            latest_backup = backups[0]
            
            # Remove current mod
            if mod_path.exists():
                if mod_path.is_file():
                    mod_path.unlink()
                else:
                    shutil.rmtree(mod_path)
                    
            # Restore from backup
            if latest_backup.is_file():
                shutil.copy2(latest_backup, mod_path)
            else:
                shutil.copytree(latest_backup, mod_path)
                
            logging.info(f"Restored backup for {mod_id}")
            return True
            
        except Exception as e:
            logging.error(f"Failed to restore backup: {e}")
            return False
            
    def cleanup_old_backups(self, mod_id: str, keep_count: int = 3) -> bool:
        """Remove old backups, keeping only the specified number"""
        try:
            backup_dir = self.updates_path / "backups" / mod_id
            if not backup_dir.exists():
                return True
                
            backups = sorted(backup_dir.glob("*"), key=os.path.getmtime, reverse=True)
            for backup in backups[keep_count:]:
                if backup.is_file():
                    backup.unlink()
                else:
                    shutil.rmtree(backup)
                    
            return True
            
        except Exception as e:
            logging.error(f"Failed to cleanup backups: {e}")
            return False 