import requests
import json
from typing import List, Dict, Optional, Generator, Any, Tuple
import os
from pathlib import Path
from tqdm import tqdm
import time
from datetime import datetime, timedelta
import logging
import hashlib
import pickle
from threading import Lock

class NexusAPI:
    """Nexus Mods API integration for Pyramod."""
    
    BASE_URL = "https://api.nexusmods.com/v1"
    RATE_LIMIT_WINDOW = 60  # 1 minute window
    MAX_REQUESTS_PER_WINDOW = 100  # Nexus API limit
    MAX_RETRIES = 3  # Maximum number of retry attempts
    RETRY_DELAY = 2  # Delay between retries in seconds
    CHUNK_SIZE = 8192  # Size of download chunks
    SEARCH_PAGE_SIZE = 100  # Number of mods per page
    
    # Cache settings
    CACHE_DIR = Path.home() / ".pyramod" / "cache"
    DEFAULT_CACHE_DURATION = 3600  # 1 hour in seconds
    CACHE_LOCK = Lock()
    
    def __init__(self, api_key: str = None, cache_duration: int = DEFAULT_CACHE_DURATION):
        """Initialize the Nexus API client.
        
        Args:
            api_key: Your Nexus Mods API key. If not provided, will try to load from config.
        """
        self.api_key = api_key or self._load_api_key()
        self.session = requests.Session()
        self.session.headers.update({
            'apikey': self.api_key,
            'User-Agent': 'Pyramod/1.0.0',
            'Content-Type': 'application/json'
        })
        self.request_timestamps = []
        self.logger = logging.getLogger('NexusAPI')
        self.cache_duration = cache_duration
        
        # Initialize cache directory
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
        
    def _load_api_key(self) -> str:
        """Load API key from config file."""
        config_path = os.path.expanduser('~/.config/pyramod/nexus_api.json')
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
                return config.get('api_key', '')
        except (FileNotFoundError, json.JSONDecodeError):
            return ''
            
    def save_api_key(self, api_key: str):
        """Save API key to config file."""
        config_path = os.path.expanduser('~/.config/pyramod/nexus_api.json')
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        with open(config_path, 'w') as f:
            json.dump({'api_key': api_key}, f)
        self.api_key = api_key
        self.session.headers.update({'apikey': api_key})
        
    def validate_api_key(self) -> bool:
        """Validate the current API key."""
        try:
            response = self.session.get(f"{self.BASE_URL}/users/validate")
            return response.status_code == 200
        except requests.RequestException:
            return False
            
    def get_user_info(self) -> Dict:
        """Get information about the current user."""
        response = self.session.get(f"{self.BASE_URL}/users/current")
        response.raise_for_status()
        return response.json()
        
    def get_game_info(self, game_domain: str) -> Dict:
        """Get information about a specific game.
        
        Args:
            game_domain: The game's domain name on Nexus Mods (e.g., 'skyrim')
        """
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}")
        response.raise_for_status()
        return response.json()
        
    def search_mods(self, 
                   game_domain: str,
                   query: str = None,
                   category: str = None,
                   author: str = None,
                   status: str = None,
                   sort: str = None,
                   page: int = 1,
                   per_page: int = 20) -> Dict:
        """Search for mods.
        
        Args:
            game_domain: The game's domain name
            query: Search query
            category: Category ID
            author: Author name
            status: Mod status (published, hidden, etc.)
            sort: Sort order (latest, trending, etc.)
            page: Page number
            per_page: Results per page
        """
        params = {
            'query': query,
            'category': category,
            'author': author,
            'status': status,
            'sort': sort,
            'page': page,
            'per_page': per_page
        }
        params = {k: v for k, v in params.items() if v is not None}
        
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods", params=params)
        response.raise_for_status()
        return response.json()
        
    def get_mod_info(self, game_domain: str, mod_id: int) -> Dict:
        """Get detailed information about a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}")
        response.raise_for_status()
        return response.json()
        
    def get_mod_files(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get all files for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/files")
        response.raise_for_status()
        return response.json()
        
    def get_file_info(self, game_domain: str, mod_id: int, file_id: int) -> Dict:
        """Get information about a specific file."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/files/{file_id}")
        response.raise_for_status()
        return response.json()
        
    def get_download_url(self, game_domain: str, mod_id: int, file_id: int) -> str:
        """Get the download URL for a specific file."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/files/{file_id}/download_link"
        )
        response.raise_for_status()
        return response.json()['uri']
        
    def get_mod_endorsements(self, game_domain: str, mod_id: int) -> Dict:
        """Get endorsement information for a mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/endorsements")
        response.raise_for_status()
        return response.json()
        
    def endorse_mod(self, game_domain: str, mod_id: int) -> bool:
        """Endorse a mod."""
        response = self.session.post(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/endorse")
        return response.status_code == 200
        
    def get_tracked_mods(self) -> List[Dict]:
        """Get list of tracked mods."""
        response = self.session.get(f"{self.BASE_URL}/user/tracked_mods")
        response.raise_for_status()
        return response.json()
        
    def track_mod(self, game_domain: str, mod_id: int) -> bool:
        """Track a mod."""
        response = self.session.post(f"{self.BASE_URL}/user/tracked_mods", json={
            'domain_name': game_domain,
            'mod_id': mod_id
        })
        return response.status_code == 200
        
    def untrack_mod(self, game_domain: str, mod_id: int) -> bool:
        """Untrack a mod."""
        response = self.session.delete(f"{self.BASE_URL}/user/tracked_mods", json={
            'domain_name': game_domain,
            'mod_id': mod_id
        })
        return response.status_code == 200
        
    def get_collections(self, game_domain: str = None) -> List[Dict]:
        """Get collections for a game or all games."""
        url = f"{self.BASE_URL}/collections"
        if game_domain:
            url += f"/{game_domain}"
        response = self.session.get(url)
        response.raise_for_status()
        return response.json()
        
    def get_collection(self, collection_id: int) -> Dict:
        """Get details of a specific collection."""
        response = self.session.get(f"{self.BASE_URL}/collections/{collection_id}")
        response.raise_for_status()
        return response.json()
        
    def create_collection(self, 
                         game_domain: str,
                         name: str,
                         description: str,
                         mod_ids: List[int] = None) -> Dict:
        """Create a new collection."""
        data = {
            'domain_name': game_domain,
            'name': name,
            'description': description,
            'mod_ids': mod_ids or []
        }
        response = self.session.post(f"{self.BASE_URL}/collections", json=data)
        response.raise_for_status()
        return response.json()
        
    def update_collection(self,
                         collection_id: int,
                         name: str = None,
                         description: str = None,
                         mod_ids: List[int] = None) -> Dict:
        """Update an existing collection."""
        data = {}
        if name is not None:
            data['name'] = name
        if description is not None:
            data['description'] = description
        if mod_ids is not None:
            data['mod_ids'] = mod_ids
            
        response = self.session.patch(f"{self.BASE_URL}/collections/{collection_id}", json=data)
        response.raise_for_status()
        return response.json()
        
    def delete_collection(self, collection_id: int) -> bool:
        """Delete a collection."""
        response = self.session.delete(f"{self.BASE_URL}/collections/{collection_id}")
        return response.status_code == 200
        
    def get_mod_updates(self, game_domain: str, mod_ids: List[int]) -> List[Dict]:
        """Check for updates to tracked mods."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/updates",
            json={'mod_ids': mod_ids}
        )
        response.raise_for_status()
        return response.json()
        
    def get_download_history(self, page: int = 1, per_page: int = 20) -> Dict:
        """Get user's download history."""
        params = {
            'page': page,
            'per_page': per_page
        }
        response = self.session.get(f"{self.BASE_URL}/user/downloads", params=params)
        response.raise_for_status()
        return response.json()
        
    def get_game_categories(self, game_domain: str) -> List[Dict]:
        """Get categories for a specific game."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/categories")
        response.raise_for_status()
        return response.json()
        
    def get_game_requirements(self, game_domain: str) -> List[Dict]:
        """Get requirements for a specific game."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/requirements")
        response.raise_for_status()
        return response.json()
        
    def get_game_versions(self, game_domain: str) -> List[Dict]:
        """Get supported versions for a specific game."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/versions")
        response.raise_for_status()
        return response.json()
        
    def get_game_engines(self, game_domain: str) -> List[Dict]:
        """Get supported engines for a specific game."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/engines")
        response.raise_for_status()
        return response.json()
        
    def get_game_tags(self, game_domain: str) -> List[Dict]:
        """Get available tags for a specific game."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/tags")
        response.raise_for_status()
        return response.json()
        
    def get_mod_comments(self, game_domain: str, mod_id: int, page: int = 1) -> Dict:
        """Get comments for a specific mod."""
        params = {'page': page}
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/comments",
            params=params
        )
        response.raise_for_status()
        return response.json()
        
    def add_mod_comment(self, game_domain: str, mod_id: int, content: str) -> Dict:
        """Add a comment to a mod."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/comments",
            json={'content': content}
        )
        response.raise_for_status()
        return response.json()
        
    def get_mod_articles(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get articles (posts) for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/articles")
        response.raise_for_status()
        return response.json()
        
    def get_mod_images(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get images for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/images")
        response.raise_for_status()
        return response.json()
        
    def get_mod_videos(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get videos for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/videos")
        response.raise_for_status()
        return response.json()
        
    def get_mod_requirements(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get requirements for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/requirements")
        response.raise_for_status()
        return response.json()
        
    def get_mod_dependencies(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get dependencies for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/dependencies")
        response.raise_for_status()
        return response.json()
        
    def get_mod_conflicts(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get conflicts for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/conflicts")
        response.raise_for_status()
        return response.json()
        
    def get_mod_versions(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get version history for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/versions")
        response.raise_for_status()
        return response.json()
        
    def get_mod_changelog(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get changelog for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/changelog")
        response.raise_for_status()
        return response.json()
        
    def get_mod_stats(self, game_domain: str, mod_id: int) -> Dict:
        """Get statistics for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/stats")
        response.raise_for_status()
        return response.json()
        
    def get_mod_ratings(self, game_domain: str, mod_id: int) -> Dict:
        """Get ratings for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/ratings")
        response.raise_for_status()
        return response.json()
        
    def rate_mod(self, game_domain: str, mod_id: int, rating: int) -> bool:
        """Rate a mod (1-5 stars)."""
        if not 1 <= rating <= 5:
            raise ValueError("Rating must be between 1 and 5")
            
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/rate",
            json={'rating': rating}
        )
        return response.status_code == 200
        
    def get_mod_reports(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get reports for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/reports")
        response.raise_for_status()
        return response.json()
        
    def report_mod(self, game_domain: str, mod_id: int, reason: str) -> bool:
        """Report a mod."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/report",
            json={'reason': reason}
        )
        return response.status_code == 200
        
    def get_mod_permissions(self, game_domain: str, mod_id: int) -> Dict:
        """Get permissions for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/permissions")
        response.raise_for_status()
        return response.json()
        
    def update_mod_permissions(self, game_domain: str, mod_id: int, permissions: Dict) -> Dict:
        """Update permissions for a specific mod."""
        response = self.session.patch(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/permissions",
            json=permissions
        )
        response.raise_for_status()
        return response.json()
        
    def get_mod_team(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get team members for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/team")
        response.raise_for_status()
        return response.json()
        
    def add_team_member(self, game_domain: str, mod_id: int, username: str, role: str) -> Dict:
        """Add a team member to a mod."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/team",
            json={'username': username, 'role': role}
        )
        response.raise_for_status()
        return response.json()
        
    def remove_team_member(self, game_domain: str, mod_id: int, username: str) -> bool:
        """Remove a team member from a mod."""
        response = self.session.delete(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/team/{username}"
        )
        return response.status_code == 200
        
    def get_mod_issues(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get issues for a specific mod."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues")
        response.raise_for_status()
        return response.json()
        
    def create_mod_issue(self, game_domain: str, mod_id: int, title: str, description: str) -> Dict:
        """Create an issue for a mod."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues",
            json={'title': title, 'description': description}
        )
        response.raise_for_status()
        return response.json()
        
    def get_mod_issue(self, game_domain: str, mod_id: int, issue_id: int) -> Dict:
        """Get details of a specific issue."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}"
        )
        response.raise_for_status()
        return response.json()
        
    def update_mod_issue(self, 
                        game_domain: str,
                        mod_id: int,
                        issue_id: int,
                        status: str = None,
                        title: str = None,
                        description: str = None) -> Dict:
        """Update an issue."""
        data = {}
        if status is not None:
            data['status'] = status
        if title is not None:
            data['title'] = title
        if description is not None:
            data['description'] = description
            
        response = self.session.patch(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}",
            json=data
        )
        response.raise_for_status()
        return response.json()
        
    def close_mod_issue(self, game_domain: str, mod_id: int, issue_id: int) -> bool:
        """Close an issue."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/close"
        )
        return response.status_code == 200
        
    def reopen_mod_issue(self, game_domain: str, mod_id: int, issue_id: int) -> bool:
        """Reopen an issue."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/reopen"
        )
        return response.status_code == 200
        
    def get_mod_issue_comments(self, game_domain: str, mod_id: int, issue_id: int) -> List[Dict]:
        """Get comments for a specific issue."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/comments"
        )
        response.raise_for_status()
        return response.json()
        
    def add_mod_issue_comment(self, 
                            game_domain: str,
                            mod_id: int,
                            issue_id: int,
                            content: str) -> Dict:
        """Add a comment to an issue."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/comments",
            json={'content': content}
        )
        response.raise_for_status()
        return response.json()
        
    def get_mod_issue_attachments(self, game_domain: str, mod_id: int, issue_id: int) -> List[Dict]:
        """Get attachments for a specific issue."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/attachments"
        )
        response.raise_for_status()
        return response.json()
        
    def add_mod_issue_attachment(self,
                                game_domain: str,
                                mod_id: int,
                                issue_id: int,
                                file_path: str) -> Dict:
        """Add an attachment to an issue."""
        with open(file_path, 'rb') as f:
            files = {'file': f}
            response = self.session.post(
                f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/attachments",
                files=files
            )
        response.raise_for_status()
        return response.json()
        
    def get_mod_issue_history(self, game_domain: str, mod_id: int, issue_id: int) -> List[Dict]:
        """Get history for a specific issue."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/history"
        )
        response.raise_for_status()
        return response.json()
        
    def get_mod_issue_labels(self, game_domain: str, mod_id: int) -> List[Dict]:
        """Get available labels for issues."""
        response = self.session.get(f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issue_labels")
        response.raise_for_status()
        return response.json()
        
    def add_mod_issue_label(self,
                          game_domain: str,
                          mod_id: int,
                          issue_id: int,
                          label: str) -> Dict:
        """Add a label to an issue."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/labels",
            json={'label': label}
        )
        response.raise_for_status()
        return response.json()
        
    def remove_mod_issue_label(self,
                             game_domain: str,
                             mod_id: int,
                             issue_id: int,
                             label: str) -> bool:
        """Remove a label from an issue."""
        response = self.session.delete(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/labels/{label}"
        )
        return response.status_code == 200
        
    def get_mod_issue_assignees(self, game_domain: str, mod_id: int, issue_id: int) -> List[Dict]:
        """Get assignees for a specific issue."""
        response = self.session.get(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/assignees"
        )
        response.raise_for_status()
        return response.json()
        
    def add_mod_issue_assignee(self,
                              game_domain: str,
                              mod_id: int,
                              issue_id: int,
                              username: str) -> Dict:
        """Add an assignee to an issue."""
        response = self.session.post(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/assignees",
            json={'username': username}
        )
        response.raise_for_status()
        return response.json()
        
    def remove_mod_issue_assignee(self,
                                game_domain: str,
                                mod_id: int,
                                issue_id: int,
                                username: str) -> bool:
        """Remove an assignee from an issue."""
        response = self.session.delete(
            f"{self.BASE_URL}/games/{game_domain}/mods/{mod_id}/issues/{issue_id}/assignees/{username}"
        )
        return response.status_code == 200

    def _get_cache_key(self, endpoint: str, params: Dict[str, Any] = None) -> str:
        """Generate a unique cache key for the request"""
        key_parts = [endpoint]
        if params:
            # Sort params to ensure consistent keys
            sorted_params = sorted(params.items())
            key_parts.extend(f"{k}={v}" for k, v in sorted_params)
        key_string = "|".join(key_parts)
        return hashlib.md5(key_string.encode()).hexdigest()
        
    def _get_cache_path(self, cache_key: str) -> Path:
        """Get the path for a cache file"""
        return self.CACHE_DIR / f"{cache_key}.cache"
        
    def _is_cache_valid(self, cache_path: Path) -> bool:
        """Check if a cache file is still valid"""
        if not cache_path.exists():
            return False
            
        cache_age = time.time() - cache_path.stat().st_mtime
        return cache_age < self.cache_duration
        
    def _load_from_cache(self, cache_path: Path) -> Optional[Any]:
        """Load data from cache"""
        try:
            with open(cache_path, 'rb') as f:
                return pickle.load(f)
        except (pickle.PickleError, EOFError) as e:
            self.logger.warning(f"Error loading cache: {e}")
            return None
            
    def _save_to_cache(self, cache_path: Path, data: Any) -> None:
        """Save data to cache"""
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(data, f)
        except (pickle.PickleError, IOError) as e:
            self.logger.warning(f"Error saving to cache: {e}")
            
    def _check_rate_limit(self):
        """Check and enforce rate limiting"""
        current_time = datetime.now()
        # Remove timestamps older than the window
        self.request_timestamps = [ts for ts in self.request_timestamps 
                                 if current_time - ts < timedelta(seconds=self.RATE_LIMIT_WINDOW)]
        
        if len(self.request_timestamps) >= self.MAX_REQUESTS_PER_WINDOW:
            # Calculate wait time until oldest request expires
            wait_time = (self.request_timestamps[0] + 
                        timedelta(seconds=self.RATE_LIMIT_WINDOW) - 
                        current_time).total_seconds()
            if wait_time > 0:
                time.sleep(wait_time)
        
        self.request_timestamps.append(current_time)
        
    def _make_request(self, method: str, endpoint: str, use_cache: bool = True, 
                     **kwargs) -> Tuple[requests.Response, bool]:
        """Make an API request with rate limiting, retry mechanism, and caching"""
        # Check cache first if enabled
        if use_cache and method == 'GET':
            cache_key = self._get_cache_key(endpoint, kwargs.get('params'))
            cache_path = self._get_cache_path(cache_key)
            
            with self.CACHE_LOCK:
                if self._is_cache_valid(cache_path):
                    cached_data = self._load_from_cache(cache_path)
                    if cached_data is not None:
                        self.logger.debug(f"Cache hit for {endpoint}")
                        return cached_data, True
                        
        # Make the actual request
        for attempt in range(self.MAX_RETRIES):
            try:
                self._check_rate_limit()
                url = f"{self.BASE_URL}/{endpoint}"
                response = requests.request(method, url, headers=self.headers, **kwargs)
                
                # Check for rate limit headers
                if 'X-RateLimit-Remaining' in response.headers:
                    remaining = int(response.headers['X-RateLimit-Remaining'])
                    if remaining < 10:  # If we're close to the limit
                        time.sleep(1)  # Add a small delay
                
                response.raise_for_status()
                
                # Cache successful GET responses
                if use_cache and method == 'GET':
                    cache_key = self._get_cache_key(endpoint, kwargs.get('params'))
                    cache_path = self._get_cache_path(cache_key)
                    
                    with self.CACHE_LOCK:
                        self._save_to_cache(cache_path, response)
                
                return response, False
                
            except requests.exceptions.RequestException as e:
                if attempt == self.MAX_RETRIES - 1:  # Last attempt
                    self.logger.error(f"Failed after {self.MAX_RETRIES} attempts: {e}")
                    raise
                self.logger.warning(f"Attempt {attempt + 1} failed: {e}")
                time.sleep(self.RETRY_DELAY * (attempt + 1))  # Exponential backoff
                
    def clear_cache(self, endpoint: Optional[str] = None) -> None:
        """Clear the cache for a specific endpoint or all endpoints"""
        with self.CACHE_LOCK:
            if endpoint:
                cache_key = self._get_cache_key(endpoint)
                cache_path = self._get_cache_path(cache_key)
                if cache_path.exists():
                    cache_path.unlink()
            else:
                for cache_file in self.CACHE_DIR.glob("*.cache"):
                    cache_file.unlink()
                    
    def search_mods_generator(self, game_domain: str, search_term: str) -> Generator[Dict, None, None]:
        """Generator function to search mods page by page"""
        page = 1
        
        try:
            while True:
                response = self._make_request(
                    'GET',
                    f"games/{game_domain}/mods",
                    params={
                        "search": search_term,
                        "limit": self.SEARCH_PAGE_SIZE,
                        "page": page
                    }
                )
                data = response.json()
                mods = data.get("mods", [])
                
                if not mods:  # No more mods to fetch
                    break
                    
                for mod in mods:
                    yield mod
                    
                # Check if there are more pages
                if len(mods) < self.SEARCH_PAGE_SIZE:
                    break
                    
                page += 1
                
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error searching mods: {e}")
            
    def download_mod(self, game_domain: str, mod_id: int, file_id: int, 
                    download_path: Path) -> bool:
        """Download a mod file"""
        try:
            # Get download URL
            response, _ = self._make_request(
                'GET',
                f"games/{game_domain}/mods/{mod_id}/files/{file_id}/download_link",
                use_cache=False  # Don't cache download URLs
            )
            download_url = response.json()["uri"]
            
            # Get file size from headers
            head_response = requests.head(download_url)
            total_size = int(head_response.headers.get('content-length', 0))
            
            # Download with resume capability
            return self._download_with_resume(download_url, download_path, total_size)
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error downloading mod: {e}")
            return False
            
    def get_modpack_info(self, modpack_id: int, use_cache: bool = True) -> Optional[Dict]:
        """Get information about a modpack with caching"""
        try:
            response, from_cache = self._make_request(
                'GET',
                f"modpacks/{modpack_id}",
                use_cache=use_cache
            )
            
            if from_cache:
                return response.json()
                
            return response.json()
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Error getting modpack info: {e}")
            return None
            
    def _download_with_resume(self, url: str, download_path: Path, total_size: int) -> bool:
        """Download a file with resume capability"""
        # Get the initial file size if it exists
        initial_size = download_path.stat().st_size if download_path.exists() else 0
        
        # Check if the server supports resume
        headers = {'Range': f'bytes={initial_size}-'} if initial_size > 0 else {}
        
        for attempt in range(self.MAX_RETRIES):
            try:
                response = requests.get(url, stream=True, headers=headers)
                
                # If server doesn't support resume, start from beginning
                if initial_size > 0 and response.status_code == 200:
                    self.logger.warning("Server doesn't support resume, starting from beginning")
                    initial_size = 0
                    response = requests.get(url, stream=True)
                
                response.raise_for_status()
                
                # Get the total size from headers
                total_size = int(response.headers.get('content-length', 0)) + initial_size
                
                # Open file in append mode if resuming
                mode = 'ab' if initial_size > 0 else 'wb'
                with open(download_path, mode) as f:
                    with tqdm(total=total_size, initial=initial_size, unit='iB', unit_scale=True) as pbar:
                        for chunk in response.iter_content(chunk_size=self.CHUNK_SIZE):
                            if chunk:
                                f.write(chunk)
                                pbar.update(len(chunk))
                
                # Verify file size
                if download_path.stat().st_size == total_size:
                    return True
                else:
                    raise IOError("Downloaded file size doesn't match expected size")
                    
            except (requests.exceptions.RequestException, IOError) as e:
                if attempt == self.MAX_RETRIES - 1:  # Last attempt
                    self.logger.error(f"Download failed after {self.MAX_RETRIES} attempts: {e}")
                    return False
                self.logger.warning(f"Download attempt {attempt + 1} failed: {e}")
                time.sleep(self.RETRY_DELAY * (attempt + 1))  # Exponential backoff
                
                # Don't delete the file on retry, we'll resume from where we left off
                if attempt == self.MAX_RETRIES - 1 and download_path.exists():
                    download_path.unlink()  # Only delete on final failure
                    
            return None 