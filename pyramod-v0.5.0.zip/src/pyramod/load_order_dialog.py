import tkinter as tk
from tkinter import ttk
import json
from typing import List, Dict, Optional

class LoadOrderDialog:
    def __init__(self, parent, mod_manager):
        self.parent = parent
        self.mod_manager = mod_manager
        self.window = tk.Toplevel(parent)
        self.window.title("Load Order Manager")
        self.window.geometry("800x600")
        
        # Create main frame
        self.main_frame = ttk.Frame(self.window)
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Create mod list
        self.mod_list = ttk.Treeview(self.main_frame, columns=("Name", "Priority"), show="headings")
        self.mod_list.heading("Name", text="Mod Name")
        self.mod_list.heading("Priority", text="Load Order")
        self.mod_list.pack(fill=tk.BOTH, expand=True)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(self.main_frame, orient=tk.VERTICAL, command=self.mod_list.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.mod_list.configure(yscrollcommand=scrollbar.set)
        
        # Add buttons
        button_frame = ttk.Frame(self.window)
        button_frame.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(button_frame, text="Move Up", command=self.move_up).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Move Down", command=self.move_down).pack(side=tk.LEFT, padx=5)
        ttk.Button(button_frame, text="Save", command=self.save_order).pack(side=tk.RIGHT, padx=5)
        ttk.Button(button_frame, text="Cancel", command=self.window.destroy).pack(side=tk.RIGHT, padx=5)
        
        # Load current order
        self.load_current_order()
        
        # Enable drag and drop
        self.mod_list.bind("<ButtonPress-1>", self.on_press)
        self.mod_list.bind("<B1-Motion>", self.on_drag)
        self.mod_list.bind("<ButtonRelease-1>", self.on_release)
        
    def load_current_order(self):
        """Load current mod order from mod manager"""
        mods = self.mod_manager.get_mods()
        for i, mod in enumerate(mods):
            self.mod_list.insert("", "end", values=(mod["name"], i))
            
    def move_up(self):
        """Move selected mod up in load order"""
        selected = self.mod_list.selection()
        if not selected:
            return
            
        item = selected[0]
        prev = self.mod_list.prev(item)
        if prev:
            self.mod_list.move(item, "", self.mod_list.index(prev))
            self.update_priorities()
            
    def move_down(self):
        """Move selected mod down in load order"""
        selected = self.mod_list.selection()
        if not selected:
            return
            
        item = selected[0]
        next_item = self.mod_list.next(item)
        if next_item:
            self.mod_list.move(item, "", self.mod_list.index(next_item) + 1)
            self.update_priorities()
            
    def update_priorities(self):
        """Update priority numbers after reordering"""
        for i, item in enumerate(self.mod_list.get_children()):
            self.mod_list.set(item, "Priority", i)
            
    def save_order(self):
        """Save new load order to mod manager"""
        new_order = []
        for item in self.mod_list.get_children():
            mod_name = self.mod_list.item(item)["values"][0]
            priority = self.mod_list.item(item)["values"][1]
            new_order.append({"name": mod_name, "priority": priority})
            
        self.mod_manager.update_load_order(new_order)
        self.window.destroy()
        
    def on_press(self, event):
        """Handle mouse press for drag and drop"""
        self.drag_start = self.mod_list.identify_row(event.y)
        
    def on_drag(self, event):
        """Handle drag motion"""
        if not self.drag_start:
            return
            
        target = self.mod_list.identify_row(event.y)
        if target and target != self.drag_start:
            self.mod_list.move(self.drag_start, "", self.mod_list.index(target))
            self.drag_start = target
            
    def on_release(self, event):
        """Handle mouse release after drag"""
        if self.drag_start:
            self.update_priorities()
            self.drag_start = None 