"""
System compatibility checker for Pyramod.
"""

import os
import json
import logging
import platform
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger("pyramod.system")

class SystemCompatibilityChecker:
    """Checks system compatibility for games and mods."""
    
    def __init__(self, config_dir: str):
        """Initialize the system compatibility checker.
        
        Args:
            config_dir: Configuration directory
        """
        self.config_dir = Path(config_dir)
        self.system_config_dir = self.config_dir / "system"
        self.system_config_dir.mkdir(parents=True, exist_ok=True)
        
        self.config_file = self.system_config_dir / "config.json"
        if not self.config_file.exists():
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default system configuration."""
        default_config = {
            "system": {
                "os": platform.system(),
                "os_version": platform.version(),
                "architecture": platform.machine(),
                "processor": platform.processor(),
                "python_version": platform.python_version(),
            },
            "hardware": {
                "cpu": self._get_cpu_info(),
                "gpu": self._get_gpu_info(),
                "memory": self._get_memory_info(),
                "storage": self._get_storage_info(),
            },
            "software": {
                "wine_version": self._get_wine_version(),
                "proton_version": self._get_proton_version(),
                "dxvk_version": self._get_dxvk_version(),
                "vulkan_version": self._get_vulkan_version(),
            },
            "compatibility": {
                "wine_compatible": True,
                "proton_compatible": True,
                "dxvk_compatible": True,
                "vulkan_compatible": True,
            }
        }
        
        with open(self.config_file, "w") as f:
            json.dump(default_config, f, indent=4)
    
    def _get_cpu_info(self) -> Dict[str, str]:
        """Get CPU information.
        
        Returns:
            CPU information
        """
        try:
            with open("/proc/cpuinfo", "r") as f:
                cpu_info = f.read()
            
            info = {}
            for line in cpu_info.split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    info[key.strip()] = value.strip()
            
            return info
        except Exception as e:
            logger.error(f"Failed to get CPU info: {e}")
            return {}
    
    def _get_gpu_info(self) -> Dict[str, str]:
        """Get GPU information.
        
        Returns:
            GPU information
        """
        try:
            # Try to get GPU info using lspci
            result = subprocess.run(
                ["lspci", "-v"],
                capture_output=True,
                text=True
            )
            
            gpu_info = {}
            for line in result.stdout.split("\n"):
                if "VGA" in line or "3D" in line:
                    gpu_info["device"] = line.strip()
                elif "Kernel driver in use:" in line:
                    gpu_info["driver"] = line.split(":", 1)[1].strip()
            
            return gpu_info
        except Exception as e:
            logger.error(f"Failed to get GPU info: {e}")
            return {}
    
    def _get_memory_info(self) -> Dict[str, str]:
        """Get memory information.
        
        Returns:
            Memory information
        """
        try:
            with open("/proc/meminfo", "r") as f:
                mem_info = f.read()
            
            info = {}
            for line in mem_info.split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    info[key.strip()] = value.strip()
            
            return info
        except Exception as e:
            logger.error(f"Failed to get memory info: {e}")
            return {}
    
    def _get_storage_info(self) -> Dict[str, str]:
        """Get storage information.
        
        Returns:
            Storage information
        """
        try:
            result = subprocess.run(
                ["df", "-h"],
                capture_output=True,
                text=True
            )
            
            storage_info = {}
            for line in result.stdout.split("\n")[1:]:
                if line:
                    parts = line.split()
                    if len(parts) >= 6:
                        storage_info[parts[5]] = {
                            "size": parts[1],
                            "used": parts[2],
                            "available": parts[3],
                            "use_percent": parts[4]
                        }
            
            return storage_info
        except Exception as e:
            logger.error(f"Failed to get storage info: {e}")
            return {}
    
    def _get_wine_version(self) -> str:
        """Get Wine version.
        
        Returns:
            Wine version
        """
        try:
            result = subprocess.run(
                ["wine", "--version"],
                capture_output=True,
                text=True
            )
            return result.stdout.strip()
        except Exception as e:
            logger.error(f"Failed to get Wine version: {e}")
            return "Unknown"
    
    def _get_proton_version(self) -> str:
        """Get Proton version.
        
        Returns:
            Proton version
        """
        try:
            proton_dir = Path.home() / ".steam" / "steam" / "steamapps" / "common" / "Proton*"
            versions = list(proton_dir.parent.glob("Proton*"))
            if versions:
                return versions[-1].name
            return "Not installed"
        except Exception as e:
            logger.error(f"Failed to get Proton version: {e}")
            return "Unknown"
    
    def _get_dxvk_version(self) -> str:
        """Get DXVK version.
        
        Returns:
            DXVK version
        """
        try:
            dxvk_dir = Path.home() / ".local" / "share" / "dxvk"
            if dxvk_dir.exists():
                return "Installed"
            return "Not installed"
        except Exception as e:
            logger.error(f"Failed to get DXVK version: {e}")
            return "Unknown"
    
    def _get_vulkan_version(self) -> str:
        """Get Vulkan version.
        
        Returns:
            Vulkan version
        """
        try:
            result = subprocess.run(
                ["vulkaninfo", "--summary"],
                capture_output=True,
                text=True
            )
            
            for line in result.stdout.split("\n"):
                if "Vulkan Instance Version:" in line:
                    return line.split(":", 1)[1].strip()
            
            return "Unknown"
        except Exception as e:
            logger.error(f"Failed to get Vulkan version: {e}")
            return "Unknown"
    
    def get_config(self) -> Dict[str, Dict[str, Union[str, bool]]]:
        """Get the current system configuration.
        
        Returns:
            Current system configuration
        """
        with open(self.config_file, "r") as f:
            return json.load(f)
    
    def update_config(self, config: Dict[str, Dict[str, Union[str, bool]]]):
        """Update the system configuration.
        
        Args:
            config: New system configuration
        """
        current_config = self.get_config()
        current_config.update(config)
        
        with open(self.config_file, "w") as f:
            json.dump(current_config, f, indent=4)
    
    def check_compatibility(self, game: str) -> Dict[str, Union[bool, List[str]]]:
        """Check system compatibility for a game.
        
        Args:
            game: Game to check compatibility for
        
        Returns:
            Compatibility check results
        """
        config = self.get_config()
        
        # Check system requirements
        system_requirements = {
            "skyrim": {
                "min_cpu_cores": 2,
                "min_memory_gb": 4,
                "min_storage_gb": 6,
                "required_gpu": ["NVIDIA", "AMD", "Intel"],
                "required_dx_version": "11",
            },
            "fallout4": {
                "min_cpu_cores": 4,
                "min_memory_gb": 8,
                "min_storage_gb": 30,
                "required_gpu": ["NVIDIA", "AMD"],
                "required_dx_version": "11",
            }
        }
        
        if game not in system_requirements:
            return {
                "compatible": False,
                "warnings": [f"Unknown game: {game}"]
            }
        
        requirements = system_requirements[game]
        warnings = []
        
        # Check CPU
        cpu_info = config["hardware"]["cpu"]
        if "processor" in cpu_info:
            if "cores" in cpu_info:
                cores = int(cpu_info["cores"])
                if cores < requirements["min_cpu_cores"]:
                    warnings.append(f"Insufficient CPU cores: {cores} < {requirements['min_cpu_cores']}")
        
        # Check memory
        mem_info = config["hardware"]["memory"]
        if "MemTotal" in mem_info:
            total_mem = int(mem_info["MemTotal"].split()[0]) // (1024 * 1024)  # Convert to GB
            if total_mem < requirements["min_memory_gb"]:
                warnings.append(f"Insufficient memory: {total_mem}GB < {requirements['min_memory_gb']}GB")
        
        # Check storage
        storage_info = config["hardware"]["storage"]
        for mount, info in storage_info.items():
            if mount == "/":
                available = int(info["available"].rstrip("G"))
                if available < requirements["min_storage_gb"]:
                    warnings.append(f"Insufficient storage: {available}GB < {requirements['min_storage_gb']}GB")
        
        # Check GPU
        gpu_info = config["hardware"]["gpu"]
        if "device" in gpu_info:
            gpu_compatible = False
            for required_gpu in requirements["required_gpu"]:
                if required_gpu in gpu_info["device"]:
                    gpu_compatible = True
                    break
            
            if not gpu_compatible:
                warnings.append(f"Incompatible GPU: {gpu_info['device']}")
        
        # Check DirectX version
        if requirements["required_dx_version"] == "11":
            if not config["compatibility"]["dxvk_compatible"]:
                warnings.append("DXVK not compatible")
        
        return {
            "compatible": len(warnings) == 0,
            "warnings": warnings
        } 