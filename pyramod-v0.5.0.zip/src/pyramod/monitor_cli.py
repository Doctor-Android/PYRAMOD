#!/usr/bin/env python3
import argparse
import logging
import sys
import time
from pathlib import Path
from system_monitor import SystemMonitor

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the system monitoring CLI."""
    parser = argparse.ArgumentParser(
        description="System Resource Monitoring CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "monitor"),
        help="Directory to store monitoring data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Start monitoring command
    start_parser = subparsers.add_parser("start", help="Start monitoring")
    start_parser.add_argument("game_name", help="Name of the game to monitor")

    # Stop monitoring command
    stop_parser = subparsers.add_parser("stop", help="Stop monitoring")

    # Get current metrics command
    metrics_parser = subparsers.add_parser("metrics", help="Get current metrics")

    # Get history command
    history_parser = subparsers.add_parser("history", help="Get monitoring history")
    history_parser.add_argument("--game", help="Filter by game name")
    history_parser.add_argument("--start", help="Filter by start time (ISO format)")
    history_parser.add_argument("--end", help="Filter by end time (ISO format)")

    # Add process command
    add_process_parser = subparsers.add_parser("add-process", help="Add process to monitor")
    add_process_parser.add_argument("process_name", help="Name of the process to monitor")

    # Remove process command
    remove_process_parser = subparsers.add_parser("remove-process", help="Remove monitored process")
    remove_process_parser.add_argument("process_name", help="Name of the process to remove")

    # Update thresholds command
    thresholds_parser = subparsers.add_parser("update-thresholds", help="Update alert thresholds")
    thresholds_parser.add_argument("--cpu", type=float, help="CPU usage threshold")
    thresholds_parser.add_argument("--memory", type=float, help="Memory usage threshold")
    thresholds_parser.add_argument("--gpu", type=float, help="GPU usage threshold")
    thresholds_parser.add_argument("--gpu-memory", type=float, help="GPU memory usage threshold")
    thresholds_parser.add_argument("--disk", type=float, help="Disk usage threshold")

    # Cleanup history command
    cleanup_parser = subparsers.add_parser("cleanup", help="Clean up old history files")

    # Watch command
    watch_parser = subparsers.add_parser("watch", help="Watch metrics in real-time")
    watch_parser.add_argument("--interval", type=float, default=1.0, help="Update interval in seconds")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("monitor_cli")
    monitor = SystemMonitor(args.config_dir)

    try:
        if args.command == "start":
            success = monitor.start_monitoring(args.game_name)
            if success:
                logger.info(f"Started monitoring {args.game_name}")
            else:
                logger.error("Failed to start monitoring")
                sys.exit(1)

        elif args.command == "stop":
            success = monitor.stop_monitoring()
            if success:
                logger.info("Stopped monitoring")
            else:
                logger.error("Failed to stop monitoring")
                sys.exit(1)

        elif args.command == "metrics":
            metrics = monitor.get_current_metrics()
            if metrics:
                print("\nCurrent System Metrics:")
                print(f"\nCPU Usage: {metrics['cpu']['percent']}%")
                print(f"Memory Usage: {metrics['memory']['percent']}%")
                print(f"Disk Usage: {metrics['disk']['percent']}%")
                
                if metrics['gpu']:
                    print("\nGPU Metrics:")
                    for gpu in metrics['gpu']:
                        print(f"\nGPU {gpu['name']}:")
                        print(f"  Load: {gpu['load']}%")
                        print(f"  Memory: {gpu['memory_percent']}%")
                        print(f"  Temperature: {gpu['temperature']}°C")
                
                if metrics['processes']:
                    print("\nMonitored Processes:")
                    for proc in metrics['processes']:
                        print(f"\n{proc['name']} (PID: {proc['pid']}):")
                        print(f"  CPU: {proc['cpu_percent']}%")
                        print(f"  Memory: {proc['memory_percent']}%")
            else:
                logger.error("No metrics available")
                sys.exit(1)

        elif args.command == "history":
            history = monitor.get_metrics_history(
                game_name=args.game,
                start_time=args.start,
                end_time=args.end
            )
            
            if history:
                print("\nMonitoring History:")
                for entry in history:
                    print(f"\nGame: {entry['game']}")
                    print(f"Start: {entry['start_time']}")
                    print(f"End: {entry['end_time']}")
                    print(f"Metrics: {len(entry['metrics'])} samples")
            else:
                print("No history found")

        elif args.command == "add-process":
            monitor.add_monitored_process(args.process_name)
            logger.info(f"Added process: {args.process_name}")

        elif args.command == "remove-process":
            monitor.remove_monitored_process(args.process_name)
            logger.info(f"Removed process: {args.process_name}")

        elif args.command == "update-thresholds":
            thresholds = {}
            if args.cpu is not None:
                thresholds["cpu_percent"] = args.cpu
            if args.memory is not None:
                thresholds["memory_percent"] = args.memory
            if args.gpu is not None:
                thresholds["gpu_percent"] = args.gpu
            if args.gpu_memory is not None:
                thresholds["gpu_memory_percent"] = args.gpu_memory
            if args.disk is not None:
                thresholds["disk_percent"] = args.disk
            
            monitor.update_alert_thresholds(thresholds)
            logger.info("Updated alert thresholds")

        elif args.command == "cleanup":
            monitor.cleanup_history()
            logger.info("Cleaned up old history files")

        elif args.command == "watch":
            try:
                while True:
                    metrics = monitor.get_current_metrics()
                    if metrics:
                        print("\033[2J\033[H")  # Clear screen
                        print("System Metrics (Press Ctrl+C to exit):")
                        print(f"\nCPU Usage: {metrics['cpu']['percent']}%")
                        print(f"Memory Usage: {metrics['memory']['percent']}%")
                        print(f"Disk Usage: {metrics['disk']['percent']}%")
                        
                        if metrics['gpu']:
                            print("\nGPU Metrics:")
                            for gpu in metrics['gpu']:
                                print(f"\nGPU {gpu['name']}:")
                                print(f"  Load: {gpu['load']}%")
                                print(f"  Memory: {gpu['memory_percent']}%")
                                print(f"  Temperature: {gpu['temperature']}°C")
                        
                        if metrics['processes']:
                            print("\nMonitored Processes:")
                            for proc in metrics['processes']:
                                print(f"\n{proc['name']} (PID: {proc['pid']}):")
                                print(f"  CPU: {proc['cpu_percent']}%")
                                print(f"  Memory: {proc['memory_percent']}%")
                    
                    time.sleep(args.interval)
            except KeyboardInterrupt:
                print("\nStopped watching metrics")

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 