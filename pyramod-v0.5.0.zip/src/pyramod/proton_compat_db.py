import os
import json
import logging
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple

class ProtonCompatDB:
    def __init__(self, db_path: str = None):
        """Initialize the Proton/Wine compatibility database.
        
        Args:
            db_path: Optional path to the SQLite database file. If not provided,
                    will use the default location in the user's config directory.
        """
        self.logger = logging.getLogger("ProtonCompatDB")
        
        # Set up database path
        if db_path is None:
            config_dir = Path.home() / ".config" / "pyramod"
            config_dir.mkdir(parents=True, exist_ok=True)
            db_path = config_dir / "proton_compat.db"
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._init_db()
        
    def _init_db(self):
        """Initialize the SQLite database with required tables."""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            
            # Create tables if they don't exist
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS proton_versions (
                    id INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    version TEXT NOT NULL,
                    type TEXT NOT NULL,  -- 'proton' or 'wine'
                    path TEXT,
                    is_installed BOOLEAN DEFAULT 0,
                    last_updated TIMESTAMP,
                    UNIQUE(name, version)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS games (
                    id INTEGER PRIMARY KEY,
                    game_id TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    executable TEXT,
                    steam_appid TEXT,
                    gog_id TEXT,
                    epic_id TEXT,
                    executable_hash TEXT,
                    last_updated TIMESTAMP,
                    UNIQUE(game_id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS game_compatibility (
                    id INTEGER PRIMARY KEY,
                    game_id TEXT NOT NULL,
                    proton_version_id INTEGER,
                    compatibility_level TEXT NOT NULL,  -- 'perfect', 'good', 'playable', 'broken'
                    notes TEXT,
                    reported_by TEXT,
                    report_date TIMESTAMP,
                    FOREIGN KEY (proton_version_id) REFERENCES proton_versions(id),
                    FOREIGN KEY (game_id) REFERENCES games(game_id),
                    UNIQUE(game_id, proton_version_id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS mod_compatibility (
                    id INTEGER PRIMARY KEY,
                    mod_id TEXT NOT NULL,
                    game_id TEXT NOT NULL,
                    proton_version_id INTEGER,
                    compatibility_level TEXT NOT NULL,
                    notes TEXT,
                    reported_by TEXT,
                    report_date TIMESTAMP,
                    FOREIGN KEY (proton_version_id) REFERENCES proton_versions(id),
                    FOREIGN KEY (game_id) REFERENCES games(game_id),
                    UNIQUE(mod_id, game_id, proton_version_id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS compatibility_reports (
                    id INTEGER PRIMARY KEY,
                    report_type TEXT NOT NULL,  -- 'game' or 'mod'
                    target_id TEXT NOT NULL,  -- game_id or mod_id
                    proton_version_id INTEGER,
                    compatibility_level TEXT NOT NULL,
                    notes TEXT,
                    reported_by TEXT,
                    report_date TIMESTAMP,
                    verified BOOLEAN DEFAULT 0,
                    verified_by TEXT,
                    verified_date TIMESTAMP,
                    FOREIGN KEY (proton_version_id) REFERENCES proton_versions(id)
                )
            """)
            
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS game_configurations (
                    id INTEGER PRIMARY KEY,
                    game_id TEXT NOT NULL,
                    proton_version_id INTEGER,
                    config_key TEXT NOT NULL,
                    config_value TEXT NOT NULL,
                    last_updated TIMESTAMP,
                    FOREIGN KEY (game_id) REFERENCES games(game_id),
                    FOREIGN KEY (proton_version_id) REFERENCES proton_versions(id),
                    UNIQUE(game_id, proton_version_id, config_key)
                )
            """)
            
            conn.commit()
    
    def _calculate_executable_hash(self, executable_path: str) -> str:
        """Calculate SHA-256 hash of an executable file.
        
        Args:
            executable_path: Path to the executable file
            
        Returns:
            SHA-256 hash of the file
        """
        try:
            with open(executable_path, 'rb') as f:
                return hashlib.sha256(f.read()).hexdigest()
        except Exception as e:
            self.logger.error(f"Error calculating hash for {executable_path}: {e}")
            return ""
    
    def add_game(self, game_id: str, name: str, executable: Optional[str] = None,
                steam_appid: Optional[str] = None, gog_id: Optional[str] = None,
                epic_id: Optional[str] = None) -> int:
        """Add a new game to the database.
        
        Args:
            game_id: Unique identifier for the game
            name: Display name of the game
            executable: Optional path to the game's executable
            steam_appid: Optional Steam App ID
            gog_id: Optional GOG.com game ID
            epic_id: Optional Epic Games Store ID
            
        Returns:
            The ID of the newly added game
        """
        executable_hash = self._calculate_executable_hash(executable) if executable else None
        
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO games 
                (game_id, name, executable, steam_appid, gog_id, epic_id, executable_hash, last_updated)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (game_id, name, executable, steam_appid, gog_id, epic_id, executable_hash, datetime.now()))
            conn.commit()
            return cursor.lastrowid
    
    def get_game(self, game_id: str) -> Optional[Dict]:
        """Get game information.
        
        Args:
            game_id: Game identifier
            
        Returns:
            Game information dictionary or None if not found
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM games WHERE game_id = ?", (game_id,))
            result = cursor.fetchone()
            return dict(result) if result else None
    
    def find_game_by_executable(self, executable_path: str) -> Optional[Dict]:
        """Find a game by its executable path or hash.
        
        Args:
            executable_path: Path to the game's executable
            
        Returns:
            Game information dictionary or None if not found
        """
        executable_hash = self._calculate_executable_hash(executable_path)
        if not executable_hash:
            return None
            
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM games 
                WHERE executable = ? OR executable_hash = ?
            """, (executable_path, executable_hash))
            result = cursor.fetchone()
            return dict(result) if result else None
    
    def find_game_by_store_id(self, store: str, store_id: str) -> Optional[Dict]:
        """Find a game by its store ID.
        
        Args:
            store: Store name ('steam', 'gog', or 'epic')
            store_id: Store-specific game ID
            
        Returns:
            Game information dictionary or None if not found
        """
        store_column = f"{store}_id"
        if store_column not in ['steam_appid', 'gog_id', 'epic_id']:
            return None
            
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute(f"SELECT * FROM games WHERE {store_column} = ?", (store_id,))
            result = cursor.fetchone()
            return dict(result) if result else None
    
    def set_game_configuration(self, game_id: str, proton_version_id: int,
                             config_key: str, config_value: str):
        """Set a game-specific Proton/Wine configuration.
        
        Args:
            game_id: Game identifier
            proton_version_id: ID of the Proton/Wine version
            config_key: Configuration key
            config_value: Configuration value
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO game_configurations 
                (game_id, proton_version_id, config_key, config_value, last_updated)
                VALUES (?, ?, ?, ?, ?)
            """, (game_id, proton_version_id, config_key, config_value, datetime.now()))
            conn.commit()
    
    def get_game_configuration(self, game_id: str, proton_version_id: int) -> Dict[str, str]:
        """Get all game-specific Proton/Wine configurations.
        
        Args:
            game_id: Game identifier
            proton_version_id: ID of the Proton/Wine version
            
        Returns:
            Dictionary of configuration key-value pairs
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT config_key, config_value 
                FROM game_configurations
                WHERE game_id = ? AND proton_version_id = ?
            """, (game_id, proton_version_id))
            return {row['config_key']: row['config_value'] for row in cursor.fetchall()}
    
    def add_proton_version(self, name: str, version: str, type: str, path: Optional[str] = None) -> int:
        """Add a new Proton/Wine version to the database.
        
        Args:
            name: Name of the Proton/Wine version (e.g., "Proton Experimental")
            version: Version string (e.g., "7.0-5")
            type: Either "proton" or "wine"
            path: Optional path to the installation
            
        Returns:
            The ID of the newly added version
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO proton_versions 
                (name, version, type, path, last_updated)
                VALUES (?, ?, ?, ?, ?)
            """, (name, version, type, path, datetime.now()))
            conn.commit()
            return cursor.lastrowid
    
    def update_proton_installation(self, version_id: int, is_installed: bool, path: Optional[str] = None):
        """Update the installation status of a Proton/Wine version.
        
        Args:
            version_id: ID of the Proton/Wine version
            is_installed: Whether the version is installed
            path: Optional path to the installation
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE proton_versions 
                SET is_installed = ?, path = ?, last_updated = ?
                WHERE id = ?
            """, (is_installed, path, datetime.now(), version_id))
            conn.commit()
    
    def get_proton_versions(self, type: Optional[str] = None) -> List[Dict]:
        """Get all Proton/Wine versions.
        
        Args:
            type: Optional filter for version type ("proton" or "wine")
            
        Returns:
            List of version dictionaries
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if type:
                cursor.execute("""
                    SELECT * FROM proton_versions 
                    WHERE type = ?
                    ORDER BY name, version
                """, (type,))
            else:
                cursor.execute("""
                    SELECT * FROM proton_versions 
                    ORDER BY name, version
                """)
            
            return [dict(row) for row in cursor.fetchall()]
    
    def add_game_compatibility(self, game_id: str, proton_version_id: int, 
                             compatibility_level: str, notes: str = "", 
                             reported_by: str = "system") -> int:
        """Add or update game compatibility information.
        
        Args:
            game_id: Game identifier
            proton_version_id: ID of the Proton/Wine version
            compatibility_level: Compatibility level ("perfect", "good", "playable", "broken")
            notes: Optional notes about compatibility
            reported_by: Who reported the compatibility
            
        Returns:
            The ID of the compatibility entry
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO game_compatibility 
                (game_id, proton_version_id, compatibility_level, notes, reported_by, report_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (game_id, proton_version_id, compatibility_level, notes, reported_by, datetime.now()))
            conn.commit()
            return cursor.lastrowid
    
    def add_mod_compatibility(self, mod_id: str, game_id: str, proton_version_id: int,
                            compatibility_level: str, notes: str = "",
                            reported_by: str = "system") -> int:
        """Add or update mod compatibility information.
        
        Args:
            mod_id: Mod identifier
            game_id: Game identifier
            proton_version_id: ID of the Proton/Wine version
            compatibility_level: Compatibility level
            notes: Optional notes about compatibility
            reported_by: Who reported the compatibility
            
        Returns:
            The ID of the compatibility entry
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR REPLACE INTO mod_compatibility 
                (mod_id, game_id, proton_version_id, compatibility_level, notes, reported_by, report_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (mod_id, game_id, proton_version_id, compatibility_level, notes, reported_by, datetime.now()))
            conn.commit()
            return cursor.lastrowid
    
    def get_game_compatibility(self, game_id: str) -> List[Dict]:
        """Get compatibility information for a game.
        
        Args:
            game_id: Game identifier
            
        Returns:
            List of compatibility entries
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT gc.*, pv.name as proton_name, pv.version as proton_version
                FROM game_compatibility gc
                JOIN proton_versions pv ON gc.proton_version_id = pv.id
                WHERE gc.game_id = ?
                ORDER BY gc.report_date DESC
            """, (game_id,))
            return [dict(row) for row in cursor.fetchall()]
    
    def get_mod_compatibility(self, mod_id: str, game_id: str) -> List[Dict]:
        """Get compatibility information for a mod.
        
        Args:
            mod_id: Mod identifier
            game_id: Game identifier
            
        Returns:
            List of compatibility entries
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("""
                SELECT mc.*, pv.name as proton_name, pv.version as proton_version
                FROM mod_compatibility mc
                JOIN proton_versions pv ON mc.proton_version_id = pv.id
                WHERE mc.mod_id = ? AND mc.game_id = ?
                ORDER BY mc.report_date DESC
            """, (mod_id, game_id))
            return [dict(row) for row in cursor.fetchall()]
    
    def add_compatibility_report(self, report_type: str, target_id: str, 
                               proton_version_id: int, compatibility_level: str,
                               notes: str = "", reported_by: str = "user") -> int:
        """Add a new compatibility report.
        
        Args:
            report_type: Either "game" or "mod"
            target_id: Game or mod identifier
            proton_version_id: ID of the Proton/Wine version
            compatibility_level: Compatibility level
            notes: Optional notes about compatibility
            reported_by: Who reported the compatibility
            
        Returns:
            The ID of the report
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO compatibility_reports 
                (report_type, target_id, proton_version_id, compatibility_level, 
                 notes, reported_by, report_date)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (report_type, target_id, proton_version_id, compatibility_level,
                  notes, reported_by, datetime.now()))
            conn.commit()
            return cursor.lastrowid
    
    def verify_compatibility_report(self, report_id: int, verified_by: str):
        """Mark a compatibility report as verified.
        
        Args:
            report_id: ID of the report to verify
            verified_by: Who verified the report
        """
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE compatibility_reports 
                SET verified = 1, verified_by = ?, verified_date = ?
                WHERE id = ?
            """, (verified_by, datetime.now(), report_id))
            conn.commit()
    
    def get_best_proton_version(self, game_id: str, mod_id: Optional[str] = None) -> Optional[Dict]:
        """Get the best Proton/Wine version for a game and optional mod.
        
        Args:
            game_id: Game identifier
            mod_id: Optional mod identifier
            
        Returns:
            Dictionary with the best Proton/Wine version information, or None if no
            compatible version is found
        """
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            if mod_id:
                # Get compatibility for both game and mod
                cursor.execute("""
                    SELECT pv.*, 
                           gc.compatibility_level as game_compatibility,
                           mc.compatibility_level as mod_compatibility
                    FROM proton_versions pv
                    JOIN game_compatibility gc ON pv.id = gc.proton_version_id
                    LEFT JOIN mod_compatibility mc ON pv.id = mc.proton_version_id 
                        AND mc.mod_id = ?
                    WHERE gc.game_id = ? AND pv.is_installed = 1
                    ORDER BY 
                        CASE gc.compatibility_level
                            WHEN 'perfect' THEN 1
                            WHEN 'good' THEN 2
                            WHEN 'playable' THEN 3
                            WHEN 'broken' THEN 4
                        END,
                        CASE mc.compatibility_level
                            WHEN 'perfect' THEN 1
                            WHEN 'good' THEN 2
                            WHEN 'playable' THEN 3
                            WHEN 'broken' THEN 4
                        END
                    LIMIT 1
                """, (mod_id, game_id))
            else:
                # Get compatibility for game only
                cursor.execute("""
                    SELECT pv.*, gc.compatibility_level as game_compatibility
                    FROM proton_versions pv
                    JOIN game_compatibility gc ON pv.id = gc.proton_version_id
                    WHERE gc.game_id = ? AND pv.is_installed = 1
                    ORDER BY 
                        CASE gc.compatibility_level
                            WHEN 'perfect' THEN 1
                            WHEN 'good' THEN 2
                            WHEN 'playable' THEN 3
                            WHEN 'broken' THEN 4
                        END
                    LIMIT 1
                """, (game_id,))
            
            result = cursor.fetchone()
            return dict(result) if result else None 