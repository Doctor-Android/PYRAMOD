#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from mod_showcase import ModShowcase

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the mod showcase CLI."""
    parser = argparse.ArgumentParser(
        description="Mod Showcase CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "showcase"),
        help="Directory to store showcase data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Create showcase command
    create_parser = subparsers.add_parser("create", help="Create a new showcase")
    create_parser.add_argument("mod_id", help="ID of the mod being showcased")
    create_parser.add_argument("title", help="Showcase title")
    create_parser.add_argument("description", help="Showcase description")
    create_parser.add_argument("author_id", help="ID of the showcase author")
    create_parser.add_argument("--media-files", nargs="+", help="Paths to media files")
    create_parser.add_argument("--tags", nargs="+", help="Tags for the showcase")
    create_parser.add_argument("--featured", action="store_true", help="Mark as featured")

    # Update showcase command
    update_parser = subparsers.add_parser("update", help="Update a showcase")
    update_parser.add_argument("showcase_id", help="ID of the showcase to update")
    update_parser.add_argument("--title", help="New title")
    update_parser.add_argument("--description", help="New description")
    update_parser.add_argument("--media-files", nargs="+", help="New media files")
    update_parser.add_argument("--tags", nargs="+", help="New tags")
    update_parser.add_argument("--featured", type=bool, help="New featured status")

    # Delete showcase command
    delete_parser = subparsers.add_parser("delete", help="Delete a showcase")
    delete_parser.add_argument("showcase_id", help="ID of the showcase to delete")

    # List showcases command
    list_parser = subparsers.add_parser("list", help="List showcases")
    list_parser.add_argument("--mod-id", help="Filter by mod ID")
    list_parser.add_argument("--author-id", help="Filter by author ID")
    list_parser.add_argument("--tags", nargs="+", help="Filter by tags")
    list_parser.add_argument("--featured", type=bool, help="Filter by featured status")
    list_parser.add_argument("--limit", type=int, default=50, help="Maximum number of results")
    list_parser.add_argument("--offset", type=int, default=0, help="Number of results to skip")

    # Get showcase info command
    info_parser = subparsers.add_parser("info", help="Get showcase information")
    info_parser.add_argument("showcase_id", help="ID of the showcase")

    # Add comment command
    comment_parser = subparsers.add_parser("comment", help="Add a comment to a showcase")
    comment_parser.add_argument("showcase_id", help="ID of the showcase")
    comment_parser.add_argument("author_id", help="ID of the comment author")
    comment_parser.add_argument("content", help="Comment content")

    # Delete comment command
    delete_comment_parser = subparsers.add_parser("delete-comment", help="Delete a comment")
    delete_comment_parser.add_argument("showcase_id", help="ID of the showcase")
    delete_comment_parser.add_argument("comment_id", help="ID of the comment to delete")

    # View showcase command
    view_parser = subparsers.add_parser("view", help="Increment view count for a showcase")
    view_parser.add_argument("showcase_id", help="ID of the showcase")

    # Like showcase command
    like_parser = subparsers.add_parser("like", help="Like a showcase")
    like_parser.add_argument("showcase_id", help="ID of the showcase")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("showcase_cli")
    showcase = ModShowcase(args.config_dir)

    try:
        if args.command == "create":
            showcase_id = showcase.create_showcase(
                mod_id=args.mod_id,
                title=args.title,
                description=args.description,
                author_id=args.author_id,
                media_files=args.media_files or [],
                tags=args.tags or [],
                featured=args.featured
            )
            if showcase_id:
                logger.info(f"Successfully created showcase: {showcase_id}")
            else:
                logger.error("Failed to create showcase")
                sys.exit(1)

        elif args.command == "update":
            updates = {}
            if args.title:
                updates["title"] = args.title
            if args.description:
                updates["description"] = args.description
            if args.media_files:
                updates["media_files"] = args.media_files
            if args.tags:
                updates["tags"] = args.tags
            if args.featured is not None:
                updates["featured"] = args.featured

            success = showcase.update_showcase(args.showcase_id, **updates)
            if success:
                logger.info("Successfully updated showcase")
            else:
                logger.error("Failed to update showcase")
                sys.exit(1)

        elif args.command == "delete":
            success = showcase.delete_showcase(args.showcase_id)
            if success:
                logger.info("Successfully deleted showcase")
            else:
                logger.error("Failed to delete showcase")
                sys.exit(1)

        elif args.command == "list":
            showcases = showcase.list_showcases(
                mod_id=args.mod_id,
                author_id=args.author_id,
                tags=args.tags,
                featured=args.featured,
                limit=args.limit,
                offset=args.offset
            )
            
            if showcases:
                print("\nShowcases:")
                for s in showcases:
                    print(f"\nID: {s['id']}")
                    print(f"Title: {s['title']}")
                    print(f"Mod: {s['mod_id']}")
                    print(f"Author: {s['author_id']}")
                    print(f"Created: {s['created_at']}")
                    print(f"Views: {s['views']}")
                    print(f"Likes: {s['likes']}")
                    print(f"Featured: {s['featured']}")
            else:
                print("No showcases found")

        elif args.command == "info":
            showcase_info = showcase.get_showcase(args.showcase_id)
            if showcase_info:
                print(f"\nShowcase information for {args.showcase_id}:")
                print(f"Title: {showcase_info['title']}")
                print(f"Description: {showcase_info['description']}")
                print(f"Mod: {showcase_info['mod_id']}")
                print(f"Author: {showcase_info['author_id']}")
                print(f"Created: {showcase_info['created_at']}")
                print(f"Updated: {showcase_info['updated_at']}")
                print(f"Views: {showcase_info['views']}")
                print(f"Likes: {showcase_info['likes']}")
                print(f"Featured: {showcase_info['featured']}")
                print("\nTags:")
                for tag in showcase_info['tags']:
                    print(f"- {tag}")
                print("\nMedia Files:")
                for media in showcase_info['media_files']:
                    print(f"- {media}")
                print("\nComments:")
                for comment in showcase_info['comments']:
                    print(f"\n{comment['author_id']} ({comment['created_at']}):")
                    print(comment['content'])
            else:
                logger.error(f"Showcase not found: {args.showcase_id}")
                sys.exit(1)

        elif args.command == "comment":
            success = showcase.add_comment(
                args.showcase_id,
                args.author_id,
                args.content
            )
            if success:
                logger.info("Successfully added comment")
            else:
                logger.error("Failed to add comment")
                sys.exit(1)

        elif args.command == "delete-comment":
            success = showcase.delete_comment(
                args.showcase_id,
                args.comment_id
            )
            if success:
                logger.info("Successfully deleted comment")
            else:
                logger.error("Failed to delete comment")
                sys.exit(1)

        elif args.command == "view":
            success = showcase.increment_views(args.showcase_id)
            if success:
                logger.info("Successfully incremented view count")
            else:
                logger.error("Failed to increment view count")
                sys.exit(1)

        elif args.command == "like":
            success = showcase.toggle_like(args.showcase_id)
            if success:
                logger.info("Successfully liked showcase")
            else:
                logger.error("Failed to like showcase")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 