#!/usr/bin/env python3
import argparse
import logging
import sys
from pathlib import Path
from events_calendar import EventsCalendar

def setup_logging():
    """Set up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

def main():
    """Main entry point for the events calendar CLI."""
    parser = argparse.ArgumentParser(
        description="Community Modding Events Calendar CLI"
    )
    parser.add_argument(
        "--config-dir",
        default=str(Path.home() / ".config" / "pyramod" / "events"),
        help="Directory to store calendar data"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to execute")

    # Add event command
    add_parser = subparsers.add_parser("add", help="Add a new event")
    add_parser.add_argument("title", help="Event title")
    add_parser.add_argument("description", help="Event description")
    add_parser.add_argument("start_time", help="Event start time (ISO format)")
    add_parser.add_argument("end_time", help="Event end time (ISO format)")
    add_parser.add_argument("event_type", help="Event type")
    add_parser.add_argument("--tags", help="Comma-separated list of tags")
    add_parser.add_argument("--location", help="Event location")
    add_parser.add_argument("--url", help="Event URL")

    # List events command
    list_parser = subparsers.add_parser("list", help="List events")
    list_parser.add_argument("--type", help="Filter by event type")
    list_parser.add_argument("--tags", help="Comma-separated list of tags to filter by")
    list_parser.add_argument("--start", help="Filter by start date (ISO format)")
    list_parser.add_argument("--end", help="Filter by end date (ISO format)")

    # Get event info command
    info_parser = subparsers.add_parser("info", help="Get event information")
    info_parser.add_argument("event_id", help="Event ID")

    # Update event command
    update_parser = subparsers.add_parser("update", help="Update an event")
    update_parser.add_argument("event_id", help="Event ID")
    update_parser.add_argument("--title", help="New event title")
    update_parser.add_argument("--description", help="New event description")
    update_parser.add_argument("--start-time", help="New start time (ISO format)")
    update_parser.add_argument("--end-time", help="New end time (ISO format)")
    update_parser.add_argument("--type", help="New event type")
    update_parser.add_argument("--tags", help="New comma-separated list of tags")
    update_parser.add_argument("--location", help="New event location")
    update_parser.add_argument("--url", help="New event URL")

    # Delete event command
    delete_parser = subparsers.add_parser("delete", help="Delete an event")
    delete_parser.add_argument("event_id", help="Event ID")

    # Add participant command
    add_participant_parser = subparsers.add_parser("add-participant", help="Add a participant")
    add_participant_parser.add_argument("event_id", help="Event ID")
    add_participant_parser.add_argument("user_id", help="User ID")

    # Remove participant command
    remove_participant_parser = subparsers.add_parser("remove-participant", help="Remove a participant")
    remove_participant_parser.add_argument("event_id", help="Event ID")
    remove_participant_parser.add_argument("user_id", help="User ID")

    # List upcoming events command
    upcoming_parser = subparsers.add_parser("upcoming", help="List upcoming events")
    upcoming_parser.add_argument("--days", type=int, default=7, help="Number of days to look ahead")

    # Export calendar command
    export_parser = subparsers.add_parser("export", help="Export calendar")
    export_parser.add_argument("output_file", help="Output file path")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    setup_logging()
    logger = logging.getLogger("calendar_cli")
    calendar = EventsCalendar(args.config_dir)

    try:
        if args.command == "add":
            tags = args.tags.split(",") if args.tags else None
            event_id = calendar.add_event(
                title=args.title,
                description=args.description,
                start_time=args.start_time,
                end_time=args.end_time,
                event_type=args.event_type,
                tags=tags,
                location=args.location,
                url=args.url
            )
            if event_id:
                logger.info(f"Successfully added event: {event_id}")
            else:
                logger.error("Failed to add event")
                sys.exit(1)

        elif args.command == "list":
            tags = args.tags.split(",") if args.tags else None
            events = calendar.list_events(
                event_type=args.type,
                tags=tags,
                start_date=args.start,
                end_date=args.end
            )
            if events:
                print("\nEvents:")
                for event in events:
                    print(f"\nID: {event['id']}")
                    print(f"Title: {event['title']}")
                    print(f"Description: {event['description']}")
                    print(f"Type: {event['event_type']}")
                    print(f"Start: {event['start_time']}")
                    print(f"End: {event['end_time']}")
                    print(f"Tags: {', '.join(event['tags'])}")
                    print(f"Participants: {len(event['participants'])}")
            else:
                print("No events found")

        elif args.command == "info":
            event = calendar.get_event(args.event_id)
            if event:
                print(f"\nEvent information for {args.event_id}:")
                print(f"Title: {event['title']}")
                print(f"Description: {event['description']}")
                print(f"Type: {event['event_type']}")
                print(f"Start: {event['start_time']}")
                print(f"End: {event['end_time']}")
                print(f"Tags: {', '.join(event['tags'])}")
                print(f"Location: {event.get('location', 'N/A')}")
                print(f"URL: {event.get('url', 'N/A')}")
                print("\nParticipants:")
                for participant in event['participants']:
                    print(f"- {participant}")
            else:
                logger.error(f"Event not found: {args.event_id}")
                sys.exit(1)

        elif args.command == "update":
            updates = {}
            if args.title:
                updates["title"] = args.title
            if args.description:
                updates["description"] = args.description
            if args.start_time:
                updates["start_time"] = args.start_time
            if args.end_time:
                updates["end_time"] = args.end_time
            if args.type:
                updates["event_type"] = args.type
            if args.tags:
                updates["tags"] = args.tags.split(",")
            if args.location:
                updates["location"] = args.location
            if args.url:
                updates["url"] = args.url

            result = calendar.update_event(args.event_id, updates)
            if result:
                logger.info("Successfully updated event")
            else:
                logger.error("Failed to update event")
                sys.exit(1)

        elif args.command == "delete":
            result = calendar.delete_event(args.event_id)
            if result:
                logger.info("Successfully deleted event")
            else:
                logger.error("Failed to delete event")
                sys.exit(1)

        elif args.command == "add-participant":
            result = calendar.add_participant(args.event_id, args.user_id)
            if result:
                logger.info("Successfully added participant")
            else:
                logger.error("Failed to add participant")
                sys.exit(1)

        elif args.command == "remove-participant":
            result = calendar.remove_participant(args.event_id, args.user_id)
            if result:
                logger.info("Successfully removed participant")
            else:
                logger.error("Failed to remove participant")
                sys.exit(1)

        elif args.command == "upcoming":
            events = calendar.get_upcoming_events(days=args.days)
            if events:
                print(f"\nUpcoming events (next {args.days} days):")
                for event in events:
                    print(f"\nID: {event['id']}")
                    print(f"Title: {event['title']}")
                    print(f"Start: {event['start_time']}")
                    print(f"Type: {event['event_type']}")
                    print(f"Participants: {len(event['participants'])}")
            else:
                print(f"No upcoming events in the next {args.days} days")

        elif args.command == "export":
            result = calendar.export_calendar(args.output_file)
            if result:
                logger.info(f"Successfully exported calendar to: {args.output_file}")
            else:
                logger.error("Failed to export calendar")
                sys.exit(1)

    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main() 