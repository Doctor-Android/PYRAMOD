from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = fh.read().splitlines()

setup(
    name="pyramod",
    version="0.5.0",
    author="BLUDSTAR",
    author_email="bludstar@example.com",
    description="A powerful mod manager for Linux games with Wine/Proton support",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/bludstar/pyramod",
    package_dir={'': 'src'},
    packages=find_packages(where='src'),
    include_package_data=True,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: POSIX :: Linux",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Games/Entertainment",
        "Topic :: System :: Systems Administration",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "pyramod=pyramod.main:main",
        ],
    },
    keywords="mod-manager, gaming, linux, wine, proton, mods, vortex",
    project_urls={
        "Bug Reports": "https://github.com/bludstar/pyramod/issues",
        "Source": "https://github.com/bludstar/pyramod",
        "Documentation": "https://github.com/bludstar/pyramod/wiki",
    },
) 