# Contributing to Pyramod

Thank you for your interest in contributing to Pyramod! This document provides guidelines and instructions for contributing.

## Code of Conduct

By participating in this project, you agree to maintain a respectful and inclusive environment for everyone.

## How to Contribute

### Reporting Bugs

1. Check if the bug has already been reported in the Issues section
2. If not, create a new issue with:
   - Clear title and description
   - Steps to reproduce
   - Expected vs actual behavior
   - System information (OS, Python version, etc.)
   - Screenshots if applicable

### Suggesting Features

1. Check if the feature has already been suggested
2. Create a new issue with:
   - Clear title and description
   - Use case and benefits
   - Implementation suggestions if any

### Pull Requests

1. Fork the repository
2. Create a new branch for your feature/fix
3. Make your changes
4. Run tests and ensure they pass
5. Update documentation if needed
6. Submit a pull request

### Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/pyramod.git
   cd pyramod
   ```

2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Install development dependencies:
   ```bash
   pip install -r requirements-dev.txt
   ```

### Code Style

- Follow PEP 8 guidelines
- Use meaningful variable and function names
- Add comments for complex logic
- Write docstrings for functions and classes
- Keep functions focused and small

### Testing

- Write tests for new features
- Ensure all tests pass before submitting PR
- Run tests with:
  ```bash
  pytest
  ```

### Documentation

- Update README.md if needed
- Add docstrings for new functions/classes
- Update API documentation if applicable

## Commit Messages

- Use clear and descriptive commit messages
- Reference issue numbers if applicable
- Use present tense ("Add feature" not "Added feature")

## Review Process

1. All PRs will be reviewed by maintainers
2. Address any feedback or requested changes
3. Once approved, your PR will be merged

## Getting Help

- Join our Discord server
- Check existing issues and discussions
- Ask questions in the Discussions section

Thank you for contributing to Pyramod! 