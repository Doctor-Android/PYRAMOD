#!/usr/bin/env python3
import unittest
import tempfile
import shutil
import os
from pathlib import Path
from wine_config_manager import WineConfigManager

class TestWineConfigManager(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.manager = WineConfigManager(self.test_dir)

    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)

    def test_prefix_creation(self):
        """Test creating a new Wine prefix."""
        # Create a test prefix
        result = self.manager.create_prefix("test_prefix", "wine-7.0")
        self.assertTrue(result)

        # Verify prefix exists
        prefix_path = Path(self.test_dir) / "prefixes" / "test_prefix"
        self.assertTrue(prefix_path.exists())

        # Verify configuration
        config = self.manager.get_prefix_info("test_prefix")
        self.assertIsNotNone(config)
        self.assertEqual(config["wine_version"], "wine-7.0")

    def test_prefix_configuration(self):
        """Test configuring a Wine prefix."""
        # Create and configure a prefix
        self.manager.create_prefix("test_prefix", "wine-7.0")
        settings = {
            "registry": {
                "HKEY_CURRENT_USER\\Software\\Wine\\DirectInput": "native"
            },
            "dll_overrides": {
                "d3d11": "native"
            },
            "environment": {
                "WINEDLLOVERRIDES": "d3d11=native"
            }
        }
        result = self.manager.configure_prefix("test_prefix", settings)
        self.assertTrue(result)

        # Verify configuration
        config = self.manager.get_prefix_info("test_prefix")
        self.assertEqual(config["settings"], settings)

    def test_prefix_deletion(self):
        """Test deleting a Wine prefix."""
        # Create and delete a prefix
        self.manager.create_prefix("test_prefix", "wine-7.0")
        result = self.manager.delete_prefix("test_prefix")
        self.assertTrue(result)

        # Verify prefix is deleted
        prefix_path = Path(self.test_dir) / "prefixes" / "test_prefix"
        self.assertFalse(prefix_path.exists())
        self.assertIsNone(self.manager.get_prefix_info("test_prefix"))

    def test_config_export_import(self):
        """Test exporting and importing prefix configurations."""
        # Create and configure a prefix
        self.manager.create_prefix("test_prefix", "wine-7.0")
        settings = {
            "registry": {
                "HKEY_CURRENT_USER\\Software\\Wine\\DirectInput": "native"
            }
        }
        self.manager.configure_prefix("test_prefix", settings)

        # Export configuration
        export_file = os.path.join(self.test_dir, "test_config.yaml")
        export_result = self.manager.export_config("test_prefix", export_file)
        self.assertTrue(export_result)
        self.assertTrue(os.path.exists(export_file))

        # Import configuration to new prefix
        import_result = self.manager.import_config(export_file, "imported_prefix")
        self.assertTrue(import_result)

        # Verify imported configuration
        imported_config = self.manager.get_prefix_info("imported_prefix")
        self.assertIsNotNone(imported_config)
        self.assertEqual(imported_config["settings"], settings)

    def test_list_prefixes(self):
        """Test listing configured prefixes."""
        # Create multiple prefixes
        self.manager.create_prefix("prefix1", "wine-7.0")
        self.manager.create_prefix("prefix2", "wine-7.0")

        # Verify prefix list
        prefixes = self.manager.list_prefixes()
        self.assertEqual(len(prefixes), 2)
        self.assertIn("prefix1", prefixes)
        self.assertIn("prefix2", prefixes)

    def test_invalid_prefix_operations(self):
        """Test operations on non-existent prefixes."""
        # Test getting info for non-existent prefix
        self.assertIsNone(self.manager.get_prefix_info("non_existent"))

        # Test configuring non-existent prefix
        result = self.manager.configure_prefix("non_existent", {})
        self.assertFalse(result)

        # Test deleting non-existent prefix
        result = self.manager.delete_prefix("non_existent")
        self.assertFalse(result)

    def test_version_detection(self):
        """Test detection of Wine and Proton versions."""
        versions = self.manager.get_available_versions()
        self.assertIn("wine", versions)
        self.assertIn("proton", versions)
        self.assertIsInstance(versions["wine"], list)
        self.assertIsInstance(versions["proton"], list)

if __name__ == '__main__':
    unittest.main() 