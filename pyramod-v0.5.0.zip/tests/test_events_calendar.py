#!/usr/bin/env python3
import unittest
import tempfile
import shutil
import os
from pathlib import Path
from datetime import datetime, timedelta
from events_calendar import EventsCalendar

class TestEventsCalendar(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.calendar = EventsCalendar(self.test_dir)
        
        # Create test event
        self.test_event = {
            "title": "Test Event",
            "description": "Test Description",
            "start_time": (datetime.now() + timedelta(days=1)).isoformat(),
            "end_time": (datetime.now() + timedelta(days=2)).isoformat(),
            "event_type": "competition",
            "tags": ["test", "competition"]
        }

    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)

    def test_add_event(self):
        """Test adding an event."""
        # Add event
        event_id = self.calendar.add_event(**self.test_event)
        self.assertIsNotNone(event_id)
        
        # Verify event
        event = self.calendar.get_event(event_id)
        self.assertIsNotNone(event)
        self.assertEqual(event["title"], self.test_event["title"])
        self.assertEqual(event["description"], self.test_event["description"])
        self.assertEqual(event["event_type"], self.test_event["event_type"])
        self.assertEqual(event["tags"], self.test_event["tags"])

    def test_list_events(self):
        """Test listing events with filters."""
        # Add multiple events
        self.calendar.add_event(**self.test_event)
        self.calendar.add_event(
            title="Another Event",
            description="Another Description",
            start_time=(datetime.now() + timedelta(days=3)).isoformat(),
            end_time=(datetime.now() + timedelta(days=4)).isoformat(),
            event_type="workshop",
            tags=["test", "workshop"]
        )
        
        # Test filtering by type
        competition_events = self.calendar.list_events(event_type="competition")
        self.assertEqual(len(competition_events), 1)
        self.assertEqual(competition_events[0]["event_type"], "competition")
        
        # Test filtering by tags
        workshop_events = self.calendar.list_events(tags=["workshop"])
        self.assertEqual(len(workshop_events), 1)
        self.assertEqual(workshop_events[0]["event_type"], "workshop")

    def test_update_event(self):
        """Test updating an event."""
        # Add event
        event_id = self.calendar.add_event(**self.test_event)
        
        # Update event
        updates = {
            "title": "Updated Title",
            "description": "Updated Description"
        }
        result = self.calendar.update_event(event_id, updates)
        self.assertTrue(result)
        
        # Verify updates
        event = self.calendar.get_event(event_id)
        self.assertEqual(event["title"], "Updated Title")
        self.assertEqual(event["description"], "Updated Description")

    def test_delete_event(self):
        """Test deleting an event."""
        # Add event
        event_id = self.calendar.add_event(**self.test_event)
        
        # Delete event
        result = self.calendar.delete_event(event_id)
        self.assertTrue(result)
        
        # Verify deletion
        event = self.calendar.get_event(event_id)
        self.assertIsNone(event)

    def test_participant_management(self):
        """Test managing event participants."""
        # Add event
        event_id = self.calendar.add_event(**self.test_event)
        
        # Add participants
        self.calendar.add_participant(event_id, "user1")
        self.calendar.add_participant(event_id, "user2")
        
        # Verify participants
        event = self.calendar.get_event(event_id)
        self.assertEqual(len(event["participants"]), 2)
        self.assertIn("user1", event["participants"])
        self.assertIn("user2", event["participants"])
        
        # Remove participant
        self.calendar.remove_participant(event_id, "user1")
        event = self.calendar.get_event(event_id)
        self.assertEqual(len(event["participants"]), 1)
        self.assertNotIn("user1", event["participants"])

    def test_upcoming_events(self):
        """Test getting upcoming events."""
        # Add events at different times
        now = datetime.now()
        self.calendar.add_event(
            title="Past Event",
            description="Past Description",
            start_time=(now - timedelta(days=2)).isoformat(),
            end_time=(now - timedelta(days=1)).isoformat(),
            event_type="test"
        )
        self.calendar.add_event(
            title="Current Event",
            description="Current Description",
            start_time=now.isoformat(),
            end_time=(now + timedelta(days=1)).isoformat(),
            event_type="test"
        )
        self.calendar.add_event(
            title="Future Event",
            description="Future Description",
            start_time=(now + timedelta(days=5)).isoformat(),
            end_time=(now + timedelta(days=6)).isoformat(),
            event_type="test"
        )
        
        # Get upcoming events
        upcoming = self.calendar.get_upcoming_events(days=7)
        self.assertEqual(len(upcoming), 2)  # Current and Future events
        self.assertEqual(upcoming[0]["title"], "Current Event")
        self.assertEqual(upcoming[1]["title"], "Future Event")

    def test_invalid_operations(self):
        """Test invalid operations."""
        # Test invalid event ID
        self.assertIsNone(self.calendar.get_event("invalid_id"))
        self.assertFalse(self.calendar.update_event("invalid_id", {}))
        self.assertFalse(self.calendar.delete_event("invalid_id"))
        self.assertFalse(self.calendar.add_participant("invalid_id", "user1"))
        self.assertFalse(self.calendar.remove_participant("invalid_id", "user1"))
        
        # Test invalid time range
        event_id = self.calendar.add_event(
            title="Test Event",
            description="Test Description",
            start_time=datetime.now().isoformat(),
            end_time=(datetime.now() - timedelta(hours=1)).isoformat(),
            event_type="test"
        )
        self.assertIsNone(event_id)

    def test_calendar_export(self):
        """Test exporting calendar to iCalendar format."""
        # Add event
        event_id = self.calendar.add_event(**self.test_event)
        
        # Export calendar
        export_file = os.path.join(self.test_dir, "export.ics")
        result = self.calendar.export_calendar(export_file)
        self.assertTrue(result)
        self.assertTrue(os.path.exists(export_file))

if __name__ == '__main__':
    unittest.main() 