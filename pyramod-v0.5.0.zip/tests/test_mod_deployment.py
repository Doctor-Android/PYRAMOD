import os
import shutil
import tempfile
import unittest
from pathlib import Path
from mod_deployment import ModDeployment

class TestModDeployment(unittest.TestCase):
    def setUp(self):
        # Create temporary directories for testing
        self.test_dir = tempfile.mkdtemp()
        self.game_dir = Path(self.test_dir) / "game"
        self.mods_dir = Path(self.test_dir) / "mods"
        self.game_dir.mkdir()
        self.mods_dir.mkdir()

        # Create a test mod
        self.test_mod_dir = self.mods_dir / "test_mod"
        self.test_mod_dir.mkdir()
        self._create_test_mod()

        # Initialize ModDeployment
        self.deployment = ModDeployment(str(self.game_dir), str(self.mods_dir))

    def tearDown(self):
        # Clean up temporary directories
        shutil.rmtree(self.test_dir)

    def _create_test_mod(self):
        """Create a test mod with some files."""
        # Create some test files
        (self.test_mod_dir / "data").mkdir()
        (self.test_mod_dir / "textures").mkdir()

        # Create test files
        with open(self.test_mod_dir / "data" / "test.esp", "w") as f:
            f.write("test data")
        with open(self.test_mod_dir / "textures" / "test.dds", "w") as f:
            f.write("test texture")

    def test_deploy_mod(self):
        """Test deploying a mod."""
        # Deploy the test mod
        result = self.deployment.deploy_mod(str(self.test_mod_dir))
        self.assertTrue(result)

        # Verify files were deployed
        self.assertTrue((self.game_dir / "data" / "test.esp").exists())
        self.assertTrue((self.game_dir / "textures" / "test.dds").exists())

    def test_undeploy_mod(self):
        """Test undeploying a mod."""
        # First deploy the mod
        self.deployment.deploy_mod(str(self.test_mod_dir))

        # Then undeploy it
        result = self.deployment.undeploy_mod(str(self.test_mod_dir))
        self.assertTrue(result)

        # Verify files were removed
        self.assertFalse((self.game_dir / "data" / "test.esp").exists())
        self.assertFalse((self.game_dir / "textures" / "test.dds").exists())

    def test_verify_deployment(self):
        """Test deployment verification."""
        # Deploy the mod
        self.deployment.deploy_mod(str(self.test_mod_dir))

        # Verify deployment
        is_valid, issues = self.deployment.verify_deployment(str(self.test_mod_dir))
        self.assertTrue(is_valid)
        self.assertEqual(len(issues), 0)

    def test_deployment_rules(self):
        """Test deployment with rules."""
        # Create deployment rules
        rules = {
            "exclude_patterns": ["*.dds"]
        }

        # Deploy with rules
        result = self.deployment.deploy_mod(str(self.test_mod_dir), rules)
        self.assertTrue(result)

        # Verify only non-excluded files were deployed
        self.assertTrue((self.game_dir / "data" / "test.esp").exists())
        self.assertFalse((self.game_dir / "textures" / "test.dds").exists())

    def test_deployment_status(self):
        """Test getting deployment status."""
        # Deploy the mod
        self.deployment.deploy_mod(str(self.test_mod_dir))

        # Get status
        status = self.deployment.get_deployment_status(str(self.test_mod_dir))
        self.assertEqual(status["status"], "success")
        self.assertEqual(len(status["files"]), 2)

if __name__ == '__main__':
    unittest.main() 