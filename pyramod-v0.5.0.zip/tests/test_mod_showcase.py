#!/usr/bin/env python3
import unittest
import tempfile
import shutil
import os
from pathlib import Path
from mod_showcase import ModShowcase
from PIL import Image
import numpy as np

class TestModShowcase(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.showcase = ModShowcase(self.test_dir)
        
        # Create test media files
        self.media_dir = Path(self.test_dir) / "test_media"
        self.media_dir.mkdir()
        
        # Create a test image
        self.test_image = self.media_dir / "test.jpg"
        with open(self.test_image, "wb") as f:
            f.write(b"fake image data")

    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)

    def test_create_showcase(self):
        """Test creating a showcase."""
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=[str(self.test_image)],
            tags=["test", "example"],
            featured=True
        )
        
        self.assertIsNotNone(showcase_id)
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertIsNotNone(showcase)
        self.assertEqual(showcase["title"], "Test Showcase")
        self.assertEqual(showcase["mod_id"], "test_mod")
        self.assertEqual(showcase["author_id"], "test_author")
        self.assertEqual(len(showcase["media_files"]), 1)
        self.assertEqual(showcase["tags"], ["test", "example"])
        self.assertTrue(showcase["featured"])

    def test_update_showcase(self):
        """Test updating a showcase."""
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=[str(self.test_image)],
            tags=["test"]
        )
        
        # Update showcase
        success = self.showcase.update_showcase(
            showcase_id,
            title="Updated Title",
            description="Updated description",
            tags=["updated", "test"]
        )
        
        self.assertTrue(success)
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(showcase["title"], "Updated Title")
        self.assertEqual(showcase["description"], "Updated description")
        self.assertEqual(showcase["tags"], ["updated", "test"])

    def test_delete_showcase(self):
        """Test deleting a showcase."""
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=[str(self.test_image)]
        )
        
        # Delete showcase
        success = self.showcase.delete_showcase(showcase_id)
        self.assertTrue(success)
        
        # Verify showcase is deleted
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertIsNone(showcase)
        
        # Verify media directory is deleted
        media_dir = Path(self.test_dir) / "media" / showcase_id
        self.assertFalse(media_dir.exists())

    def test_list_showcases(self):
        """Test listing showcases with filters."""
        # Create multiple showcases
        self.showcase.create_showcase(
            mod_id="mod1",
            title="Showcase 1",
            description="Description 1",
            author_id="author1",
            media_files=[str(self.test_image)],
            tags=["tag1"],
            featured=True
        )
        
        self.showcase.create_showcase(
            mod_id="mod2",
            title="Showcase 2",
            description="Description 2",
            author_id="author2",
            media_files=[str(self.test_image)],
            tags=["tag2"]
        )
        
        # Test filters
        featured = self.showcase.list_showcases(featured=True)
        self.assertEqual(len(featured), 1)
        self.assertEqual(featured[0]["title"], "Showcase 1")
        
        by_author = self.showcase.list_showcases(author_id="author2")
        self.assertEqual(len(by_author), 1)
        self.assertEqual(by_author[0]["title"], "Showcase 2")
        
        by_tag = self.showcase.list_showcases(tags=["tag1"])
        self.assertEqual(len(by_tag), 1)
        self.assertEqual(by_tag[0]["title"], "Showcase 1")

    def test_comments(self):
        """Test comment functionality."""
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=[str(self.test_image)]
        )
        
        # Add comment
        success = self.showcase.add_comment(
            showcase_id,
            author_id="commenter",
            content="Test comment"
        )
        self.assertTrue(success)
        
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(len(showcase["comments"]), 1)
        self.assertEqual(showcase["comments"][0]["content"], "Test comment")
        
        # Delete comment
        comment_id = showcase["comments"][0]["id"]
        success = self.showcase.delete_comment(showcase_id, comment_id)
        self.assertTrue(success)
        
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(len(showcase["comments"]), 0)

    def test_views_and_likes(self):
        """Test view and like functionality."""
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=[str(self.test_image)]
        )
        
        # Test views
        self.showcase.increment_views(showcase_id)
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(showcase["views"], 1)
        
        # Test likes
        self.showcase.toggle_like(showcase_id)
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(showcase["likes"], 1)

    def test_invalid_operations(self):
        """Test handling of invalid operations."""
        # Test non-existent showcase
        self.assertFalse(self.showcase.update_showcase("invalid_id"))
        self.assertFalse(self.showcase.delete_showcase("invalid_id"))
        self.assertFalse(self.showcase.add_comment("invalid_id", "author", "content"))
        self.assertFalse(self.showcase.delete_comment("invalid_id", "comment_id"))
        self.assertFalse(self.showcase.increment_views("invalid_id"))
        self.assertFalse(self.showcase.toggle_like("invalid_id"))
        
        # Test invalid media file
        showcase_id = self.showcase.create_showcase(
            mod_id="test_mod",
            title="Test Showcase",
            description="Test description",
            author_id="test_author",
            media_files=["nonexistent.jpg"]
        )
        
        showcase = self.showcase.get_showcase(showcase_id)
        self.assertEqual(len(showcase["media_files"]), 0)

if __name__ == '__main__':
    unittest.main() 