import unittest
import tkinter as tk
from tkinter import ttk
import sys
import os

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import MainWindow
from settings_dialog import SettingsDialog
from about_dialog import AboutDialog
from load_order_dialog import LoadOrderDialog

class TestUI(unittest.TestCase):
    def setUp(self):
        """Set up test environment"""
        self.root = tk.Tk()
        self.app = MainWindow()
        
    def tearDown(self):
        """Clean up test environment"""
        self.root.destroy()
        
    def test_main_window(self):
        """Test main window components"""
        # Test window title
        self.assertEqual(self.app.root.title(), "Pyramod")
        
        # Test window size
        self.assertEqual(self.app.root.geometry(), "1200x800")
        
        # Test sidebar buttons
        sidebar_buttons = self.app.sidebar.winfo_children()
        self.assertEqual(len(sidebar_buttons), 5)  # Dashboard, Mods, Load Order, Settings, About
        
        # Test content area
        self.assertIsNotNone(self.app.content_area)
        
        # Test status bar
        self.assertIsNotNone(self.app.status_bar)
        
    def test_dashboard(self):
        """Test dashboard view"""
        # Show dashboard
        self.app.show_dashboard()
        
        # Test title
        title = self.app.current_content.winfo_children()[0]
        self.assertEqual(title.cget("text"), "Dashboard")
        
        # Test stat boxes
        stats_frame = self.app.current_content.winfo_children()[1]
        self.assertEqual(len(stats_frame.winfo_children()), 3)  # 3 stat boxes
        
        # Test activity list
        activity_frame = self.app.current_content.winfo_children()[2]
        activity_list = activity_frame.winfo_children()[0]
        self.assertEqual(len(activity_list.cget("columns")), 2)  # Time and Action columns
        
    def test_mods_view(self):
        """Test mods view"""
        # Show mods view
        self.app.show_mods()
        
        # Test title
        title = self.app.current_content.winfo_children()[0]
        self.assertEqual(title.cget("text"), "Mods")
        
        # Test toolbar
        toolbar = self.app.current_content.winfo_children()[1]
        self.assertEqual(len(toolbar.winfo_children()), 3)  # 3 buttons
        
        # Test mod list
        mod_frame = self.app.current_content.winfo_children()[2]
        mod_list = mod_frame.winfo_children()[0]
        self.assertEqual(len(mod_list.cget("columns")), 3)  # Name, Version, Status columns
        
    def test_load_order_view(self):
        """Test load order view"""
        # Show load order view
        self.app.show_load_order()
        
        # Test title
        title = self.app.current_content.winfo_children()[0]
        self.assertEqual(title.cget("text"), "Load Order")
        
        # Test order list
        order_frame = self.app.current_content.winfo_children()[1]
        order_list = order_frame.winfo_children()[0]
        self.assertEqual(len(order_list.cget("columns")), 2)  # Priority and Name columns
        
    def test_settings_dialog(self):
        """Test settings dialog"""
        dialog = SettingsDialog(self.root)
        
        # Test window title
        self.assertEqual(dialog.window.title(), "Settings")
        
        # Test notebook tabs
        self.assertEqual(len(dialog.notebook.tabs()), 3)  # General, Mods, Advanced
        
        # Test general tab
        general_tab = dialog.notebook.winfo_children()[0]
        self.assertEqual(len(general_tab.winfo_children()), 2)  # Theme and Language frames
        
        # Test mods tab
        mods_tab = dialog.notebook.winfo_children()[1]
        self.assertEqual(len(mods_tab.winfo_children()), 2)  # Updates and Deployment frames
        
        # Test advanced tab
        advanced_tab = dialog.notebook.winfo_children()[2]
        self.assertEqual(len(advanced_tab.winfo_children()), 2)  # System and Logging frames
        
    def test_about_dialog(self):
        """Test about dialog"""
        dialog = AboutDialog(self.root)
        
        # Test window title
        self.assertEqual(dialog.window.title(), "About Pyramod")
        
        # Test title
        title = dialog.main_frame.winfo_children()[0]
        self.assertEqual(title.cget("text"), "Pyramod")
        
        # Test version
        version = dialog.main_frame.winfo_children()[1]
        self.assertTrue(version.cget("text").startswith("Version"))
        
        # Test features
        features_frame = dialog.main_frame.winfo_children()[3]
        self.assertEqual(len(features_frame.winfo_children()), 6)  # 6 features
        
        # Test credits
        credits_frame = dialog.main_frame.winfo_children()[4]
        self.assertEqual(len(credits_frame.winfo_children()), 5)  # 5 credit lines
        
    def test_load_order_dialog(self):
        """Test load order dialog"""
        dialog = LoadOrderDialog(self.root, None)  # None for mod_manager as it's not needed for UI tests
        
        # Test window title
        self.assertEqual(dialog.window.title(), "Load Order Manager")
        
        # Test mod list
        self.assertEqual(len(dialog.mod_list.cget("columns")), 2)  # Name and Priority columns
        
        # Test buttons
        button_frame = dialog.window.winfo_children()[1]
        self.assertEqual(len(button_frame.winfo_children()), 4)  # 4 buttons

if __name__ == '__main__':
    unittest.main() 