#!/usr/bin/env python3
import os
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from proton_manager import ProtonManager

class TestProtonManager(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.temp_dir = tempfile.mkdtemp()
        self.manager = ProtonManager(self.temp_dir)
        
        # Create mock Proton installations
        self.steam_path = Path(self.temp_dir) / "steam" / "common"
        self.steam_path.mkdir(parents=True)
        (self.steam_path / "Proton-7.0").mkdir()
        (self.steam_path / "Proton-8.0").mkdir()
        
        self.lutris_path = Path(self.temp_dir) / "lutris" / "runners" / "wine"
        self.lutris_path.mkdir(parents=True)
        (self.lutris_path / "wine-7.0").mkdir()
        (self.lutris_path / "wine-8.0").mkdir()
        
        # Update config with test paths
        self.manager.config["proton_paths"]["steam"] = str(self.steam_path)
        self.manager.config["proton_paths"]["lutris"] = str(self.lutris_path)
        self.manager._save_config()
    
    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.temp_dir)
    
    def test_detect_proton_installations(self):
        """Test detection of Proton installations."""
        installations = self.manager.detect_proton_installations()
        
        self.assertIn("steam", installations)
        self.assertIn("lutris", installations)
        self.assertEqual(len(installations["steam"]), 2)
        self.assertEqual(len(installations["lutris"]), 2)
    
    def test_create_prefix(self):
        """Test prefix creation."""
        # Create a prefix
        success = self.manager.create_prefix("test_game", "Proton-7.0")
        self.assertTrue(success)
        
        # Verify prefix was created
        prefix_dir = Path(self.temp_dir) / "prefixes" / "test_game"
        self.assertTrue(prefix_dir.exists())
        
        # Verify prefix is registered
        self.assertIn("test_game", self.manager.prefix_registry)
        self.assertEqual(
            self.manager.prefix_registry["test_game"]["proton_version"],
            "Proton-7.0"
        )
    
    def test_delete_prefix(self):
        """Test prefix deletion."""
        # Create a prefix
        self.manager.create_prefix("test_game", "Proton-7.0")
        
        # Delete the prefix
        success = self.manager.delete_prefix("test_game")
        self.assertTrue(success)
        
        # Verify prefix was deleted
        prefix_dir = Path(self.temp_dir) / "prefixes" / "test_game"
        self.assertFalse(prefix_dir.exists())
        
        # Verify prefix is not in registry
        self.assertNotIn("test_game", self.manager.prefix_registry)
    
    def test_get_prefix_info(self):
        """Test getting prefix information."""
        # Create a prefix
        self.manager.create_prefix("test_game", "Proton-7.0")
        
        # Get prefix info
        info = self.manager.get_prefix_info("test_game")
        self.assertIsNotNone(info)
        self.assertEqual(info["proton_version"], "Proton-7.0")
        
        # Test non-existent prefix
        info = self.manager.get_prefix_info("non_existent")
        self.assertIsNone(info)
    
    def test_list_prefixes(self):
        """Test listing prefixes."""
        # Create some prefixes
        self.manager.create_prefix("game1", "Proton-7.0")
        self.manager.create_prefix("game2", "Proton-8.0")
        
        # List prefixes
        prefixes = self.manager.list_prefixes()
        self.assertEqual(len(prefixes), 2)
        
        # Verify prefix information
        game_names = [p[0] for p in prefixes]
        self.assertIn("game1", game_names)
        self.assertIn("game2", game_names)
    
    def test_update_prefix_settings(self):
        """Test updating prefix settings."""
        # Create a prefix
        self.manager.create_prefix("test_game", "Proton-7.0")
        
        # Update settings
        new_settings = {
            "dxvk": False,
            "vkd3d": True,
            "esync": False
        }
        success = self.manager.update_prefix_settings("test_game", new_settings)
        self.assertTrue(success)
        
        # Verify settings were updated
        info = self.manager.get_prefix_info("test_game")
        self.assertEqual(info["settings"]["dxvk"], False)
        self.assertEqual(info["settings"]["vkd3d"], True)
        self.assertEqual(info["settings"]["esync"], False)
        
        # Test updating non-existent prefix
        success = self.manager.update_prefix_settings("non_existent", new_settings)
        self.assertFalse(success)
    
    def test_invalid_operations(self):
        """Test handling of invalid operations."""
        # Try to create prefix with non-existent Proton version
        success = self.manager.create_prefix("test_game", "NonExistentProton")
        self.assertFalse(success)
        
        # Try to delete non-existent prefix
        success = self.manager.delete_prefix("non_existent")
        self.assertFalse(success)
        
        # Try to update settings for non-existent prefix
        success = self.manager.update_prefix_settings("non_existent", {"dxvk": True})
        self.assertFalse(success)

if __name__ == "__main__":
    unittest.main() 