import unittest
import os
import shutil
import tempfile
from mod_manager import ModManager
from game_profiles import GameProfile

class TestModManager(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for testing
        self.test_dir = tempfile.mkdtemp()
        self.mod_manager = ModManager(self.test_dir)
        self.test_game = "Stardew Valley"
        self.test_profile = "test_profile"

    def tearDown(self):
        # Clean up the temporary directory
        shutil.rmtree(self.test_dir)

    def test_create_profile(self):
        """Test creating a new mod profile"""
        profile = self.mod_manager.create_profile(self.test_game, self.test_profile)
        self.assertIsNotNone(profile)
        self.assertEqual(profile.name, self.test_profile)
        self.assertEqual(profile.game, self.test_game)

    def test_install_mod(self):
        """Test installing a mod"""
        # Create a test mod file
        mod_path = os.path.join(self.test_dir, "test_mod.zip")
        with open(mod_path, "w") as f:
            f.write("test mod content")

        # Install the mod
        result = self.mod_manager.install_mod(self.test_game, self.test_profile, mod_path)
        self.assertTrue(result)
        self.assertTrue(os.path.exists(os.path.join(self.test_dir, "mods", "test_mod")))

    def test_uninstall_mod(self):
        """Test uninstalling a mod"""
        # First install a mod
        mod_path = os.path.join(self.test_dir, "test_mod.zip")
        with open(mod_path, "w") as f:
            f.write("test mod content")
        self.mod_manager.install_mod(self.test_game, self.test_profile, mod_path)

        # Then uninstall it
        result = self.mod_manager.uninstall_mod(self.test_game, self.test_profile, "test_mod")
        self.assertTrue(result)
        self.assertFalse(os.path.exists(os.path.join(self.test_dir, "mods", "test_mod")))

    def test_list_mods(self):
        """Test listing installed mods"""
        # Install a test mod
        mod_path = os.path.join(self.test_dir, "test_mod.zip")
        with open(mod_path, "w") as f:
            f.write("test mod content")
        self.mod_manager.install_mod(self.test_game, self.test_profile, mod_path)

        # List mods
        mods = self.mod_manager.list_mods(self.test_game, self.test_profile)
        self.assertEqual(len(mods), 1)
        self.assertEqual(mods[0].name, "test_mod")

    def test_mod_conflicts(self):
        """Test detecting mod conflicts"""
        # Install two conflicting mods
        mod1_path = os.path.join(self.test_dir, "mod1.zip")
        mod2_path = os.path.join(self.test_dir, "mod2.zip")
        with open(mod1_path, "w") as f:
            f.write("test mod 1 content")
        with open(mod2_path, "w") as f:
            f.write("test mod 2 content")
        
        self.mod_manager.install_mod(self.test_game, self.test_profile, mod1_path)
        self.mod_manager.install_mod(self.test_game, self.test_profile, mod2_path)

        # Check for conflicts
        conflicts = self.mod_manager.check_conflicts(self.test_game, self.test_profile)
        self.assertIsInstance(conflicts, list)

if __name__ == '__main__':
    unittest.main() 