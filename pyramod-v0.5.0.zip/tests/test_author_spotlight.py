#!/usr/bin/env python3
import unittest
import tempfile
import shutil
import os
from pathlib import Path
from author_spotlight import AuthorSpotlight
from PIL import Image
import numpy as np

class TestAuthorSpotlight(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.spotlight = AuthorSpotlight(self.test_dir)
        
        # Create test avatar
        self.test_avatar = os.path.join(self.test_dir, "test_avatar.jpg")
        img = Image.new('RGB', (100, 100), color='blue')
        img.save(self.test_avatar)

    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)

    def test_register_author(self):
        """Test registering a new author."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio",
            social_links={
                "github": "https://github.com/testuser",
                "twitter": "https://twitter.com/testuser"
            },
            avatar_path=self.test_avatar
        )
        
        self.assertIsNotNone(author_id)
        
        # Verify author
        author = self.spotlight.get_author(author_id)
        self.assertIsNotNone(author)
        self.assertEqual(author["username"], "testuser")
        self.assertEqual(author["display_name"], "Test User")
        self.assertEqual(author["bio"], "Test bio")
        self.assertIn("github", author["social_links"])
        self.assertIsNotNone(author["avatar_url"])

    def test_update_author(self):
        """Test updating author information."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        # Update author
        updates = {
            "display_name": "Updated Name",
            "bio": "Updated bio"
        }
        result = self.spotlight.update_author(author_id, updates)
        self.assertTrue(result)
        
        # Verify updates
        author = self.spotlight.get_author(author_id)
        self.assertEqual(author["display_name"], "Updated Name")
        self.assertEqual(author["bio"], "Updated bio")

    def test_add_mod(self):
        """Test adding a mod to an author's profile."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        # Add mod
        mod_data = {
            "id": "mod123",
            "name": "Test Mod",
            "description": "Test description"
        }
        result = self.spotlight.add_mod(author_id, mod_data)
        self.assertTrue(result)
        
        # Verify mod
        author = self.spotlight.get_author(author_id)
        self.assertEqual(len(author["mods"]), 1)
        self.assertEqual(author["mods"][0]["id"], "mod123")
        self.assertEqual(author["stats"]["total_mods"], 1)

    def test_add_award(self):
        """Test adding an award to an author's profile."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        # Add award
        award_data = {
            "id": "award123",
            "name": "Best Modder 2024",
            "description": "Award for outstanding contributions"
        }
        result = self.spotlight.add_award(author_id, award_data)
        self.assertTrue(result)
        
        # Verify award
        author = self.spotlight.get_author(author_id)
        self.assertEqual(len(author["awards"]), 1)
        self.assertEqual(author["awards"][0]["id"], "award123")

    def test_create_spotlight(self):
        """Test creating a spotlight feature."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        # Create spotlight
        spotlight_id = self.spotlight.create_spotlight(
            author_id,
            "Featured Modder",
            "Test spotlight content",
            featured_mods=["mod123"]
        )
        
        self.assertIsNotNone(spotlight_id)
        
        # Verify spotlight
        spotlight = self.spotlight.get_spotlight(spotlight_id)
        self.assertIsNotNone(spotlight)
        self.assertEqual(spotlight["title"], "Featured Modder")
        self.assertEqual(spotlight["content"], "Test spotlight content")
        self.assertEqual(spotlight["featured_mods"], ["mod123"])
        self.assertIn("html_content", spotlight)

    def test_list_spotlights(self):
        """Test listing spotlights."""
        # Register author and create spotlights
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        self.spotlight.create_spotlight(
            author_id,
            "Spotlight 1",
            "Content 1"
        )
        self.spotlight.create_spotlight(
            author_id,
            "Spotlight 2",
            "Content 2"
        )
        
        # Test filtering
        spotlights = self.spotlight.list_spotlights(author_id=author_id)
        self.assertEqual(len(spotlights), 2)
        
        spotlights = self.spotlight.list_spotlights(status="published")
        self.assertEqual(len(spotlights), 2)

    def test_update_spotlight(self):
        """Test updating a spotlight feature."""
        # Register author and create spotlight
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        spotlight_id = self.spotlight.create_spotlight(
            author_id,
            "Original Title",
            "Original content"
        )
        
        # Update spotlight
        updates = {
            "title": "Updated Title",
            "content": "Updated content"
        }
        result = self.spotlight.update_spotlight(spotlight_id, updates)
        self.assertTrue(result)
        
        # Verify updates
        spotlight = self.spotlight.get_spotlight(spotlight_id)
        self.assertEqual(spotlight["title"], "Updated Title")
        self.assertEqual(spotlight["content"], "Updated content")
        self.assertIn("html_content", spotlight)

    def test_delete_spotlight(self):
        """Test deleting a spotlight feature."""
        # Register author and create spotlight
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        spotlight_id = self.spotlight.create_spotlight(
            author_id,
            "Test Spotlight",
            "Test content"
        )
        
        # Delete spotlight
        result = self.spotlight.delete_spotlight(spotlight_id)
        self.assertTrue(result)
        
        # Verify deletion
        spotlight = self.spotlight.get_spotlight(spotlight_id)
        self.assertIsNone(spotlight)
        
        # Verify directory is deleted
        spotlight_dir = Path(self.test_dir) / "spotlight" / "features" / spotlight_id
        self.assertFalse(spotlight_dir.exists())

    def test_author_stats(self):
        """Test author statistics management."""
        # Register author
        author_id = self.spotlight.register_author(
            username="testuser",
            display_name="Test User",
            bio="Test bio"
        )
        
        # Update stats
        stats = {
            "total_downloads": 1000,
            "total_endorsements": 100
        }
        result = self.spotlight.update_author_stats(author_id, stats)
        self.assertTrue(result)
        
        # Verify stats
        author_stats = self.spotlight.get_author_stats(author_id)
        self.assertIsNotNone(author_stats)
        self.assertEqual(author_stats["total_downloads"], 1000)
        self.assertEqual(author_stats["total_endorsements"], 100)

    def test_invalid_operations(self):
        """Test invalid operations."""
        # Test invalid author ID
        self.assertIsNone(self.spotlight.get_author("invalid_id"))
        self.assertFalse(self.spotlight.update_author("invalid_id", {}))
        self.assertFalse(self.spotlight.add_mod("invalid_id", {}))
        self.assertFalse(self.spotlight.add_award("invalid_id", {}))
        self.assertIsNone(self.spotlight.get_author_stats("invalid_id"))
        
        # Test invalid spotlight ID
        self.assertIsNone(self.spotlight.get_spotlight("invalid_id"))
        self.assertFalse(self.spotlight.update_spotlight("invalid_id", {}))
        self.assertFalse(self.spotlight.delete_spotlight("invalid_id"))

if __name__ == '__main__':
    unittest.main() 