#!/usr/bin/env python3
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timedelta
from system_monitor import SystemMonitor

class TestSystemMonitor(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.monitor = SystemMonitor(self.test_dir)
    
    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)
    
    def test_config_management(self):
        """Test configuration management."""
        # Test default config
        self.assertIn("monitoring_interval", self.monitor.config)
        self.assertIn("history_retention", self.monitor.config)
        self.assertIn("alert_thresholds", self.monitor.config)
        self.assertIn("monitored_processes", self.monitor.config)
        
        # Test updating alert thresholds
        new_thresholds = {
            "cpu_percent": 95,
            "memory_percent": 90
        }
        self.monitor.update_alert_thresholds(new_thresholds)
        self.assertEqual(
            self.monitor.config["alert_thresholds"]["cpu_percent"],
            95
        )
        self.assertEqual(
            self.monitor.config["alert_thresholds"]["memory_percent"],
            90
        )
    
    def test_process_monitoring(self):
        """Test process monitoring management."""
        # Test adding process
        self.monitor.add_monitored_process("test.exe")
        self.assertIn("test.exe", self.monitor.config["monitored_processes"])
        
        # Test removing process
        self.monitor.remove_monitored_process("test.exe")
        self.assertNotIn("test.exe", self.monitor.config["monitored_processes"])
    
    def test_monitoring_control(self):
        """Test monitoring start/stop."""
        # Test starting monitoring
        success = self.monitor.start_monitoring("TestGame")
        self.assertTrue(success)
        self.assertTrue(self.monitor.monitoring)
        self.assertEqual(self.monitor.current_game, "TestGame")
        self.assertIsNotNone(self.monitor.monitoring_start)
        
        # Test stopping monitoring
        success = self.monitor.stop_monitoring()
        self.assertTrue(success)
        self.assertFalse(self.monitor.monitoring)
        self.assertIsNone(self.monitor.current_game)
        self.assertIsNone(self.monitor.monitoring_start)
        
        # Test stopping when not monitoring
        success = self.monitor.stop_monitoring()
        self.assertFalse(success)
    
    def test_metrics_collection(self):
        """Test metrics collection."""
        # Start monitoring
        self.monitor.start_monitoring("TestGame")
        
        # Get current metrics
        metrics = self.monitor.get_current_metrics()
        self.assertIsNotNone(metrics)
        
        # Check metrics structure
        self.assertIn("timestamp", metrics)
        self.assertIn("cpu", metrics)
        self.assertIn("memory", metrics)
        self.assertIn("disk", metrics)
        self.assertIn("gpu", metrics)
        self.assertIn("processes", metrics)
        
        # Check CPU metrics
        self.assertIn("percent", metrics["cpu"])
        self.assertIn("count", metrics["cpu"])
        self.assertIn("frequency", metrics["cpu"])
        
        # Check memory metrics
        self.assertIn("total", metrics["memory"])
        self.assertIn("available", metrics["memory"])
        self.assertIn("percent", metrics["memory"])
        self.assertIn("used", metrics["memory"])
        
        # Check disk metrics
        self.assertIn("total", metrics["disk"])
        self.assertIn("used", metrics["disk"])
        self.assertIn("free", metrics["disk"])
        self.assertIn("percent", metrics["disk"])
        
        # Stop monitoring
        self.monitor.stop_monitoring()
    
    def test_alert_handling(self):
        """Test alert handling."""
        # Set low thresholds for testing
        self.monitor.update_alert_thresholds({
            "cpu_percent": 0,
            "memory_percent": 0,
            "gpu_percent": 0,
            "gpu_memory_percent": 0,
            "disk_percent": 0
        })
        
        # Start monitoring
        self.monitor.start_monitoring("TestGame")
        
        # Get metrics (should trigger alerts)
        metrics = self.monitor.get_current_metrics()
        alerts = self.monitor._check_alerts(metrics)
        
        # Check that alerts were triggered
        self.assertGreater(len(alerts), 0)
        for alert in alerts:
            self.assertIn("type", alert)
            self.assertIn("level", alert)
            self.assertIn("message", alert)
        
        # Stop monitoring
        self.monitor.stop_monitoring()
    
    def test_history_management(self):
        """Test history management."""
        # Start monitoring
        self.monitor.start_monitoring("TestGame")
        
        # Collect some metrics
        time.sleep(2)
        
        # Stop monitoring
        self.monitor.stop_monitoring()
        
        # Get history
        history = self.monitor.get_metrics_history(game_name="TestGame")
        self.assertGreater(len(history), 0)
        
        # Check history structure
        entry = history[0]
        self.assertIn("game", entry)
        self.assertIn("start_time", entry)
        self.assertIn("end_time", entry)
        self.assertIn("metrics", entry)
        
        # Test history filtering
        start_time = (datetime.now() - timedelta(days=1)).isoformat()
        end_time = (datetime.now() + timedelta(days=1)).isoformat()
        
        filtered_history = self.monitor.get_metrics_history(
            game_name="TestGame",
            start_time=start_time,
            end_time=end_time
        )
        self.assertEqual(len(filtered_history), len(history))
    
    def test_history_cleanup(self):
        """Test history cleanup."""
        # Set short retention period
        self.monitor.config["history_retention"] = 1
        self.monitor._save_config()
        
        # Create old history file
        old_time = datetime.now() - timedelta(days=2)
        old_file = self.monitor.history_dir / f"old_game_{old_time.strftime('%Y%m%d_%H%M%S')}.json"
        with open(old_file, "w") as f:
            f.write("{}")
        
        # Run cleanup
        self.monitor.cleanup_history()
        
        # Check that old file was removed
        self.assertFalse(old_file.exists())

if __name__ == "__main__":
    unittest.main() 