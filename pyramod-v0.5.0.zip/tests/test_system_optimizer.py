import unittest
import tempfile
import shutil
import json
from pathlib import Path
from datetime import datetime
from system_optimizer import SystemOptimizer

class TestSystemOptimizer(unittest.TestCase):
    def setUp(self):
        # Create temporary directory for config
        self.test_dir = tempfile.mkdtemp()
        self.optimizer = SystemOptimizer(self.test_dir)

    def tearDown(self):
        # Clean up temporary directory
        shutil.rmtree(self.test_dir)

    def test_profile_management(self):
        """Test creating and retrieving optimization profiles."""
        # Create a test profile
        test_profile = {
            'settings': {
                'cpu': {'governor': 'performance'},
                'memory': {'swappiness': 10}
            }
        }
        self.optimizer.create_optimization_profile("TestGame", test_profile)

        # Retrieve the profile
        profile = self.optimizer.get_optimization_profile("TestGame")
        self.assertIsNotNone(profile)
        self.assertEqual(profile['settings']['cpu']['governor'], 'performance')
        self.assertEqual(profile['settings']['memory']['swappiness'], 10)

    def test_optimization_application(self):
        """Test applying optimizations."""
        # Create a test profile with safe settings
        test_profile = {
            'settings': {
                'cpu': {'governor': 'powersave'},
                'memory': {'swappiness': 60},
                'disk': {'readahead': 128}
            }
        }
        self.optimizer.create_optimization_profile("TestGame", test_profile)

        # Apply optimizations
        optimizations = self.optimizer.optimize_system_for_game("TestGame")
        self.assertIsInstance(optimizations, list)

    def test_recommendations(self):
        """Test getting optimization recommendations."""
        # Create a test profile
        test_profile = {
            'settings': {
                'cpu': {'governor': 'performance'},
                'memory': {'swappiness': 10}
            }
        }
        self.optimizer.create_optimization_profile("TestGame", test_profile)

        # Get recommendations
        recommendations = self.optimizer.get_optimization_recommendations("TestGame")
        self.assertIsInstance(recommendations, list)

    def test_profile_persistence(self):
        """Test that profiles are saved and loaded correctly."""
        # Create a test profile
        test_profile = {
            'settings': {
                'cpu': {'governor': 'performance'},
                'memory': {'swappiness': 10}
            }
        }
        self.optimizer.create_optimization_profile("TestGame", test_profile)

        # Create a new optimizer instance
        new_optimizer = SystemOptimizer(self.test_dir)

        # Check if profile was loaded
        profile = new_optimizer.get_optimization_profile("TestGame")
        self.assertIsNotNone(profile)
        self.assertEqual(profile['settings']['cpu']['governor'], 'performance')

    def test_invalid_profile(self):
        """Test handling of invalid profiles."""
        # Try to get non-existent profile
        profile = self.optimizer.get_optimization_profile("NonExistentGame")
        self.assertIsNone(profile)

        # Try to optimize non-existent profile
        optimizations = self.optimizer.optimize_system_for_game("NonExistentGame")
        self.assertEqual(len(optimizations), 0)

    def test_recommendations_no_profile(self):
        """Test recommendations for non-existent profile."""
        recommendations = self.optimizer.get_optimization_recommendations("NonExistentGame")
        self.assertEqual(len(recommendations), 1)
        self.assertEqual(recommendations[0], "No optimization profile found for this game")

if __name__ == '__main__':
    unittest.main() 