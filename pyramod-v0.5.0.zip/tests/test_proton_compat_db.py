import os
import tempfile
import unittest
from pathlib import Path
from proton_compat_db import ProtonCompatDB

class TestProtonCompatDB(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        # Create a temporary directory for the test database
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_proton_compat.db"
        self.db = ProtonCompatDB(str(self.db_path))
        
        # Add some test data
        self.proton_id = self.db.add_proton_version(
            "Proton Experimental",
            "7.0-5",
            "proton",
            "/path/to/proton"
        )
        
        self.wine_id = self.db.add_proton_version(
            "Wine",
            "7.0",
            "wine",
            "/path/to/wine"
        )
    
    def tearDown(self):
        """Clean up test environment."""
        self.temp_dir.cleanup()
    
    def test_proton_version_management(self):
        """Test adding and retrieving Proton/Wine versions."""
        # Test getting all versions
        versions = self.db.get_proton_versions()
        self.assertEqual(len(versions), 2)
        
        # Test filtering by type
        proton_versions = self.db.get_proton_versions(type="proton")
        self.assertEqual(len(proton_versions), 1)
        self.assertEqual(proton_versions[0]["name"], "Proton Experimental")
        
        wine_versions = self.db.get_proton_versions(type="wine")
        self.assertEqual(len(wine_versions), 1)
        self.assertEqual(wine_versions[0]["name"], "Wine")
        
        # Test updating installation status
        self.db.update_proton_installation(self.proton_id, True)
        versions = self.db.get_proton_versions()
        self.assertTrue(versions[0]["is_installed"])
    
    def test_game_compatibility(self):
        """Test game compatibility management."""
        # Add game compatibility
        compat_id = self.db.add_game_compatibility(
            "skyrim",
            self.proton_id,
            "perfect",
            "Works perfectly with all mods",
            "system"
        )
        
        # Get game compatibility
        compat = self.db.get_game_compatibility("skyrim")
        self.assertEqual(len(compat), 1)
        self.assertEqual(compat[0]["compatibility_level"], "perfect")
        self.assertEqual(compat[0]["proton_name"], "Proton Experimental")
        
        # Update compatibility
        self.db.add_game_compatibility(
            "skyrim",
            self.proton_id,
            "good",
            "Minor issues with some mods",
            "system"
        )
        compat = self.db.get_game_compatibility("skyrim")
        self.assertEqual(compat[0]["compatibility_level"], "good")
    
    def test_mod_compatibility(self):
        """Test mod compatibility management."""
        # Add mod compatibility
        compat_id = self.db.add_mod_compatibility(
            "skse",
            "skyrim",
            self.proton_id,
            "perfect",
            "Works perfectly",
            "system"
        )
        
        # Get mod compatibility
        compat = self.db.get_mod_compatibility("skse", "skyrim")
        self.assertEqual(len(compat), 1)
        self.assertEqual(compat[0]["compatibility_level"], "perfect")
        self.assertEqual(compat[0]["proton_name"], "Proton Experimental")
        
        # Update compatibility
        self.db.add_mod_compatibility(
            "skse",
            "skyrim",
            self.proton_id,
            "good",
            "Minor issues",
            "system"
        )
        compat = self.db.get_mod_compatibility("skse", "skyrim")
        self.assertEqual(compat[0]["compatibility_level"], "good")
    
    def test_compatibility_reports(self):
        """Test compatibility report management."""
        # Add a report
        report_id = self.db.add_compatibility_report(
            "game",
            "skyrim",
            self.proton_id,
            "perfect",
            "Test report",
            "user1"
        )
        
        # Verify the report
        self.db.verify_compatibility_report(report_id, "admin")
        
        # Get the best version
        best_version = self.db.get_best_proton_version("skyrim")
        self.assertIsNotNone(best_version)
        self.assertEqual(best_version["name"], "Proton Experimental")
    
    def test_best_version_selection(self):
        """Test selection of the best Proton/Wine version."""
        # Add multiple versions with different compatibility levels
        self.db.add_game_compatibility("skyrim", self.proton_id, "perfect")
        self.db.add_game_compatibility("skyrim", self.wine_id, "good")
        
        # Get best version for game only
        best_version = self.db.get_best_proton_version("skyrim")
        self.assertEqual(best_version["name"], "Proton Experimental")
        
        # Add mod compatibility
        self.db.add_mod_compatibility("skse", "skyrim", self.proton_id, "good")
        self.db.add_mod_compatibility("skse", "skyrim", self.wine_id, "perfect")
        
        # Get best version for game and mod
        best_version = self.db.get_best_proton_version("skyrim", "skse")
        self.assertEqual(best_version["name"], "Wine")
    
    def test_invalid_operations(self):
        """Test handling of invalid operations."""
        # Test getting compatibility for non-existent game
        compat = self.db.get_game_compatibility("nonexistent")
        self.assertEqual(len(compat), 0)
        
        # Test getting compatibility for non-existent mod
        compat = self.db.get_mod_compatibility("nonexistent", "skyrim")
        self.assertEqual(len(compat), 0)
        
        # Test getting best version for non-existent game
        best_version = self.db.get_best_proton_version("nonexistent")
        self.assertIsNone(best_version)

if __name__ == "__main__":
    unittest.main() 