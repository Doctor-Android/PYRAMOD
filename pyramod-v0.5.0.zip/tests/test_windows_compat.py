#!/usr/bin/env python3
import os
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from windows_compat import WindowsCompat

class TestWindowsCompat(unittest.TestCase):
    def setUp(self):
        """Set up test environment."""
        self.test_dir = tempfile.mkdtemp()
        self.compat = WindowsCompat(self.test_dir)
        
        # Create test files
        self.test_dll = os.path.join(self.test_dir, "test.dll")
        with open(self.test_dll, "wb") as f:
            f.write(b"test dll content")
        
        self.test_installer = os.path.join(self.test_dir, "test_installer.exe")
        with open(self.test_installer, "wb") as f:
            f.write(b"test installer content")
        
        self.test_script_ext = os.path.join(self.test_dir, "script_extender")
        os.makedirs(self.test_script_ext)
        with open(os.path.join(self.test_script_ext, "test.dll"), "wb") as f:
            f.write(b"script extender dll")
    
    def tearDown(self):
        """Clean up test environment."""
        shutil.rmtree(self.test_dir)
    
    def test_path_translation(self):
        """Test Windows path translation."""
        # Test direct mapping
        self.compat.add_path_translation("C:\\Games\\Skyrim", "/games/skyrim")
        self.assertEqual(
            self.compat.translate_path("C:\\Games\\Skyrim"),
            "/games/skyrim"
        )
        
        # Test automatic conversion
        self.assertEqual(
            self.compat.translate_path("C:\\Program Files\\Game"),
            "/mnt/c/Program Files/Game"
        )
    
    def test_registry_operations(self):
        """Test registry operations."""
        # Test setting and getting registry values
        self.compat.set_registry_value(
            "HKEY_LOCAL_MACHINE\\Software\\Game",
            "InstallPath",
            "C:\\Games\\Game"
        )
        self.assertEqual(
            self.compat.get_registry_value(
                "HKEY_LOCAL_MACHINE\\Software\\Game",
                "InstallPath"
            ),
            "C:\\Games\\Game"
        )
        
        # Test non-existent value
        self.assertIsNone(
            self.compat.get_registry_value(
                "HKEY_LOCAL_MACHINE\\Software\\Game",
                "NonExistent"
            )
        )
    
    def test_dll_handling(self):
        """Test DLL handling."""
        # Test DLL installation
        target_dir = os.path.join(self.test_dir, "target")
        os.makedirs(target_dir)
        
        self.assertTrue(self.compat.handle_dll(self.test_dll, target_dir))
        
        # Verify DLL was cached and linked
        cached_dll = os.path.join(self.compat.dll_dir, "test.dll")
        self.assertTrue(os.path.exists(cached_dll))
        self.assertTrue(os.path.exists(os.path.join(target_dir, "test.dll")))
        
        # Verify DLL cache entry
        self.assertIn("test.dll", self.compat.dll_cache)
    
    def test_script_extender(self):
        """Test script extender installation."""
        # Test script extender installation
        self.assertTrue(
            self.compat.install_script_extender("Skyrim", self.test_script_ext)
        )
        
        # Verify installation
        extender_path = self.compat.get_script_extender_path("Skyrim")
        self.assertIsNotNone(extender_path)
        self.assertTrue(os.path.exists(os.path.join(extender_path, "test.dll")))
        
        # Verify cache entry
        self.assertIn("Skyrim", self.compat.script_ext_cache)
    
    def test_installer_execution(self):
        """Test installer execution."""
        # Note: This test is mocked since we can't actually run Wine in tests
        # In a real environment, this would test actual installer execution
        self.assertTrue(
            self.compat.run_installer(
                self.test_installer,
                os.path.join(self.test_dir, "game"),
                ["/S"]
            )
        )
    
    def test_cleanup(self):
        """Test cleanup operations."""
        # Set up test data
        self.compat.handle_dll(self.test_dll, os.path.join(self.test_dir, "target"))
        self.compat.install_script_extender("Skyrim", self.test_script_ext)
        
        # Remove test files
        os.remove(self.test_dll)
        shutil.rmtree(self.test_script_ext)
        
        # Run cleanup
        self.compat.cleanup()
        
        # Verify cleanup
        self.assertNotIn("test.dll", self.compat.dll_cache)
        self.assertNotIn("Skyrim", self.compat.script_ext_cache)

if __name__ == "__main__":
    unittest.main() 