import unittest
import os
import sys
import json
import tempfile
import shutil
from pathlib import Path

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mod_manager import ModManager
from system_manager import SystemManager
from proton_manager import ProtonManager
from wine_config_manager import WineConfigManager

class TestIntegration(unittest.TestCase):
    def setUp(self):
        """Set up test environment"""
        # Create temporary directory
        self.test_dir = tempfile.mkdtemp()
        self.mod_dir = os.path.join(self.test_dir, "mods")
        self.game_dir = os.path.join(self.test_dir, "games")
        os.makedirs(self.mod_dir)
        os.makedirs(self.game_dir)
        
        # Initialize managers
        self.mod_manager = ModManager(self.mod_dir)
        self.system_manager = SystemManager()
        self.proton_manager = ProtonManager()
        self.wine_manager = WineConfigManager()
        
    def tearDown(self):
        """Clean up test environment"""
        shutil.rmtree(self.test_dir)
        
    def test_mod_installation(self):
        """Test mod installation workflow"""
        # Create test mod
        mod_data = {
            "name": "Test Mod",
            "version": "1.0.0",
            "files": ["test.txt"]
        }
        
        # Install mod
        self.mod_manager.install_mod(mod_data)
        
        # Verify installation
        installed_mods = self.mod_manager.get_installed_mods()
        self.assertEqual(len(installed_mods), 1)
        self.assertEqual(installed_mods[0]["name"], "Test Mod")
        
    def test_load_order(self):
        """Test load order management"""
        # Install multiple mods
        mods = [
            {"name": "Mod A", "version": "1.0.0"},
            {"name": "Mod B", "version": "1.0.0"},
            {"name": "Mod C", "version": "1.0.0"}
        ]
        
        for mod in mods:
            self.mod_manager.install_mod(mod)
            
        # Set load order
        load_order = [
            {"name": "Mod C", "priority": 0},
            {"name": "Mod B", "priority": 1},
            {"name": "Mod A", "priority": 2}
        ]
        
        self.mod_manager.update_load_order(load_order)
        
        # Verify load order
        installed_mods = self.mod_manager.get_installed_mods()
        self.assertEqual(installed_mods[0]["name"], "Mod C")
        self.assertEqual(installed_mods[1]["name"], "Mod B")
        self.assertEqual(installed_mods[2]["name"], "Mod A")
        
    def test_proton_compatibility(self):
        """Test Proton compatibility system"""
        # Add test game
        game_data = {
            "name": "Test Game",
            "path": self.game_dir,
            "proton_version": "7.0"
        }
        
        # Set compatibility
        self.proton_manager.set_compatibility(game_data["name"], "7.0", True)
        
        # Verify compatibility
        compat = self.proton_manager.get_compatibility(game_data["name"])
        self.assertTrue(compat["compatible"])
        self.assertEqual(compat["version"], "7.0")
        
    def test_system_monitoring(self):
        """Test system monitoring"""
        # Get system info
        system_info = self.system_manager.get_system_info()
        
        # Verify system info
        self.assertIn("cpu", system_info)
        self.assertIn("memory", system_info)
        self.assertIn("gpu", system_info)
        
    def test_wine_configuration(self):
        """Test Wine configuration"""
        # Set Wine config
        config = {
            "dxvk": True,
            "esync": True,
            "fsync": True
        }
        
        self.wine_manager.set_config(config)
        
        # Verify config
        saved_config = self.wine_manager.get_config()
        self.assertEqual(saved_config["dxvk"], True)
        self.assertEqual(saved_config["esync"], True)
        self.assertEqual(saved_config["fsync"], True)
        
    def test_mod_deployment(self):
        """Test mod deployment system"""
        # Install test mod
        mod_data = {
            "name": "Test Mod",
            "version": "1.0.0",
            "files": ["test.txt"]
        }
        
        self.mod_manager.install_mod(mod_data)
        
        # Deploy mods
        self.mod_manager.deploy_mods()
        
        # Verify deployment
        deployed_files = os.listdir(self.game_dir)
        self.assertIn("test.txt", deployed_files)
        
    def test_mod_updates(self):
        """Test mod update system"""
        # Install test mod
        mod_data = {
            "name": "Test Mod",
            "version": "1.0.0",
            "files": ["test.txt"]
        }
        
        self.mod_manager.install_mod(mod_data)
        
        # Update mod
        update_data = {
            "name": "Test Mod",
            "version": "1.1.0",
            "files": ["test.txt", "new.txt"]
        }
        
        self.mod_manager.update_mod(update_data)
        
        # Verify update
        installed_mods = self.mod_manager.get_installed_mods()
        self.assertEqual(installed_mods[0]["version"], "1.1.0")
        
    def test_error_handling(self):
        """Test error handling"""
        # Test invalid mod installation
        with self.assertRaises(ValueError):
            self.mod_manager.install_mod({})
            
        # Test invalid load order
        with self.assertRaises(ValueError):
            self.mod_manager.update_load_order([{"invalid": "data"}])
            
        # Test invalid Proton version
        with self.assertRaises(ValueError):
            self.proton_manager.set_compatibility("Test Game", "invalid", True)

if __name__ == '__main__':
    unittest.main() 