# Pyramod

A modern, user-friendly mod manager for Linux games, inspired by Vortex.

**Created by BLUDSTAR**

## Features

- 🎮 Multi-game support
- 📦 Easy mod installation and management
- 🔄 Automatic updates
- 💾 Profile management
- 🛡️ Backup system
- 🎯 Mod conflict detection
- 🌙 Dark/Light theme
- 🔌 Plugin load order management
- ✨ Professional splash screen with logo animation
- ✨ Logos embedded directly in the GUI for persistent branding.

## Requirements

- Python 3.8+
- `pip` and `venv`

## How to Install and Run

### 1. Clone the Repository
First, clone the Pyramod repository to your local machine:
```bash
git clone https://github.com/bludstar/pyramod.git
cd pyramod
```

### 2. Set Up a Virtual Environment
It is highly recommended to use a virtual environment to manage dependencies.
```bash
python3 -m venv venv
source venv/bin/activate
```
*On Windows, the activation command is `venv\\Scripts\\activate`*

### 3. Install Dependencies
Install all the required Python packages using pip.
```bash
pip install -r requirements.txt
```

### 4. Run Pyramod
Once the installation is complete, you can run the application with:
```bash
python -m pyramod.main --gui
```
Or, for command-line operations:
```bash
python -m pyramod.main --help
```

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup

1.  **Fork the repository** and clone it.
2.  Follow the **installation steps** above.
3.  Install development dependencies:
    ```bash
    pip install -r requirements-dev.txt
    ```
4.  Run tests to ensure everything is working:
    ```bash
    pytest
    ```
5.  Create your feature branch and submit a pull request!

## Community

- [Discord Server](https://discord.gg/pyramod) - Join our community
- [GitHub Discussions](https://github.com/yourusername/pyramod/discussions) - Ask questions and share ideas
- [Issue Tracker](https://github.com/yourusername/pyramod/issues) - Report bugs and request features

## Documentation

- [User Guide](docs/user_guide.md)
- [API Documentation](docs/api.md)
- [Development Guide](docs/development.md)

## Roadmap

- [ ] Steam Workshop integration
- [ ] Nexus Mods integration
- [ ] Mod collections
- [ ] Cloud sync
- [ ] More game support

## Support Pyramod

If you find Pyramod useful, consider supporting its development. Your contributions help cover server costs, development time, and continued improvements.

**A commitment to charity: 10% of all donations will be given to [Caritas Internationalis](https://www.caritas.org/), a global organization dedicated to ending poverty and promoting justice.**

### Patreon Tiers

-   **Supporter** ($6.99/month)
    -   Early access to new features
    -   Your name in the credits
    -   Access to a supporter-only Discord channel
    -   Basic priority support

-   **Enthusiast** ($12.99/month)
    -   All Supporter tier benefits
    -   Vote on new features and development priorities
    -   Access to beta testing versions
    -   Advanced priority support

-   **Patron** ($99.99/month)
    -   All Enthusiast tier benefits
    -   Direct input on the development roadmap
    -   Request custom features
    -   Your name prominently displayed in the application and credits

[❤️ Support on Patreon](https://www.patreon.com/your_username)

### Other Ways to Support

-   [🏆 GitHub Sponsors](https://github.com/sponsors/your_username) (One-time or recurring)
-   [💸 PayPal](https://paypal.me/your_username) (Direct donations)

Your support helps maintain and improve Pyramod for the entire Linux gaming community!

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- Inspired by [Vortex](https://www.nexusmods.com/about/vortex/)
- Built with [Python](https://www.python.org/) and [Tkinter](https://docs.python.org/3/library/tkinter.html)
- Thanks to all our contributors!

## Support

If you find Pyramod useful, consider supporting its development:

### Patreon Tiers

- **Supporter** ($6.99/month)
  - Early access to new features
  - Your name in the credits
  - Access to supporter-only Discord
  - Basic priority support

- **Enthusiast** ($12.99/month)
  - Everything in Supporter tier
  - Vote on new features
  - Beta testing access
  - Custom mod profiles
  - Advanced priority support

- **Patron** ($99.99/month)
  - Everything in Enthusiast tier
  - Direct input on development
  - Custom feature requests
  - Private Discord channel
  - Your name prominently displayed
  - Early access to all features
  - Priority bug fixes

[Support on Patreon](https://www.patreon.com/your_username)

## GitHub Sponsors

- [GitHub Sponsors](https://github.com/sponsors/your_username) - One-time or recurring support

## PayPal

- [PayPal](https://paypal.me/your_username) - Direct donations

Your support helps maintain and improve Pyramod for the Linux gaming community! 